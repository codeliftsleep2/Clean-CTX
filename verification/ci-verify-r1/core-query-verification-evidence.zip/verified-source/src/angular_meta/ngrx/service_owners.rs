//! Service ownership of already-qualified constructor dispatches, compilation-local.
use super::constructors::ConstructorDispatch;
use crate::angular_meta::inject_evidence::ClassInitializerEvidence;
use crate::compression::capture_pipeline::CapturedNode;
use crate::ir::invocation_evidence::{
    ArgumentQualifier, DeclarationContextKind, InvocationEvidenceView, InvocationOccurrence,
    SourceSpan, WrittenCallee,
};
use crate::layers::meta::semantic::{EntityRef, SemanticEdge, SemanticRelation};
use std::collections::BTreeMap;

pub(crate) struct AuthoritativeServiceOwner {
    pub service: String,
    pub class_span: SourceSpan,
    pub method_span: SourceSpan,
}

/// Join exact callable context through syntax to its exact class, then require
/// independent Angular Service authority for that same class declaration.
pub(crate) fn authoritative_service_owner(
    invocation: &InvocationOccurrence,
    classes: &[ClassInitializerEvidence],
    source: &str,
) -> Option<AuthoritativeServiceOwner> {
    let context = invocation.declaration_context()?;
    if context.kind() != DeclarationContextKind::Callable {
        return None;
    }
    let language = crate::compression::language::safe_typescript_language()?;
    let mut parser = tree_sitter::Parser::new();
    parser.set_language(&language).ok()?;
    let tree = parser.parse(source, None)?;
    if tree.root_node().has_error() {
        return None;
    }
    let declaration = context.declaration();
    let method = tree
        .root_node()
        .named_descendant_for_byte_range(declaration.start_byte(), declaration.end_byte())?;
    if method.kind() != "method_definition"
        || method.start_byte() != declaration.start_byte()
        || method.end_byte() != declaration.end_byte()
    {
        return None;
    }
    let body = method.parent().filter(|node| node.kind() == "class_body")?;
    let owner = body
        .parent()
        .filter(|node| node.kind() == "class_declaration")?;
    let class_span = SourceSpan::new(owner.start_byte(), owner.end_byte()).ok()?;
    let class = classes
        .iter()
        .find(|class| class.class_span == class_span)?;
    if crate::angular_meta::decorators::extract_graph_entries(&class.raw_class)?.1
        != crate::angular_meta::decorators::ClassKind::Service
    {
        return None;
    }
    Some(AuthoritativeServiceOwner {
        service: class.consumer.clone(),
        class_span,
        method_span: declaration,
    })
}

/// Attach Service ownership to modern action-creator dispatch occurrences in
/// non-static property initializers. The generic TypeScript `this` binder
/// remains method-only; this is the bounded NgRx initializer authority path.
pub(crate) fn admit_modern_initializer_dispatches(
    shape: &mut super::NgRxShape,
    evidence: &InvocationEvidenceView<'_>,
    classes: &[ClassInitializerEvidence],
    source_id: &str,
    source: &str,
) {
    let source_hash = crate::cache::content_hash(source.as_bytes());
    for site in &mut shape.dispatch_sites {
        if site.object_literal {
            continue;
        }
        let Some(call) = evidence
            .occurrences()
            .iter()
            .find(|call| call.span().start_byte() == site.call_start)
        else {
            continue;
        };
        let WrittenCallee::Member { receiver, terminal } = call.callee() else {
            continue;
        };
        if evidence.slice(*terminal).ok() != Some("dispatch") {
            continue;
        }
        let [argument] = call.arguments() else {
            continue;
        };
        if argument.qualifier() != &ArgumentQualifier::Plain {
            continue;
        }
        let Some(authority) = super::selector_references::initializer_store_authority(
            call, *receiver, classes, None, source,
        ) else {
            continue;
        };
        let Some(service) = authority.service_owner else {
            continue;
        };
        let Some(store_import) =
            crate::ir::typescript_type_import_binding::bind_type_reference_to_named_import(
                source_id,
                source,
                authority.type_reference,
            )
        else {
            continue;
        };
        if store_import.source_id() == source_id
            && store_import.source_hash() == source_hash
            && store_import.imported_symbol_name() == "Store"
            && store_import.module_specifier() == "@ngrx/store"
        {
            site.service_owner = Some(service);
        }
    }
}

#[derive(Debug, Clone)]
pub(crate) struct ServiceDispatch {
    pub start_byte: usize,
    pub service: String,
    pub action: String,
    pub file: String,
    pub source_hash: String,
    #[allow(dead_code)]
    pub class_span: SourceSpan,
    #[allow(dead_code)]
    pub method_span: SourceSpan,
}
fn span(node: &CapturedNode) -> SourceSpan {
    SourceSpan::new(node.start_byte, node.end_byte).expect("ordered parser span")
}

/// Same-match class -> own method -> immediate statement -> invocation, joined
/// to both frozen endpoint evidence and independent canonical Service authority.
pub(crate) fn collect(
    source: &str,
    file: Option<&str>,
    captures: &[CapturedNode],
    invocations: &[InvocationOccurrence],
    classes: &[ClassInitializerEvidence],
    constructors: &[ConstructorDispatch],
) -> Vec<ServiceDispatch> {
    let Some(file) = file else {
        return Vec::new();
    };
    let hash = crate::cache::content_hash(source.as_bytes());
    let mut matches: BTreeMap<usize, BTreeMap<&str, &CapturedNode>> = BTreeMap::new();
    for c in captures
        .iter()
        .filter(|c| c.name.starts_with("ngrx.service."))
    {
        matches.entry(c.match_index).or_default().insert(&c.name, c);
    }
    matches
        .values()
        .filter_map(|m| {
            let call = m.get("ngrx.service.call")?;
            let method = m.get("ngrx.service.method")?;
            let owner = m.get("ngrx.service.owner")?;
            let endpoint = constructors.iter().find(|r| {
                r.start_byte == call.start_byte
                    && r.file.as_deref() == Some(file)
                    && r.source_hash == hash
            })?;
            let action = endpoint.action_name.as_ref()?;
            let canonical = endpoint.owner_name.as_ref()?;
            let invocation = invocations.iter().find(|c| c.span() == span(call))?;
            let service = authoritative_service_owner(invocation, classes, source)?;
            if service.service.as_str() != canonical.as_str()
                || service.class_span != span(owner)
                || service.method_span != span(method)
            {
                return None;
            }
            Some(ServiceDispatch {
                start_byte: call.start_byte,
                service: service.service,
                action: action.clone(),
                file: file.into(),
                source_hash: hash.clone(),
                class_span: service.class_span,
                method_span: service.method_span,
            })
        })
        .collect()
}

/// Project precise Service occurrences, leaving all other existing occurrences
/// to the frozen Component/fallback producer. Never rewrite aggregate edges by
/// target spelling: one Action can also have an honest non-Service dispatch.
pub(crate) fn project(
    raw: super::NgRxShape,
    starts: &[usize],
    constructors: &[ConstructorDispatch],
    owners: &[ServiceDispatch],
    source: &str,
    file: &str,
) -> Vec<SemanticEdge> {
    let hash = crate::cache::content_hash(source.as_bytes());
    let admitted: Vec<_> = owners
        .iter()
        .filter(|o| {
            o.source_hash == hash
                && o.file == file
                && constructors.iter().any(|r| {
                    r.start_byte == o.start_byte
                        && r.source_hash == hash
                        && r.file.as_deref() == Some(file)
                        && r.owner_name.as_deref() == Some(&o.service)
                        && r.action_name.as_deref() == Some(&o.action)
                })
        })
        .collect();
    let mut remaining = constructors.to_vec();
    for r in &mut remaining {
        if admitted.iter().any(|o| o.start_byte == r.start_byte) {
            // Keep the suppression record; this occurrence is projected below.
            r.action_name = None;
        }
    }
    let fallback = super::constructors::apply(raw, starts, &remaining, source, file);
    let mut edges = fallback.to_ngrx_semantic_edges();
    edges.extend(admitted.into_iter().map(|o| SemanticEdge {
        subject: EntityRef::new("angular", "Service", &o.service),
        relation: SemanticRelation::Dispatches,
        object: EntityRef::new("ngrx", "Action", &o.action),
        layer: "ngrx",
        call_evidence: None,
    }));
    edges
}
