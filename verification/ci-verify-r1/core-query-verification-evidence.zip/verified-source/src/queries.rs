// src/queries.rs
// TypeScript AST node types: class_declaration, method_definition,
//   function_declaration, property_signature, throw_statement,
//   if_statement, for_statement, while_statement, return_statement,
//   import_statement, import_declaration
// C# AST node types: class_declaration, method_declaration,
//   interface_declaration, field_declaration, throw_statement,
//   for_statement, if_statement, while_statement,
//   return_statement, using_directive
//
// FAANG audit: expanded all queries to capture the full set of
// structural, control-flow, and Java/Rust-specific constructs.
// Every language now captures: class/enum/interface/record types,
// methods, fields, constructors, control flow, imports, and
// language-specific items (package, mod, macro, type alias, etc.).

pub const TS_QUERY: &str = r#"
    ; --- TypeScript/JavaScript structural captures ---
    ; Export ownership is represented by the export_statement wrapper while
    ; the declaration capture remains the canonical declaration node. The IR
    ; producer joins these captures by the child's exact source span.
    (export_statement (class_declaration) @export.class)
    (export_statement (abstract_class_declaration) @export.class)
    (export_statement (interface_declaration) @export.interface)
    (class_declaration) @class.root
    (abstract_class_declaration) @class.root
    (method_definition) @method.root
    (function_declaration) @func.root
    (property_signature) @field.root
    ; --- TypeScript class property captures ---
    ; Class properties are distinct AST nodes from interface property
    ; signatures. Without these captures, adding a property to a class
    ; produced a false negative in diff_commits. F-01 diff audit.
    ; NOTE: `public_field_definition` is a valid node type in
    ; tree-sitter-typescript v0.23. `property_definition` and
    ; `method_signature` were NOT — including them caused the entire
    ; TS query to fail to compile, which broke the diff path for every
    ; TypeScript file.
    (public_field_definition) @field.root
    ; --- TypeScript-specific type declarations ---
    (interface_declaration) @interface.root
    (enum_declaration) @enum.root
    (type_alias_declaration) @type.root
    ; --- Control flow captures ---
    (throw_statement) @throw.root
    (for_statement) @for.root
    (if_statement) @if.root
    (while_statement) @while.root
    (return_statement) @return.root
    ; --- Import captures ---
    (import_statement) @import.root
    ; --- Angular Meta-Layer forward-compat captures ---
    (decorator) @decorator.root
    (object) @object.root
"#;

pub const CS_QUERY: &str = r#"
    ; --- C# structural captures ---
    (class_declaration) @class.root
    (method_declaration) @method.root
    (interface_declaration) @interface.root
    (struct_declaration) @struct.root
    (enum_declaration) @enum.root
    (record_declaration) @record.root
    (field_declaration) @field.root
    ; Audit fix: capture enum variant members so the diff snapshot can
    ; detect additions/removals of enum values. Without this capture, enum
    ; variant changes are a false negative in diff_commits.
    (enum_member_declaration) @field.root
    (constructor_declaration) @constructor.root
    ; --- C# property/event/indexer/operator captures ---
    ; Properties are a distinct AST node from fields in C#. Without this
    ; capture, adding a property to a class produced a false negative in
    ; diff_commits (the class appeared unchanged). F-01 diff audit.
    (property_declaration) @field.root
    (event_declaration) @field.root
    (event_field_declaration) @field.root
    (indexer_declaration) @field.root
    (operator_declaration) @field.root
    (destructor_declaration) @field.root
    (conversion_operator_declaration) @field.root
    ; --- Control flow captures ---
    (throw_statement) @throw.root
    (for_statement) @for.root
    (if_statement) @if.root
    (while_statement) @while.root
    (do_statement) @do.root
    (return_statement) @return.root
    (switch_statement) @switch.root
    (try_statement) @try.root
    ; --- Import captures ---
    (using_directive) @import.root
"#;

// Generic invocation captures (native call facts) for C#.
//
// These patterns are deliberately NOT part of `CS_QUERY`: the compression and
// diff paths (`compress_file`, `build_snapshot`) consume `CS_QUERY` captures
// positionally and would otherwise gain unknown capture names. The IR
// compilation path concatenates this query onto its base query and walks both
// in ONE tree-sitter parse (see `crate::ir::calls`).
//
// Structure, not text: each invocation form binds the NAME node that is
// written at the call site (`@call.callee`) and, in the second pattern of each
// pair, every individual `argument` node (`@call.argument`). The explicit
// argument count is therefore the number of observed argument nodes — never a
// `split(',')`, regex, or line scan — so nested commas inside generic
// arguments, object creations, lambdas, and array initializers can never
// inflate it.
//
// Both patterns of a pair are required: the argument-less pattern enumerates
// invocations with ZERO arguments (`Foo()`), and the argument pattern
// enumerates their arity. `match_index` groups the captures of one query
// match so the producer can associate each argument with its callee.
//
// `function:` is the invocation's function node and `name:` is a member
// access's final name node, so `items.OrderBy(a, b)` yields the callee
// `OrderBy` with argc 2 — the receiver is never part of the argument list.
// Unsupported function shapes (conditional access `a?.Foo()`, parenthesized
// and cast expressions) are deliberately not matched: an unmatched form
// produces no fact rather than a guessed one.
// C#-specific semantic captures consumed only by the IR compiler.
//
// This query is deliberately separate from `CS_QUERY`: compression and diff
// consumers share that base query and must not observe semantic-only capture names.
// The IR capture walk appends this query and `CS_CALL_QUERY` to the same
// tree-sitter query, preserving the single-parse production invariant.
pub const CS_SEMANTIC_QUERY: &str = r#"
    ; Namespace scopes are captured structurally so semantic resolution never
    ; reconstructs lexical ownership from strings.
    (namespace_declaration) @csharp.namespace_root
    (file_scoped_namespace_declaration) @csharp.namespace_root
    (namespace_declaration name: (_) @csharp.namespace_name)
    (file_scoped_namespace_declaration name: (_) @csharp.namespace_name)
    ; Declaration identifiers are the single C# canonical/builtin name authority.
    (class_declaration name: (identifier) @csharp.class_name)
    (interface_declaration name: (identifier) @csharp.interface_name)
    (struct_declaration name: (identifier) @csharp.struct_name)
    (enum_declaration name: (identifier) @csharp.enum_name)
    (record_declaration name: (identifier) @csharp.record_name)
    (type_parameter_list) @csharp.type_parameters
    ; Direct declaration ownership is retained through the query match identity.
    (class_declaration
        (type_parameter_list
            (type_parameter) @csharp.class_type_parameter)) @csharp.generic_class
    ; Class/struct/interface base lists expose entries through the type supertype.
    (base_list (type) @csharp.base_type)
    ; record_base is aliased to base_list. Capture each direct named child
    ; without guessing which concrete _name form the grammar selected.
    (record_declaration
        (base_list
            (_) @csharp.record_base_candidate))
    ; A positional record may invoke its record base constructor. Capture only
    ; the typed name field. Projection suppresses the enclosing candidate by
    ; span, so constructor arguments never enter the written type.
    (record_declaration
        (base_list
            (primary_constructor_base_type
                type: (_) @csharp.base_type)))
    ; Attribute identity remains neutral. The R0 collector separates the
    ; written name from any argument payload without assigning framework meaning.
    (attribute) @csharp.attribute
    ; Declaration attributes are captured separately so resolution can attach
    ; them to their owning class without confusing method/property attributes.
    (class_declaration
        (attribute_list
            (attribute) @csharp.class_attribute))
    ; Method attributes retain their declaration owner so framework consumers
    ; can authorize action semantics without scanning written class text.
    (method_declaration
        (attribute_list
            (attribute) @csharp.method_attribute))
"#;

pub const CS_CALL_QUERY: &str = r#"
    ; --- Generic invocation captures (native call facts) ---
    (invocation_expression
        function: (identifier) @call.callee
        arguments: (argument_list))
    (invocation_expression
        function: (identifier) @call.callee
        arguments: (argument_list (argument) @call.argument))
    (invocation_expression
        function: (member_access_expression name: (identifier) @call.callee)
        arguments: (argument_list))
    (invocation_expression
        function: (member_access_expression name: (identifier) @call.callee)
        arguments: (argument_list (argument) @call.argument))
    (invocation_expression
        function: (generic_name (identifier) @call.callee)
        arguments: (argument_list))
    (invocation_expression
        function: (generic_name (identifier) @call.callee)
        arguments: (argument_list (argument) @call.argument))
    (invocation_expression
        function: (member_access_expression name: (generic_name (identifier) @call.callee))
        arguments: (argument_list))
    (invocation_expression
        function: (member_access_expression name: (generic_name (identifier) @call.callee))
        arguments: (argument_list (argument) @call.argument))
    ; --- Private source-bound invocation evidence (same parse) ---
    (invocation_expression) @invoke.root
    (invocation_expression function: (_) @invoke.function) @invoke.root
    (invocation_expression function: (identifier) @invoke.terminal) @invoke.root
    (invocation_expression function: (generic_name
        (identifier) @invoke.terminal
        (type_argument_list (type) @invoke.type_argument))) @invoke.root
    (invocation_expression function: (generic_name
        (identifier) @invoke.terminal)) @invoke.root
    (invocation_expression function: (member_access_expression
        expression: (_) @invoke.receiver
        name: (identifier) @invoke.terminal)) @invoke.root
    (invocation_expression function: (member_access_expression
        expression: (_) @invoke.receiver
        name: (generic_name (identifier) @invoke.terminal))) @invoke.root
    (invocation_expression function: (member_access_expression
        name: (generic_name (type_argument_list (type) @invoke.type_argument)))) @invoke.root
    (invocation_expression arguments: (argument_list
        (argument name: (identifier)? @invoke.argument_name) @invoke.argument)) @invoke.root
    (method_declaration name: (identifier) @invoke.declaration_name)
        @invoke.declaration @invoke.declaration.callable
    (constructor_declaration name: (identifier) @invoke.declaration_name)
        @invoke.declaration @invoke.declaration.callable
    (local_function_statement name: (identifier) @invoke.declaration_name)
        @invoke.declaration @invoke.declaration.callable
    (local_declaration_statement (variable_declaration
        (variable_declarator name: (identifier) @invoke.declaration_name
            "=" (_)) @invoke.declaration @invoke.declaration.variable))
    (field_declaration (variable_declaration
        (variable_declarator name: (identifier) @invoke.declaration_name
            "=" (_)) @invoke.declaration @invoke.declaration.field))
    (property_declaration name: (identifier) @invoke.declaration_name
        "=" value: (_)) @invoke.declaration @invoke.declaration.property
    (property_declaration name: (identifier) @invoke.declaration_name
        (arrow_expression_clause)) @invoke.declaration @invoke.declaration.property
"#;

// Generic invocation captures (native call facts) for TypeScript.
//
// Exactly the `CS_CALL_QUERY` contract, expressed in TypeScript grammar:
// deliberately NOT part of `TS_QUERY` (so the compression and diff paths, which
// consume `TS_QUERY` captures positionally, can never observe a call capture),
// and structural — the callee NAME node plus one capture per explicitly written
// argument — so the observed arity is never derived from `split(',')`, a regex,
// a line scan, or a second parse.
//
// TypeScript invocation syntax maps onto the existing normalized fact:
//   * `foo(...)`      -> callee `foo`   (identifier)
//   * `this.foo(...)` -> callee `foo`   (member property; the receiver is
//                        never an argument and never enters the count)
//   * `foo<T>(...)`   -> callee `foo`   (`type_arguments` is a sibling field of
//                        the call, never part of the name)
//   * `foo(...args)`  -> one explicitly written argument (spread element)
//
// Both patterns of a pair are required: the argument-less pattern enumerates
// invocations with ZERO arguments (`foo()`), and the argument patterns
// enumerate their arity. `match_index` groups the captures of one query match
// so the producer can associate each argument with its callee.
//
// A spread element binds `@call.spread`, not `@call.argument`: it is still ONE
// written argument, but it also expands at run time, so the invocation's
// written count is no longer an exact arity. The producer records it as one
// argument AND qualifies the fact (`has_spread`), which is what keeps
// `foo(a)` and `foo(...args)` distinguishable even though both write one
// argument node.
//
// Unmatched forms emit NO fact rather than a guessed one, and they belong to
// two clearly different classes:
//
// SEMANTIC / MODEL BOUNDARIES — the current normalized fact cannot express
// them (not a parsing gap):
//   * `new Foo(...)` is a `new_expression`: object creation, not an invocation
//     of a named method. The callee would be the constructed TYPE, and the
//     `Calls` model is method-name-level (`builtin` / `Method` entities), so
//     construction is out of scope rather than unmatched.
//   * tagged template calls (`tag` + backtick) carry a `template_string` in
//     their `arguments` field — a substitution tuple, not an argument list.
//     The normalized fact counts explicitly written argument nodes in an
//     `arguments` list, which such a call does not have.
//   * an invocation with no precisely identified callable owner (a PLAIN
//     property initializer such as `x = foo()`, a top-level statement, an
//     anonymous arrow body): the caller must be a real callable declaration
//     id, so ownership is never guessed.
//
// CURRENT PRODUCER COVERAGE GAPS — recoverable later; these are NOT claims
// that the forms are unrepresentable:
//   * computed member calls with a non-literal property: `foo[bar]()` is a
//     `subscript_expression` and has no statically written callee name. The
//     literal form `foo["save"]()` IS structurally recoverable — it is a
//     coverage gap of these patterns, not a property of the model.
//   * `#private` member calls: `this.#save()` names its callee precisely (a
//     `private_property_identifier`); the patterns above simply do not bind
//     that node kind yet.
//   * an arrow expression whose binding carries NO stable name: an inline
//     callback argument (`items.map(x => transform(x))`), an object-literal
//     property (`{ next: tp => save(tp) }`), an IIFE, or a `this.load = () =>
//     ...` assignment. Such an arrow establishes no callable scope of its own,
//     so an invocation inside it is owned by the innermost enclosing
//     RECOGNIZED callable instead — the inheritance that already makes
//     `load() { source.subscribe({ next: tp => save(tp) }); }` publish
//     `load --Calls--> save`. That behavior is confirmed and preserved on
//     purpose, so object-literal property arrows are deliberately NOT
//     callable owners.
//
// Arrow DECLARATIONS whose binding carries a directly recoverable name DO own
// their calls (the last two patterns of this query; see also
// `src/ir/calls.rs`, which joins their captures by query-match identity, and
// `src/ir/pipeline/core.rs`, which registers the callable declaration):
//
//   * `const load = () => save();`         -> callable `load`
//   * `let refresh = () => update();`      -> callable `refresh`
//   * `class C { load = () => save(); }`   -> callable `load`
//   * `private handle = () => save();`, `readonly refresh = async () =>
//     fetchData()`, `load: Handler = (v: Item) => save(v)`, and generic arrows
//     (`load = <T>(v: T) => save(v)`) are the SAME declaration shape:
//     modifiers, the type annotation, type parameters and `async` are
//     siblings of the value, and a concise expression body is a body like any
//     other, so none of them changes the callable identity.
//
// Both captures of one declaration belong to ONE query match, and the name
// node always precedes the arrow node in document order — the order this walk
// visits them — so the producer associates them structurally, never by text
// scanning.
//
// `name: (identifier)` and `name: (property_identifier)` are deliberately
// narrow. Computed (`[key]`), numeric, string and `#private` property names,
// every destructuring binding (`const { load } = makeHandlers()`,
// `const [fn] = ...`) and assignment targets (`this.load = () => ...`) have no
// stable written identifier for this model, so they are structurally EXCLUDED
// rather than repaired by text extraction.
pub const TS_CALL_QUERY: &str = r#"
    ; --- Generic invocation captures (native call facts) ---
    (call_expression
        function: (identifier) @call.callee
        arguments: (arguments))
    (call_expression
        function: (identifier) @call.callee
        arguments: (arguments (expression) @call.argument))
    (call_expression
        function: (identifier) @call.callee
        arguments: (arguments (spread_element) @call.spread))
    (call_expression
        function: (member_expression property: (property_identifier) @call.callee)
        arguments: (arguments))
    (call_expression
        function: (member_expression property: (property_identifier) @call.callee)
        arguments: (arguments (expression) @call.argument))
    (call_expression
        function: (member_expression property: (property_identifier) @call.callee)
        arguments: (arguments (spread_element) @call.spread))
    ; --- Callable identity for BOUND ARROWS (native call facts) ---
    ; One pattern per declaration form. `@arrow.name` is the stable written
    ; owner name, `@arrow.root` is the arrow declaration whose source span owns
    ; every invocation inside it. Both captures ride ONE query match, so the
    ; producer joins them by match identity (never by text scanning).
    ; `value: (arrow_function)` is a concrete subtype of the `value` field's
    ; `expression` supertype — the same structural idiom the invocation
    ; patterns above already use for `call_expression.function`.
    (variable_declarator
        name: (identifier) @arrow.name
        value: (arrow_function) @arrow.root)
    (public_field_definition
        name: (property_identifier) @arrow.name
        value: (arrow_function) @arrow.root)
    ; --- Private source-bound invocation evidence (same parse) ---
    (call_expression) @invoke.root
    (call_expression function: (_) @invoke.function) @invoke.root
    (call_expression function: (identifier) @invoke.terminal) @invoke.root
    (call_expression function: (member_expression
        object: (_) @invoke.receiver
        property: (property_identifier) @invoke.terminal)) @invoke.root
    (call_expression arguments: (arguments
        [(expression) (spread_element)] @invoke.argument)) @invoke.root
    (call_expression arguments: (arguments
        (spread_element) @invoke.spread)) @invoke.root
    (call_expression type_arguments: (type_arguments
        (type) @invoke.type_argument)) @invoke.root
    (variable_declarator
        name: (identifier) @invoke.declaration_name
        value: (_)) @invoke.declaration @invoke.declaration.variable
    (public_field_definition
        name: (property_identifier) @invoke.declaration_name
        value: (_)) @invoke.declaration @invoke.declaration.field
    (method_definition) @invoke.declaration @invoke.declaration.callable
    (method_definition
        name: (property_identifier) @invoke.declaration_name) @invoke.declaration @invoke.declaration.callable
    (function_declaration) @invoke.declaration @invoke.declaration.callable
    (function_declaration
        name: (identifier) @invoke.declaration_name) @invoke.declaration @invoke.declaration.callable
    (variable_declarator
        name: (identifier) @invoke.declaration_name
        value: (arrow_function) @invoke.declaration @invoke.declaration.callable)
    (public_field_definition
        name: (property_identifier) @invoke.declaration_name
        value: (arrow_function) @invoke.declaration @invoke.declaration.callable)

"#;

// Generic invocation captures (native call facts) for Java.
//
// Exactly the `CS_CALL_QUERY` contract, expressed in Java grammar: deliberately
// NOT part of `JAVA_QUERY` (so the compression and diff paths can never observe
// a call capture), and structural — the callee NAME node plus one capture per
// explicitly written argument — so the observed arity is never derived from
// `split(',')`, a regex, a line scan, or a second parse.
//
// Java's `method_invocation` carries the callee name in its `name` field for
// BOTH receiver-less (`foo(...)`) and receiver-ful (`obj.foo(...)`,
// `this.foo(...)`, `super.foo(...)`) forms, so one pair of patterns covers
// every invocation shape. `type_arguments` is a sibling field, so `foo<T>(...)`
// yields the callee `foo`.
//
// Unmatched forms emit NO fact rather than a guessed one, and they belong to
// two clearly different classes:
//
// SEMANTIC / MODEL BOUNDARIES — the current normalized fact cannot express
// them (not a parsing gap):
//   * `new Foo(...)` is an `object_creation_expression`: object creation is not
//     an invocation of a named method, and the `Calls` model is method-name-
//     level (`builtin` / `Method` entities), so construction is out of scope.
//   * `super(...)` / `this(...)` is an `explicit_constructor_invocation`, which
//     has no `name` field at all — it is a constructor invocation, not a named
//     method call.
//   * a method reference (`Foo::bar`) is a method VALUE, never an invocation.
//   * an invocation with no precisely identified callable owner (a field
//     initializer, a static initializer): the caller must be a real callable
//     declaration id, so ownership is never guessed.
//
// CURRENT PRODUCER COVERAGE GAPS: none inside `method_invocation` — the callee
// is always the required `name` identifier, so the pair of patterns above
// covers every invocation shape (receiver-less, `this.`, `super.`, `obj.`, and
// explicit type-argument forms alike).
pub const JAVA_CALL_QUERY: &str = r#"
    ; --- Generic invocation captures (native call facts) ---
    (method_invocation
        name: (identifier) @call.callee
        arguments: (argument_list))
    (method_invocation
        name: (identifier) @call.callee
        arguments: (argument_list (expression) @call.argument))
"#;

// Rust AST node types: struct_item, enum_item, trait_item, impl_item,
//   function_item, type_item, field_declaration, use_declaration,
//   return_expression, if_expression, for_expression, while_expression,
//   match_expression, macro_invocation, mod_item
pub const RS_QUERY: &str = r#"
    ; Core structural captures
    (struct_item) @struct.root
    (enum_item) @enum.root
    (trait_item) @trait.root
    (impl_item) @impl.root
    (function_item) @method.root
    (type_item) @type.root
    (field_declaration) @field.root
    ; Enum variants are distinct AST nodes. Without this capture, adding
    ; or removing a variant produced a false negative in diff_commits.
    ; F-01 diff audit.
    (enum_variant) @field.root
    ; Import and module captures
    (use_declaration) @import.root
    (mod_item) @mod.root
    ; Control flow captures
    (return_expression) @return.root
    (if_expression) @if.root
    (for_expression) @for.root
    (while_expression) @while.root
    (match_expression) @match.root
    (loop_expression) @loop.root
    ; Exception / panic captures
    (macro_invocation
        macro: (identifier) @_panic_macro
        (#match? @_panic_macro "panic|unreachable|unimplemented|todo|assert")
    ) @throw.root
    ; Macro captures
    (macro_invocation) @macro.root
"#;

// Generic invocation captures (native call facts) for Rust.
//
// Rust represents both free-function calls and method calls as
// `call_expression`; a method call's function is a `field_expression`, whose
// final `field_identifier` is the written callee name. Each named child of the
// `arguments` node is one explicitly written argument. Macro invocations are a
// different node type and deliberately remain outside this contract.
pub const RS_CALL_QUERY: &str = r#"
    ; --- Generic invocation captures (native call facts) ---
    (call_expression
        function: (identifier) @call.callee
        arguments: (arguments))
    (call_expression
        function: (identifier) @call.callee
        arguments: (arguments (_) @call.argument))
    (call_expression
        function: (field_expression
            field: (field_identifier) @call.callee)
        arguments: (arguments))
    (call_expression
        function: (field_expression
            field: (field_identifier) @call.callee)
        arguments: (arguments (_) @call.argument))
"#;

// Java AST node types: class_declaration, interface_declaration,
//   method_declaration, constructor_declaration, field_declaration,
//   constant_declaration,
//   enum_declaration, record_declaration, import_declaration,
//   package_declaration, if_statement, for_statement, while_statement,
//   do_statement, return_statement, throw_statement, try_statement,
//   switch_expression
pub const JAVA_QUERY: &str = r#"
    ; Core structural captures
    (class_declaration) @class.root
    (interface_declaration) @interface.root
    (enum_declaration) @enum.root
    (record_declaration) @record.root
    (method_declaration) @method.root
    (constructor_declaration) @constructor.root
    (field_declaration) @field.root
    (constant_declaration) @field.root
    ; Import and package
    (import_declaration) @import.root
    (package_declaration) @package.root
    ; Control flow captures
    (if_statement) @if.root
    (for_statement) @for.root
    (while_statement) @while.root
    (do_statement) @do.root
    (return_statement) @return.root
    (throw_statement) @throw.root
    (try_statement) @try.root
    ; Audit fix: tree-sitter-java uses `switch_expression` (not
    ; `switch_statement`) since Java 14 unified switch expression syntax.
    (switch_expression) @switch.root
"#;

pub(crate) mod core_ir;
