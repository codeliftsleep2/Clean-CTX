// src/layers/meta/mod.rs
//
// MetaLayer trait + per-framework implementations.
// Each implementation is gated by its Cargo feature so the framework-specific
// code is only compiled when the feature is enabled.
//
// # Preferred pattern for new meta-layers
//
// New meta-layers SHOULD follow the decentralized .NET pattern:
//   - Define the MetaLayer struct + MetaLayer trait impl in the meta-layer's
//     own module (e.g. `src/dotnet_meta/mod.rs`)
//   - Register it in `src/layers/registry.rs` with a `#[cfg(feature = "...")]` guard
//   - The decentralized approach keeps the meta-layer's code co-located with
//     its detection, extraction, and marker logic
//
// Legacy: Angular and Spring Boot meta-layers have their trait impls directly
// in this file for historical reasons. New meta-layers should NOT follow
// this pattern.

#[cfg(feature = "angular")]
pub(crate) mod angular_applicability;
#[cfg(feature = "angular")]
mod angular_semantic;
pub mod builtin;
pub(crate) mod canonical_endpoint;
mod context;
pub mod semantic;

pub use context::MetaLayerOwnedEvaluation;
pub use context::{MetaLayerContext, MetaLayerEvaluation, StructuredClassBase};
pub(crate) mod resolver_registrations;

use crate::compression::Fidelity;
use crate::config::CleanCtxConfig;
use crate::layers::meta::semantic::SemanticEdge;
use std::path::Path;

/// Increment marker and semantic generations independently when identical
/// Angular inputs change that producer's durable markers or semantic edges.
#[cfg(feature = "angular")]
pub(crate) const ANGULAR_MARKER_PRODUCER_GENERATION: u32 = 6;
#[cfg(feature = "angular")]
pub(crate) const ANGULAR_SEMANTIC_PRODUCER_GENERATION: u32 = 79;

/// Structured output of a single meta-layer pass.
///
/// This replaces the previous render-then-reparse anti-pattern where
/// `enrich` wrote a rendered `String` and the pipeline re-parsed it back
/// into a structured `MetaBlock` by string-splitting on `// ---` headers.
///
/// Each layer produces its structured block (if any) plus the rendered
/// text. The pipeline uses the structured block directly; the rendered
/// text is retained for consumers that only need the flat string
/// (e.g. the IR compiler's `TypeAlias` enrichment).
#[derive(Debug, Clone, Default)]
pub struct MetaLayerOutput {
    /// The layer that produced this output (e.g. "angular").
    pub layer_name: &'static str,
    /// The fully-rendered `Φ` block text (empty when the layer produced
    /// no markers for this file).
    pub rendered: String,
    /// Structured Angular block (decorators plus ecosystem sections including
    /// RxJS, NgRx, Signals, Routing, Forms, Formly, and Testing). `None` when
    /// the file is not Angular.
    pub angular_block: Option<crate::angular_meta::MetaBlock>,
    /// Structured Spring Boot block. `None` when not a Spring file.
    pub spring_block: Option<crate::spring_meta::MetaBlock>,
    /// Structured .NET block. `None` when not a .NET file.
    pub dotnet_block: Option<crate::dotnet_meta::MetaBlock>,
}

/// A meta-layer that enriches compressed output with framework-specific
/// context (e.g. Angular decorators, Spring Boot annotations).
///
/// Meta-layers are purely additive: they append framework-specific markers
/// to the compressed output without modifying the base compression.
pub trait MetaLayer: Send + Sync {
    /// Unique identifier (e.g. "angular", "spring_boot").
    fn name(&self) -> &'static str;

    /// Check if this meta-layer applies to the given source file.
    /// Called before `enrich` to avoid unnecessary work.
    ///
    /// `config` is optional so the layer can honor its per-framework
    /// `enabled` flag (a disabled layer returns `false`, skipping
    /// detection entirely — zero overhead).
    fn is_applicable(&self, source: &str, path: &Path, config: Option<&CleanCtxConfig>) -> bool;

    /// Enrich the compressed output with framework-specific markers.
    ///
    /// Returns `Some(MetaLayerOutput)` when the layer produced markers for
    /// this file, `None` when it produced none (zero overhead).
    ///
    /// # Arguments
    /// - `source`: The full source text of the file being compressed.
    /// - `class_captures`: The canonical source spans of each type capture
    ///   (class/interface/enum/record/struct), in document order. Each span
    ///   is the exact text of that type's declaration including leading
    ///   decorators/annotations/attributes and the full body. The meta-layer
    ///   must NEVER inspect text outside the owning class span — this is the
    ///   per-class metadata invariant.
    /// - `fidelity`: The fidelity level controlling verbosity.
    /// - `config`: The project config (optional) so per-layer `enabled`
    ///   flags and sub-layer settings are honored.
    fn enrich(
        &self,
        source: &str,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput>;

    /// Path-aware enrichment hook. Existing layers retain their exact
    /// behavior through default forwarding; layers with authorized filename
    /// semantics may override this method.
    fn enrich_with_path(
        &self,
        source: &str,
        _path: &Path,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput> {
        self.enrich(source, class_captures, fidelity, config)
    }

    /// Extract structured semantic edges for the given source file.
    ///
    /// Legacy text-only contract. Framework meta-layers implement this from
    /// the class-source spans; the always-on `BuiltinMetaLayer` uses
    /// [`Self::extract_semantic_edges_paired`] instead.
    ///
    /// Returns an empty vector by default -- meta-layers are NOT required
    /// to produce semantic edges. Semantic edges are structural facts
    /// (implicit confidence 1.0) discovered by the same per-framework
    /// helpers that produce the Phi markers; `enrich()` output is
    /// unchanged. No plugin feeds these yet (Phase 1+); the default keeps
    /// every existing layer behavior-identical.
    fn extract_semantic_edges(
        &self,
        _source: &str,
        _class_captures: &[String],
        _fidelity: Fidelity,
        _config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        Vec::new()
    }

    /// Extract structured semantic edges with capture-type information.
    ///
    /// `class_captures` is a slice of `(capture_name, capture_text)` pairs —
    /// the capture identity (e.g. `"class.root"`, `"interface.root"`,
    /// `"trait.root"`) paired with the class-source span. The default
    /// implementation forwards to [`Self::extract_semantic_edges`] after
    /// discarding the capture names, so framework layers keep their
    /// existing text-only contract; only layers that need the capture type
    /// (the always-on `BuiltinMetaLayer`) override this method.
    fn extract_semantic_edges_paired(
        &self,
        source: &str,
        class_captures: &[(String, String)],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        let texts: Vec<String> = class_captures
            .iter()
            .map(|(_, text)| text.clone())
            .collect();
        self.extract_semantic_edges(source, &texts, fidelity, config)
    }

    /// Path-aware semantic extraction hook with backward-compatible default
    /// forwarding for layers whose semantics do not depend on filenames.
    fn extract_semantic_edges_paired_with_path(
        &self,
        source: &str,
        _path: &Path,
        class_captures: &[(String, String)],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        self.extract_semantic_edges_paired(source, class_captures, fidelity, config)
    }

    /// Evaluate one applicable layer through one compilation boundary.
    fn evaluate_context(&self, context: &MetaLayerContext<'_>) -> MetaLayerEvaluation {
        MetaLayerEvaluation {
            output: self.enrich_with_path(
                context.source,
                context.path,
                context.class_captures,
                context.fidelity,
                context.config,
            ),
            semantic_edges: self.extract_semantic_edges_paired_with_path(
                context.source,
                context.path,
                context.paired_class_captures,
                context.fidelity,
                context.config,
            ),
            semantic_dependencies: Vec::new(),
        }
    }

    /// Owned semantic side outputs share this same evaluation, without changing
    /// existing implementors or the legacy public evaluation struct.
    fn evaluate_owned_if_applicable(
        &self,
        context: &MetaLayerContext<'_>,
    ) -> Option<MetaLayerOwnedEvaluation> {
        self.evaluate_if_applicable(context).map(Into::into)
    }

    /// Decide applicability and evaluate without discarding detection evidence.
    fn evaluate_if_applicable(
        &self,
        context: &MetaLayerContext<'_>,
    ) -> Option<MetaLayerEvaluation> {
        self.is_applicable(context.source, context.path, context.config)
            .then(|| self.evaluate_context(context))
    }
}

// ── Angular Meta-Layer ────────────────────────────────────────────────

#[cfg(feature = "angular")]
pub struct AngularMetaLayer;

#[cfg(feature = "angular")]
impl AngularMetaLayer {
    pub fn new() -> Self {
        Self
    }
}

#[cfg(feature = "angular")]
impl Default for AngularMetaLayer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(feature = "angular")]
impl MetaLayer for AngularMetaLayer {
    fn name(&self) -> &'static str {
        "angular"
    }

    fn is_applicable(&self, source: &str, _path: &Path, config: Option<&CleanCtxConfig>) -> bool {
        // Honor the per-framework `enabled` flag. When the config is
        // absent or the "angular" entry is missing, the layer is on
        // (default behaviour).
        let enabled = config
            .and_then(|c| c.meta_layers.get("angular"))
            .map(|m| m.enabled)
            .unwrap_or(true);
        if !enabled {
            return false;
        }

        // Delegate to the existing Angular detection heuristic, plus the
        // Angular Ecosystem Deepening import gates. Pure NgRx actions/
        // selectors files, routing config files (app.routes.ts), and
        // standalone RxJS services have no @Component/@Injectable
        // decorators — they must still pass the gate so the pipeline
        // enriches them. The per-layer extractors apply their own
        // import-gate checks internally, so false positives here are
        // cheap (zero output, zero overhead).
        let testing_enabled = config
            .and_then(|c| c.meta_layers.get("angular"))
            .map(|m| m.testing.enabled)
            .unwrap_or(true);
        let reactive_forms_enabled = config
            .and_then(|c| c.meta_layers.get("angular"))
            .map(|m| m.reactive_forms.enabled)
            .unwrap_or(true);
        let formly_enabled = config
            .and_then(|c| c.meta_layers.get("angular"))
            .map(|m| m.formly.enabled)
            .unwrap_or(true);
        crate::angular_meta::detect::is_angular_file(source)
            || crate::angular_meta::rx::has_rxjs_imports(source)
            || crate::angular_meta::ngrx::has_ngrx_imports(source)
            || crate::angular_meta::signals::has_signal_imports(source)
            || reactive_forms_enabled
                && crate::angular_meta::reactive_forms::has_reactive_forms(source)
            || formly_enabled && crate::angular_meta::formly::has_formly(source)
            || crate::angular_meta::routing::has_router_imports(source)
            || testing_enabled && crate::angular_meta::testing::is_testing_source(source, _path)
    }

    fn enrich(
        &self,
        source: &str,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput> {
        self.enrich_with_path(source, Path::new(""), class_captures, fidelity, config)
    }

    fn enrich_with_path(
        &self,
        source: &str,
        path: &Path,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput> {
        // Honor the per-framework meta-layer config (enabled flags,
        // min_pipe_operators, include_dispatch_sites, etc.). When the
        // config is absent or the "angular" entry is missing, all
        // sub-layers run with their defaults.
        let meta_config = config.and_then(|c| c.meta_layers.get("angular"));
        let block = crate::angular_meta::run_meta_layer_with_config_and_path(
            source,
            class_captures,
            fidelity,
            meta_config,
            path,
        )?;
        if block.is_empty() {
            return None;
        }
        Some(MetaLayerOutput {
            layer_name: self.name(),
            rendered: block.render(),
            angular_block: Some(block),
            spring_block: None,
            dotnet_block: None,
        })
    }

    fn extract_semantic_edges(
        &self,
        source: &str,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        let meta_config = config.and_then(|c| c.meta_layers.get("angular"));
        let mut edges = angular_semantic::extract_non_testing_edges(
            source,
            class_captures,
            fidelity,
            config,
            None,
            Default::default(),
        );

        let testing_enabled = meta_config.map(|c| c.testing.enabled).unwrap_or(true);
        if testing_enabled {
            edges.extend(
                crate::angular_meta::testing::extract_testing_semantic_edges(source, Path::new("")),
            );
        }

        edges
    }

    fn extract_semantic_edges_paired_with_path(
        &self,
        source: &str,
        path: &Path,
        class_captures: &[(String, String)],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        let captures: Vec<String> = class_captures
            .iter()
            .map(|(_, text)| text.clone())
            .collect();
        let mut edges = angular_semantic::extract_non_testing_edges(
            source,
            &captures,
            fidelity,
            config,
            Some(path),
            Default::default(),
        );
        let testing_enabled = config
            .and_then(|value| value.meta_layers.get("angular"))
            .map(|value| value.testing.enabled)
            .unwrap_or(true);
        if testing_enabled {
            edges
                .extend(crate::angular_meta::testing::extract_testing_semantic_edges(source, path));
        }
        edges
    }

    fn evaluate_context(&self, context: &MetaLayerContext<'_>) -> MetaLayerEvaluation {
        angular_semantic::evaluate(self.name(), context, None)
    }

    fn evaluate_owned_if_applicable(
        &self,
        context: &MetaLayerContext<'_>,
    ) -> Option<MetaLayerOwnedEvaluation> {
        angular_applicability::evaluate_if_applicable(self.name(), context)
    }

    fn evaluate_if_applicable(
        &self,
        context: &MetaLayerContext<'_>,
    ) -> Option<MetaLayerEvaluation> {
        angular_applicability::evaluate_if_applicable(self.name(), context)
            .map(|owned| owned.evaluation)
    }
}

#[cfg(not(feature = "angular"))]
pub struct AngularMetaLayer;

#[cfg(not(feature = "angular"))]
impl AngularMetaLayer {
    pub fn new() -> Self {
        Self
    }
}

#[cfg(not(feature = "angular"))]
impl Default for AngularMetaLayer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(not(feature = "angular"))]
impl MetaLayer for AngularMetaLayer {
    fn name(&self) -> &'static str {
        "angular"
    }

    fn is_applicable(&self, _source: &str, _path: &Path, _config: Option<&CleanCtxConfig>) -> bool {
        false
    }

    fn enrich(
        &self,
        _source: &str,
        _class_captures: &[String],
        _fidelity: Fidelity,
        _config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput> {
        // No-op when feature is disabled
        None
    }
}

// ── Spring Boot Meta-Layer ────────────────────────────────────────────

#[cfg(feature = "spring_boot")]
pub struct SpringBootMetaLayer;

#[cfg(feature = "spring_boot")]
impl SpringBootMetaLayer {
    pub fn new() -> Self {
        Self
    }
}

#[cfg(feature = "spring_boot")]
impl Default for SpringBootMetaLayer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(feature = "spring_boot")]
impl MetaLayer for SpringBootMetaLayer {
    fn name(&self) -> &'static str {
        "spring_boot"
    }

    fn is_applicable(&self, source: &str, _path: &Path, _config: Option<&CleanCtxConfig>) -> bool {
        // Delegate to the existing Spring Boot detection heuristic
        crate::spring_meta::detect::is_spring_file(source)
    }

    fn enrich(
        &self,
        source: &str,
        class_captures: &[String],
        fidelity: Fidelity,
        _config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput> {
        let block = crate::spring_meta::run_meta_layer(source, class_captures, fidelity)?;
        if block.is_empty() {
            return None;
        }
        Some(MetaLayerOutput {
            layer_name: self.name(),
            rendered: block.render(),
            angular_block: None,
            spring_block: Some(block),
            dotnet_block: None,
        })
    }

    fn extract_semantic_edges(
        &self,
        _source: &str,
        class_captures: &[String],
        fidelity: Fidelity,
        _config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        let mut edges = Vec::new();
        for raw_class in class_captures {
            edges.extend(crate::spring_meta::semantic::extract_spring_semantic_edges(
                raw_class, fidelity,
            ));
        }
        edges
    }

    fn evaluate_context(&self, context: &MetaLayerContext<'_>) -> MetaLayerEvaluation {
        #[cfg(test)]
        crate::spring_meta::record_evaluation();

        let output = crate::spring_meta::run_meta_layer_for_applicable_source(
            context.class_captures,
            context.fidelity,
        )
        .filter(|block| !block.is_empty())
        .map(|block| MetaLayerOutput {
            layer_name: self.name(),
            rendered: block.render(),
            spring_block: Some(block),
            ..Default::default()
        });
        MetaLayerEvaluation {
            output,
            semantic_edges: self.extract_semantic_edges_paired_with_path(
                context.source,
                context.path,
                context.paired_class_captures,
                context.fidelity,
                context.config,
            ),
            semantic_dependencies: Vec::new(),
        }
    }
}

#[cfg(not(feature = "spring_boot"))]
pub struct SpringBootMetaLayer;

#[cfg(not(feature = "spring_boot"))]
impl SpringBootMetaLayer {
    pub fn new() -> Self {
        Self
    }
}

#[cfg(not(feature = "spring_boot"))]
impl Default for SpringBootMetaLayer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(not(feature = "spring_boot"))]
impl MetaLayer for SpringBootMetaLayer {
    fn name(&self) -> &'static str {
        "spring_boot"
    }

    fn is_applicable(&self, _source: &str, _path: &Path, _config: Option<&CleanCtxConfig>) -> bool {
        false
    }

    fn enrich(
        &self,
        _source: &str,
        _class_captures: &[String],
        _fidelity: Fidelity,
        _config: Option<&CleanCtxConfig>,
    ) -> Option<MetaLayerOutput> {
        // No-op when feature is disabled
        None
    }
}
