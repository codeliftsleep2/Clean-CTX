//! Shared non-testing Angular semantic projection.

use crate::compression::Fidelity;
use crate::config::CleanCtxConfig;
use crate::layers::meta::semantic::SemanticEdge;

#[derive(Default)]
pub(super) struct ProjectionEvidence<'a> {
    #[cfg(feature = "typescript")]
    typescript_authority: Option<&'a crate::ir::typescript_resolution::TypeScriptAuthority>,
    resolver_registrations:
        Option<&'a mut Option<super::resolver_registrations::ResolverRegistrations>>,
    module_dependencies: Option<&'a mut Vec<crate::layers::meta::semantic::SemanticDependency>>,
    lexical_regions: Option<&'a crate::meta_util::LexicalRegions>,
    ngrx: Option<Option<&'a crate::angular_meta::ngrx::NgRxShape>>,
    ngrx_edges: Option<&'a [SemanticEdge]>,
    routing: Option<Option<&'a crate::angular_meta::routing::RouteShape>>,
    is_angular: Option<bool>,
    initializers: Option<&'a [crate::angular_meta::inject_evidence::ClassInitializerEvidence]>,
    invocations: Option<&'a crate::ir::invocation_evidence::InvocationEvidenceView<'a>>,
}

pub(super) fn extract_non_testing_edges(
    source: &str,
    class_captures: &[String],
    fidelity: Fidelity,
    config: Option<&CleanCtxConfig>,
    declaring_path: Option<&std::path::Path>,
    evidence: ProjectionEvidence<'_>,
) -> Vec<SemanticEdge> {
    let meta_config = config.and_then(|value| value.meta_layers.get("angular"));
    let mut edges = Vec::new();
    let mut module_dependencies = evidence.module_dependencies;

    if evidence
        .is_angular
        .unwrap_or_else(|| crate::angular_meta::detect::is_angular_file(source))
    {
        let classes: Vec<_> = match evidence.initializers {
            Some(classes) => classes
                .iter()
                .map(|class| {
                    (
                        Some(class.consumer.as_str()),
                        class.raw_class.as_str(),
                        {
                            let tokens = class.admitted_tokens();
                            #[cfg(feature = "typescript")]
                            let tokens = if evidence.typescript_authority.is_some() {
                                Vec::new()
                            } else {
                                tokens
                            };
                            tokens
                        },
                        class
                            .class_span
                            .end_byte()
                            .checked_sub(class.raw_class.len()),
                    )
                })
                .collect(),
            None => class_captures
                .iter()
                .map(|raw| (None, raw.as_str(), Vec::new(), None))
                .collect(),
        };
        for (owner, raw_class, tokens, start) in classes {
            let entries = crate::angular_meta::decorators::extract_graph_entries(raw_class);
            #[cfg(feature = "typescript")]
            let entries = if let Some(authority) = evidence.typescript_authority {
                match start.and_then(|start| {
                    crate::angular_meta::class_role_authority::class_role(
                        source, raw_class, start, authority,
                    )
                }) {
                    Some(role) => owner.map(|owner| {
                        (
                            owner.to_string(),
                            role.kind,
                            role.selector,
                            crate::angular_meta::constructor_injects::extract_constructor_injects(
                                raw_class,
                            )
                            .unwrap_or_default(),
                            role.pipe_name,
                        )
                    }),
                    None => None,
                }
            } else {
                entries
            };
            #[cfg(not(feature = "typescript"))]
            let _ = start;
            if let Some((class_name, kind, selector, mut injects, pipe_name)) = entries {
                let class_name = owner.unwrap_or(&class_name);
                injects.extend(tokens);
                let projected = crate::angular_meta::semantic::class_to_semantic_edges(
                    class_name,
                    kind,
                    selector.as_deref(),
                    &injects,
                    pipe_name.as_deref(),
                    raw_class,
                    fidelity,
                );
                #[cfg(feature = "typescript")]
                let projected: Vec<_> = projected
                    .into_iter()
                    .filter(|edge| {
                        evidence.typescript_authority.is_none()
                            || edge.relation
                                != crate::layers::meta::semantic::SemanticRelation::Injects
                    })
                    .collect();
                edges.extend(projected);
                if matches!(
                    kind,
                    crate::angular_meta::decorators::ClassKind::Module
                        | crate::angular_meta::decorators::ClassKind::Component
                ) {
                    #[cfg(feature = "typescript")]
                    let canonical = evidence.typescript_authority.map(|authority| {
                        start
                            .map(|start| {
                                crate::angular_meta::module_metadata::project_authoritative(
                                    authority,
                                    start,
                                    start + raw_class.len(),
                                )
                            })
                            .unwrap_or_default()
                    });
                    #[cfg(not(feature = "typescript"))]
                    let canonical: Option<
                        crate::angular_meta::module_metadata::ModuleProjection,
                    > = None;
                    let projection = canonical.unwrap_or_else(|| {
                        crate::angular_meta::module_metadata::project(
                            class_name,
                            raw_class,
                            source,
                            declaring_path,
                            class_captures,
                        )
                    });
                    edges.extend(projection.edges);
                    if let Some(dependencies) = module_dependencies.as_deref_mut() {
                        dependencies.extend(projection.dependencies);
                    }
                }
                let source_id = declaring_path
                    .map(|path| path.to_string_lossy())
                    .unwrap_or_else(|| std::borrow::Cow::Borrowed("<memory>"));
                edges.extend(
                    crate::angular_meta::provider_semantics::project_with_authority(
                        &source_id,
                        source,
                        class_name,
                        kind,
                        evidence.typescript_authority,
                    ),
                );
                if let Some(path) = declaring_path
                    && let Some(edge) = crate::angular_meta::semantic::component_template_edge(
                        class_name, kind, raw_class, path,
                    )
                {
                    edges.push(edge);
                }
            }
        }
    }

    #[cfg(feature = "typescript")]
    if let (Some(authority), Some(classes)) = (evidence.typescript_authority, evidence.initializers)
    {
        edges.extend(crate::angular_meta::constructor_authority::project(
            source, authority, classes,
        ));
    }

    #[cfg(feature = "typescript")]
    if let (Some(authority), Some(classes), Some(invocations)) = (
        evidence.typescript_authority,
        evidence.initializers,
        evidence.invocations,
    ) {
        edges.extend(crate::angular_meta::inject_authority::project(
            source,
            authority,
            classes,
            invocations,
        ));
    }

    if let Some(invocations) = evidence.invocations {
        let source_id = declaring_path
            .map(|path| path.to_string_lossy())
            .unwrap_or_else(|| std::borrow::Cow::Borrowed("<memory>"));
        edges.extend(
            crate::angular_meta::member_semantics::project_with_authority(
                &source_id,
                source,
                invocations,
                evidence.typescript_authority,
            ),
        );
    }

    let ngrx_shape = match evidence.ngrx {
        Some(shape) => shape.cloned(),
        None => evidence.lexical_regions.map_or_else(
            || crate::angular_meta::ngrx::extract_ngrx_shape(source, fidelity),
            |regions| {
                crate::angular_meta::ngrx::extract_ngrx_shape_with_regions(
                    source, fidelity, regions,
                )
            },
        ),
    };
    if meta_config.map(|value| value.ngrx.enabled).unwrap_or(true)
        && let Some(shape) = ngrx_shape
    {
        edges.extend(
            evidence
                .ngrx_edges
                .map_or_else(|| shape.to_ngrx_semantic_edges(), |edges| edges.to_vec()),
        );
    }
    let routing_shape = match evidence.routing {
        Some(shape) => shape.cloned(),
        None => evidence.lexical_regions.map_or_else(
            || {
                crate::angular_meta::routing::extract_route_shape_at(
                    source,
                    fidelity,
                    declaring_path,
                )
            },
            |regions| {
                crate::angular_meta::routing::extract_route_shape_at_with_regions(
                    source,
                    fidelity,
                    regions,
                    declaring_path,
                )
            },
        ),
    };
    let routing_enabled = meta_config
        .map(|value| value.routing.enabled)
        .unwrap_or(true);
    if routing_enabled && let Some(shape) = routing_shape {
        #[cfg(feature = "typescript")]
        let owned = evidence
            .typescript_authority
            .map(crate::angular_meta::route_components::owned_objects)
            .unwrap_or_default();
        #[cfg(not(feature = "typescript"))]
        let owned = Vec::new();
        #[cfg(feature = "typescript")]
        let lazy_owned = evidence
            .typescript_authority
            .map(crate::angular_meta::route_lazy_components::owned_objects)
            .unwrap_or_default();
        #[cfg(not(feature = "typescript"))]
        let lazy_owned = Vec::new();
        #[cfg(feature = "typescript")]
        let children_owned = evidence
            .typescript_authority
            .map(crate::angular_meta::route_load_children::owned_objects)
            .unwrap_or_default();
        #[cfg(not(feature = "typescript"))]
        let children_owned = Vec::new();
        #[cfg(feature = "typescript")]
        let guard_owned = evidence
            .typescript_authority
            .map(crate::angular_meta::route_guards::owned_objects)
            .unwrap_or_default();
        #[cfg(not(feature = "typescript"))]
        let guard_owned = Vec::new();
        #[cfg(feature = "typescript")]
        let kinds_owned = evidence
            .typescript_authority
            .map(crate::angular_meta::route_guards::owned_kinds)
            .unwrap_or_default();
        #[cfg(not(feature = "typescript"))]
        let kinds_owned = Vec::new();
        #[cfg(feature = "typescript")]
        let resolver_owned = evidence
            .typescript_authority
            .map(crate::angular_meta::route_resolvers::owned_objects)
            .unwrap_or_default();
        #[cfg(not(feature = "typescript"))]
        let resolver_owned = Vec::new();
        edges.extend(shape.to_semantic_edges_resolver_ownership(
            &owned,
            &lazy_owned,
            &children_owned,
            &guard_owned,
            &kinds_owned,
            &resolver_owned,
        ));
    }

    #[cfg(feature = "typescript")]
    if routing_enabled && let Some(authority) = evidence.typescript_authority {
        let resolver_projection =
            crate::angular_meta::route_resolvers::project_with_registrations(authority);
        edges.extend(resolver_projection.edges);
        if let Some(output) = evidence.resolver_registrations {
            *output = Some(resolver_projection.registrations);
        }
        edges.extend(crate::angular_meta::route_guards::project(authority));
        edges.extend(crate::angular_meta::route_guards::project_kinds(authority));
        edges.extend(crate::angular_meta::route_load_children::project(authority));
        edges.extend(crate::angular_meta::route_components::project(authority));
        edges.extend(crate::angular_meta::route_lazy_components::project(
            authority,
        ));
    }

    #[cfg(feature = "typescript")]
    if let Some(authority) = evidence.typescript_authority {
        edges.extend(crate::angular_meta::config_composition::project(authority));
        edges.extend(crate::angular_meta::route_providers::project(authority));
        edges.extend(crate::angular_meta::bootstrap_references::project(
            authority,
        ));
        edges.extend(crate::angular_meta::application_config_providers::project(
            authority,
        ));
    }
    edges
}

pub(super) fn evaluate(
    layer_name: &'static str,
    context: &super::MetaLayerContext<'_>,
    precomputed_angular: Option<bool>,
) -> super::MetaLayerEvaluation {
    evaluate_owned(layer_name, context, precomputed_angular).evaluation
}

pub(super) fn evaluate_owned(
    layer_name: &'static str,
    context: &super::MetaLayerContext<'_>,
    precomputed_angular: Option<bool>,
) -> super::MetaLayerOwnedEvaluation {
    let meta_config = context
        .config
        .and_then(|config| config.meta_layers.get("angular"));
    let ngrx_enabled = meta_config
        .map(|config| config.ngrx.enabled)
        .unwrap_or(true);
    let mut ngrx_edges = None;
    let ngrx_shape = ngrx_enabled
        .then(|| {
            let (shape, starts) = crate::angular_meta::ngrx::extract_ngrx_shape_with_sites(
                context.source,
                context.fidelity,
                context.lexical_regions,
            )
            .map_or((None, Vec::new()), |(shape, starts)| (Some(shape), starts));
            let shape = crate::angular_meta::ngrx::legacy::include(
                shape,
                context.ngrx_class_actions.unwrap_or(&[]),
            );
            shape
                .map(|shape| {
                    let mut semantic_shape = context.invocation_evidence.map_or_else(
                        || {
                            let mut unsupported = shape.clone();
                            unsupported.select_sites.clear();
                            unsupported
                        },
                        |invocations| {
                            crate::angular_meta::ngrx::selector_references::admit(
                                shape.clone(),
                                invocations,
                                context.ngrx_selector_declarations.unwrap_or(&[]),
                                context.angular_initializers.unwrap_or(&[]),
                                &context.path.to_string_lossy(),
                                context.source,
                            )
                        },
                    );
                    if let Some(invocations) = context.invocation_evidence {
                        crate::angular_meta::ngrx::service_owners::admit_modern_initializer_dispatches(
                            &mut semantic_shape,
                            invocations,
                            context.angular_initializers.unwrap_or(&[]),
                            &context.path.to_string_lossy(),
                            context.source,
                        );
                    }
                    semantic_shape
                        .dispatch_sites
                        .retain(|site| !site.object_literal);
                    ngrx_edges = Some(crate::angular_meta::ngrx::service_owners::project(
                        semantic_shape,
                        &starts,
                        context.ngrx_constructor_dispatches.unwrap_or(&[]),
                        context.ngrx_service_dispatches.unwrap_or(&[]),
                        context.source,
                        &context.path.to_string_lossy(),
                    ));
                    crate::angular_meta::ngrx::constructors::apply(
                        shape,
                        &starts,
                        context.ngrx_constructor_dispatches.unwrap_or(&[]),
                        context.source,
                        &context.path.to_string_lossy(),
                    )
                })
                .filter(|shape| !shape.is_empty())
        })
        .flatten();
    let routing_enabled = meta_config
        .map(|config| config.routing.enabled)
        .unwrap_or(true);
    let routing_shape = routing_enabled
        .then(|| {
            crate::angular_meta::routing::extract_route_shape_at_with_regions(
                context.source,
                context.fidelity,
                context.lexical_regions,
                Some(context.path),
            )
        })
        .flatten();
    let block = crate::angular_meta::run_meta_layer_with_config_path_regions_and_evidence(
        context.source,
        context.class_captures,
        context.fidelity,
        meta_config,
        context.path,
        context.lexical_regions,
        crate::angular_meta::PrecomputedAngularEvidence {
            rx: context.invocation_evidence.map(|view| {
                crate::angular_meta::rx::extract_rx_shape_with_evidence(
                    context.source,
                    context.lexical_regions,
                    view,
                )
            }),
            ngrx: Some(ngrx_shape.clone()),
            routing: Some(routing_shape.clone()),
            is_angular: precomputed_angular,
            initializers: context.angular_initializers,
        },
    );
    let output = block
        .filter(|block| !block.is_empty())
        .map(|block| super::MetaLayerOutput {
            layer_name,
            rendered: block.render(),
            angular_block: Some(block),
            ..Default::default()
        });
    let captures: Vec<String> = context
        .paired_class_captures
        .iter()
        .map(|(_, text)| text.clone())
        .collect();
    let mut resolver_registrations = None;
    let mut module_dependencies = Vec::new();
    let mut semantic_edges = extract_non_testing_edges(
        context.source,
        &captures,
        context.fidelity,
        context.config,
        Some(context.path),
        ProjectionEvidence {
            #[cfg(feature = "typescript")]
            typescript_authority: context.typescript_authority,
            resolver_registrations: Some(&mut resolver_registrations),
            module_dependencies: Some(&mut module_dependencies),
            lexical_regions: Some(context.lexical_regions),
            ngrx: Some(ngrx_shape.as_ref()),
            ngrx_edges: ngrx_edges.as_deref(),
            routing: Some(routing_shape.as_ref()),
            is_angular: precomputed_angular,
            initializers: context.angular_initializers,
            invocations: context.invocation_evidence,
        },
    );
    if ngrx_enabled {
        semantic_edges = crate::angular_meta::ngrx::action_imports::refine_candidates(
            &context.path.to_string_lossy(),
            context.source,
            semantic_edges,
        );
        if let Some(shape) = ngrx_shape.as_ref() {
            semantic_edges.extend(crate::angular_meta::ngrx::direct_imports::candidates(
                &context.path.to_string_lossy(),
                context.source,
                shape,
            ));
        }
        semantic_edges.extend(
            context
                .ngrx_selector_declarations
                .unwrap_or(&[])
                .iter()
                .filter_map(|declaration| declaration.edge()),
        );
        semantic_edges.extend(
            context
                .ngrx_legacy_transitions
                .unwrap_or(&[])
                .iter()
                .map(crate::angular_meta::ngrx::transitions::LegacyTransition::edge),
        );
        for discriminant in context.ngrx_legacy_discriminants.unwrap_or(&[]) {
            if discriminant.matches_source(&context.path.to_string_lossy(), context.source) {
                semantic_edges.push(discriminant.declaration_edge());
                semantic_edges.push(discriminant.transition_edge());
            }
        }
        semantic_edges.extend(crate::angular_meta::ngrx::object_actions::evidence(
            &context.path.to_string_lossy(),
            context.source,
        ));
    }
    if meta_config
        .map(|config| config.testing.enabled)
        .unwrap_or(true)
    {
        semantic_edges.extend(
            crate::angular_meta::testing::extract_testing_semantic_edges_with_regions(
                context.source,
                context.path,
                context.lexical_regions,
            ),
        );
    }
    let mut semantic_dependencies = routing_shape
        .map(|shape| shape.semantic_dependencies.clone())
        .unwrap_or_default();
    semantic_dependencies.extend(module_dependencies);
    if ngrx_enabled
        && semantic_edges
            .iter()
            .any(|edge| crate::angular_meta::ngrx::object_actions::is_evidence_layer(edge.layer))
    {
        semantic_dependencies.extend(crate::angular_meta::ngrx::object_actions::dependencies(
            &context.path.to_string_lossy(),
            context.source,
        ));
    }
    #[cfg(feature = "typescript")]
    let resolver_registration_scope = Some(
        meta_config.is_none_or(|value| value.routing.enabled)
            && context.typescript_authority.is_some(),
    );
    #[cfg(not(feature = "typescript"))]
    let resolver_registration_scope = Some(false);
    super::MetaLayerOwnedEvaluation {
        resolver_registration_scope,
        evaluation: super::MetaLayerEvaluation {
            output,
            semantic_edges,
            semantic_dependencies,
        },
        resolver_registrations,
    }
}
