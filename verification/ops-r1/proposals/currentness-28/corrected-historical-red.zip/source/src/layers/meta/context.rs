//! Borrowed, compilation-scoped evidence shared by meta-layers.

use std::path::Path;

use crate::compression::Fidelity;
use crate::config::CleanCtxConfig;
use crate::layers::meta::semantic::SemanticEdge;
use crate::meta_util::LexicalRegions;

use super::MetaLayerOutput;

/// Parser-owned first-base evidence for one structured class declaration.
/// Framework layers may classify only the exact written forms they support.
pub struct StructuredClassBase {
    pub owner: String,
    pub written: String,
}

/// Marker and semantic results produced by one applicable meta-layer.
#[derive(Debug, Default)]
pub struct MetaLayerEvaluation {
    pub output: Option<MetaLayerOutput>,
    pub semantic_edges: Vec<SemanticEdge>,
    pub semantic_dependencies: Vec<crate::layers::meta::semantic::SemanticDependency>,
}

/// Additive owned transport; the existing public evaluation shape stays intact.
#[derive(Debug, Default)]
pub struct MetaLayerOwnedEvaluation {
    pub(crate) resolver_registration_scope: Option<bool>,
    pub evaluation: MetaLayerEvaluation,
    pub(crate) resolver_registrations: Option<super::resolver_registrations::ResolverRegistrations>,
}

impl From<MetaLayerEvaluation> for MetaLayerOwnedEvaluation {
    fn from(evaluation: MetaLayerEvaluation) -> Self {
        Self {
            evaluation,
            resolver_registrations: None,
            resolver_registration_scope: None,
        }
    }
}

/// Immutable inputs and shared lexical evidence for one meta-layer pass.
pub struct MetaLayerContext<'a> {
    #[cfg(feature = "typescript")]
    pub(crate) typescript_authority:
        Option<&'a crate::ir::typescript_resolution::TypeScriptAuthority>,
    pub source: &'a str,
    pub path: &'a Path,
    pub class_captures: &'a [String],
    pub paired_class_captures: &'a [(String, String)],
    /// Parser-owned declaration identifiers when a language provides them.
    pub structured_declarations: Option<&'a [(String, String)]>,
    /// Parser-owned first class-base references when a language provides them.
    pub structured_class_bases: Option<&'a [StructuredClassBase]>,
    /// Framework-neutral resolved class ancestry from the current C# parse.
    #[cfg(feature = "csharp")]
    pub(crate) csharp_resolved_classes:
        Option<&'a [crate::ir::csharp_resolution::CSharpResolvedClass]>,
    pub fidelity: Fidelity,
    pub config: Option<&'a CleanCtxConfig>,
    pub lexical_regions: &'a LexicalRegions,
    /// Compiler-owned evidence; absence means no upstream parse was supplied.
    pub(crate) invocation_evidence:
        Option<&'a crate::ir::invocation_evidence::InvocationEvidenceView<'a>>,
    #[cfg(feature = "typescript")]
    pub(crate) angular_initializers:
        Option<&'a [crate::angular_meta::inject_evidence::ClassInitializerEvidence]>,
    #[cfg(feature = "typescript")]
    pub(crate) ngrx_service_dispatches:
        Option<&'a [crate::angular_meta::ngrx::service_owners::ServiceDispatch]>,
    #[cfg(feature = "typescript")]
    pub(crate) ngrx_constructor_dispatches:
        Option<&'a [crate::angular_meta::ngrx::constructors::ConstructorDispatch]>,
    #[cfg(feature = "typescript")]
    pub(crate) ngrx_legacy_transitions:
        Option<&'a [crate::angular_meta::ngrx::transitions::LegacyTransition]>,
    #[cfg(feature = "typescript")]
    pub(crate) ngrx_legacy_discriminants:
        Option<&'a [crate::angular_meta::ngrx::discriminants::LegacyDiscriminantEvidence]>,
    #[cfg(feature = "typescript")]
    pub(crate) ngrx_class_actions:
        Option<&'a [crate::angular_meta::ngrx::legacy::ClassActionEvidence]>,
    #[cfg(feature = "typescript")]
    pub(crate) ngrx_selector_declarations:
        Option<&'a [crate::angular_meta::ngrx::selector_declarations::SelectorDeclarationEvidence]>,
}

impl<'a> MetaLayerContext<'a> {
    pub fn new(
        source: &'a str,
        path: &'a Path,
        class_captures: &'a [String],
        paired_class_captures: &'a [(String, String)],
        fidelity: Fidelity,
        config: Option<&'a CleanCtxConfig>,
        lexical_regions: &'a LexicalRegions,
    ) -> Self {
        Self {
            source,
            path,
            class_captures,
            paired_class_captures,
            #[cfg(feature = "typescript")]
            typescript_authority: None,
            structured_declarations: None,
            structured_class_bases: None,
            #[cfg(feature = "csharp")]
            csharp_resolved_classes: None,
            fidelity,
            config,
            lexical_regions,
            invocation_evidence: None,
            #[cfg(feature = "typescript")]
            angular_initializers: None,
            #[cfg(feature = "typescript")]
            ngrx_class_actions: None,
            #[cfg(feature = "typescript")]
            ngrx_selector_declarations: None,
            #[cfg(feature = "typescript")]
            ngrx_legacy_transitions: None,
            #[cfg(feature = "typescript")]
            ngrx_legacy_discriminants: None,
            #[cfg(feature = "typescript")]
            ngrx_constructor_dispatches: None,
            #[cfg(feature = "typescript")]
            ngrx_service_dispatches: None,
        }
    }
}
