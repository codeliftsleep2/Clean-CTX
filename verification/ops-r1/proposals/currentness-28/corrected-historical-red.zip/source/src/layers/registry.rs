// src/layers/registry.rs
//
// LayerRegistry — collects all enabled language and meta layers at startup
// and dispatches to them at runtime.
//
// When a Cargo feature is disabled, the corresponding layer is not registered,
// and the tree-sitter grammar is not linked in the binary.

use crate::compression::Fidelity;
use crate::config::CleanCtxConfig;
use crate::layers::language::LanguageLayer;
use crate::layers::meta::semantic::SemanticEdge;
use crate::layers::meta::{MetaLayer, MetaLayerContext, MetaLayerOutput};
use std::path::Path;
use std::sync::OnceLock;

/// Owned results from one combined meta-layer dispatch.
type OwnedMetaLayerResults = (
    Vec<MetaLayerOutput>,
    Vec<SemanticEdge>,
    Vec<crate::layers::meta::semantic::SemanticDependency>,
    Option<crate::layers::meta::resolver_registrations::ResolverRegistrations>,
    Option<bool>,
);

/// Global registry, initialized once per process.
static LAYER_REGISTRY: OnceLock<LayerRegistry> = OnceLock::new();

#[cfg(test)]
thread_local! {
    static CONTEXT_EVALUATION_COUNT: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[cfg(test)]
#[cfg(feature = "angular")]
pub(crate) fn reset_context_evaluation_count() {
    CONTEXT_EVALUATION_COUNT.with(|count| count.set(0));
}

#[cfg(test)]
#[cfg(feature = "angular")]
pub(crate) fn context_route_count() -> usize {
    CONTEXT_EVALUATION_COUNT.with(std::cell::Cell::get)
}

/// Registry of all enabled language and meta layers.
///
/// Built at startup from the available Cargo features. Provides dispatch
/// methods for language detection, compilation, and meta-layer enrichment.
pub struct LayerRegistry {
    languages: Vec<Box<dyn LanguageLayer>>,
    meta_layers: Vec<Box<dyn MetaLayer>>,
}

impl Default for LayerRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl LayerRegistry {
    /// Build a new registry from the currently enabled Cargo features.
    ///
    /// This is called once at server startup and cached in a `OnceLock`.
    pub fn new() -> Self {
        let mut reg = LayerRegistry {
            languages: Vec::new(),
            meta_layers: Vec::new(),
        };

        // Language layers (always available when feature is enabled)
        #[cfg(feature = "typescript")]
        reg.languages
            .push(Box::new(crate::layers::language::TypeScriptLayer::new()));

        #[cfg(feature = "csharp")]
        reg.languages
            .push(Box::new(crate::layers::language::CSharpLayer::new()));

        #[cfg(feature = "rust")]
        reg.languages
            .push(Box::new(crate::layers::language::RustLayer::new()));

        #[cfg(feature = "java")]
        reg.languages
            .push(Box::new(crate::layers::language::JavaLayer::new()));

        // Meta layers (only available when both the meta feature and base language are enabled)
        #[cfg(feature = "angular")]
        reg.meta_layers
            .push(Box::new(crate::layers::meta::AngularMetaLayer::new()));

        #[cfg(feature = "spring_boot")]
        reg.meta_layers
            .push(Box::new(crate::layers::meta::SpringBootMetaLayer::new()));

        #[cfg(feature = "dotnet")]
        reg.meta_layers
            .push(Box::new(crate::dotnet_meta::DotNetMetaLayer::new()));

        // Always-on fallback meta layer: indexes ordinary type declarations
        // (classes/interfaces/structs/enums/traits/records) as `builtin`
        // entities. Registered LAST so framework semantics run first; the
        // `builtin` domain is disjoint from framework domains, so ordering
        // never affects identity correctness.
        reg.meta_layers.push(Box::new(
            crate::layers::meta::builtin::BuiltinMetaLayer::new(),
        ));

        reg
    }

    /// Get or initialize the global registry.
    pub fn global() -> &'static Self {
        LAYER_REGISTRY.get_or_init(Self::new)
    }

    /// Find a language layer by name.
    pub fn language_layer(&self, name: &str) -> Option<&dyn LanguageLayer> {
        self.languages
            .iter()
            .find(|l| l.name() == name)
            .map(|l| l.as_ref())
    }

    /// Find a language layer by file extension.
    pub fn language_layer_for_extension(&self, ext: &str) -> Option<&dyn LanguageLayer> {
        self.languages
            .iter()
            .find(|l| l.extensions().contains(&ext))
            .map(|l| l.as_ref())
    }

    /// Get all enabled language layers.
    pub fn language_layers(&self) -> &[Box<dyn LanguageLayer>] {
        &self.languages
    }

    /// Get all enabled meta layers.
    pub fn meta_layers(&self) -> &[Box<dyn MetaLayer>] {
        &self.meta_layers
    }

    /// Run all applicable meta-layers on the given source and class captures.
    ///
    /// This is the pipeline-compatible entry point. Each meta-layer checks
    /// `is_applicable` and, if true, calls `enrich` to produce a structured
    /// [`MetaLayerOutput`] (structured block + rendered text).
    ///
    /// The `ir` parameter provides class captures from the compiled IR.
    /// When called from the text pipeline, this may be an empty IR — meta-layers
    /// that need class names should extract them from `class_captures` directly.
    ///
    /// The `config` parameter is forwarded to each layer's `enrich` so
    /// per-framework `enabled` flags and sub-layer settings are honored.
    ///
    /// Returns a vector of [`MetaLayerOutput`] values — one per layer that
    /// produced markers. The structured blocks are used directly by the
    /// compression pipeline (no render-then-reparse); the rendered text is
    /// retained for consumers that only need the flat string.
    pub fn run_meta_layers_pipeline(
        &self,
        source: &str,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<MetaLayerOutput> {
        self.run_meta_layers_pipeline_with_path(
            source,
            Path::new(""),
            class_captures,
            fidelity,
            config,
        )
    }

    /// Path-aware dispatch. The source-only entry point above remains the
    /// backward-compatible API for callers without canonical path context.
    pub fn run_meta_layers_pipeline_with_path(
        &self,
        source: &str,
        path: &Path,
        class_captures: &[String],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<MetaLayerOutput> {
        let mut results = Vec::new();

        for layer in &self.meta_layers {
            // Use trait-based dispatch: check if this layer applies to the source
            if layer.is_applicable(source, path, config) {
                // Pass the real source code and class captures directly — no
                // DefClass round-trip (eliminates the semantic corruption where
                // DefClass.name carried full source text instead of a class name).
                if let Some(output) =
                    layer.enrich_with_path(source, path, class_captures, fidelity, config)
                {
                    results.push(output);
                }
            }
        }

        results
    }

    /// Collect semantic edges through the text-oriented compatibility path.
    ///
    /// Mirrors `run_meta_layers_pipeline` dispatch: each layer checks
    /// `is_applicable` and, if true, calls `extract_semantic_edges`. Edges
    /// are NOT deduplicated here -- deduplication happens at the workspace
    /// index boundary (semantic plan U2).
    ///
    /// `class_captures` is a slice of `(capture_name, capture_text)` pairs so
    /// the always-on `BuiltinMetaLayer` can classify ordinary declarations
    /// without re-parsing the source. Framework layers ignore the name.
    pub fn collect_semantic_edges(
        &self,
        source: &str,
        class_captures: &[(String, String)],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        self.collect_semantic_edges_with_path(
            source,
            Path::new(""),
            class_captures,
            fidelity,
            config,
        )
    }

    /// Path-aware semantic dispatch with default forwarding for layers that
    /// do not consume path evidence.
    pub fn collect_semantic_edges_with_path(
        &self,
        source: &str,
        path: &Path,
        class_captures: &[(String, String)],
        fidelity: Fidelity,
        config: Option<&CleanCtxConfig>,
    ) -> Vec<SemanticEdge> {
        let mut edges = Vec::new();
        for layer in &self.meta_layers {
            if layer.is_applicable(source, path, config) {
                edges.extend(layer.extract_semantic_edges_paired_with_path(
                    source,
                    path,
                    class_captures,
                    fidelity,
                    config,
                ));
            }
        }
        edges
    }

    /// Combined marker and semantic dispatch for one compilation context.
    pub fn evaluate_meta_layers_context(
        &self,
        context: &MetaLayerContext<'_>,
    ) -> (
        Vec<MetaLayerOutput>,
        Vec<SemanticEdge>,
        Vec<crate::layers::meta::semantic::SemanticDependency>,
    ) {
        let (outputs, edges, dependencies, _, _) = self.evaluate_owned_meta_layers_context(context);
        (outputs, edges, dependencies)
    }

    pub(crate) fn evaluate_owned_meta_layers_context(
        &self,
        context: &MetaLayerContext<'_>,
    ) -> OwnedMetaLayerResults {
        #[cfg(test)]
        CONTEXT_EVALUATION_COUNT.with(|count| count.set(count.get() + 1));
        let mut resolver_registrations = None;
        let mut resolver_registration_scope = Some(false);
        let mut outputs = Vec::new();
        let mut edges = Vec::new();
        let mut dependencies = Vec::new();
        for layer in &self.meta_layers {
            let Some(evaluation) = layer.evaluate_owned_if_applicable(context) else {
                continue;
            };
            if evaluation.resolver_registration_scope.is_some() {
                resolver_registration_scope = evaluation.resolver_registration_scope;
            }
            if evaluation.resolver_registrations.is_some() {
                resolver_registrations = evaluation.resolver_registrations;
            }
            let evaluation = evaluation.evaluation;
            if let Some(output) = evaluation.output {
                outputs.push(output);
            }
            edges.extend(evaluation.semantic_edges);
            dependencies.extend(evaluation.semantic_dependencies);
        }
        dependencies.sort_by(|left, right| left.file_path.cmp(&right.file_path));
        dependencies.dedup_by(|left, right| left.file_path == right.file_path);
        (
            outputs,
            edges,
            dependencies,
            resolver_registrations,
            resolver_registration_scope,
        )
    }

    /// Check if a specific meta-layer is enabled.
    pub fn has_meta_layer(&self, name: &str) -> bool {
        self.meta_layers.iter().any(|l| l.name() == name)
    }

    /// Get a list of enabled language names (for diagnostics/CLI).
    pub fn enabled_language_names(&self) -> Vec<&'static str> {
        self.languages.iter().map(|l| l.name()).collect()
    }

    /// Get a list of enabled meta-layer names (for diagnostics/CLI).
    pub fn enabled_meta_layer_names(&self) -> Vec<&'static str> {
        self.meta_layers.iter().map(|l| l.name()).collect()
    }
}

#[cfg(test)]
#[path = "../tests/layers/registry.rs"]
mod tests;
