// src/ir/render_llm.rs
//
// Phase 1: LLM-Optimized Hierarchical IR Renderer.
//
// Converts a `HierarchicalIR` into compact, LLM-friendly text using
// single-character structural markers. This is a STATELESS projection:
// all stateful operations (deltas, persistence, context tracking) operate
// on the flat `CoreOp[]` stream internally. The rendered text is generated
// fresh each time from the latest IR.
//
// Key design decisions:
//   - Uses class/method **names** only, never internal alias IDs (C1, M1)
//   - Overloaded methods disambiguated by their visible parameter signatures
//   - Fidelity controls field layout (structural = grouped, Edit = one-per-line)
//   - Meta-layer `@` annotations always shown regardless of fidelity
//   - The `// SCHEMA vNext` header opens every output with the legend table
//
// Notation reference (also in the SCHEMA vNext header):
//   @=meta  C=class  X=extends  I=implements  F=field  M=method
//   $=import  p:=params  →=return  mod:=method-modifiers cmod:=class-modifiers
//   ctl:=control-summary pf:=pattern-facts fl:=legacy-flags cl:=class-metadata P=pattern T=type-alias

use super::hierarchical::{
    ClassNode, FieldNode, HierarchicalIR, InterfaceNode, MethodNode, PatternEntry,
};
use super::patterns::is_observable_return_type;
use super::{DeclarationModifier, ExecutionContextKind, PatternFact, SideEffectKind};
use crate::compression::Fidelity;
use std::collections::{HashMap, HashSet};

/// Render a `HierarchicalIR` into compact LLM-optimized text.
///
/// The output is a single string with newline-separated lines. The format
/// is designed to be maximally informative per token for LLM consumption.
///
/// # Fidelity behavior
///
/// | Aspect | Low | Medium | High | Edit | Verbatim |
/// |--------|-----|--------|------|------|----------|
/// | Fields | Space-separated, same line | One per line | One per line | One per line | One per line |
/// | Methods | Minimal (name + flags) | Params shown | Params shown | Params shown + verbatim bodies | Full raw source |
/// | Meta `@` | Always | Always | Always | Always | Always |
/// | `X`/`I` | Always | Always | Always | Always | Always |
/// | Patterns | Always | Always | Always | Always | Always |
/// | Imports | Always | Always | Always | Always | Always |
/// | Type aliases | Always | Always | Always | Always | Always |
///
/// Overloaded methods retain visible parameter signatures at every structural
/// fidelity so their declarations remain distinct without decorating names.
pub fn render_hierarchical_for_llm(hir: &HierarchicalIR, fidelity: Fidelity) -> String {
    render_hierarchical_for_llm_focused(hir, fidelity, None)
}

/// Render a `HierarchicalIR` into compact LLM-optimized text, optionally
/// restricting which methods get full verbatim bodies at `Fidelity::Edit`.
///
/// When `focus` is `Some(set)`, only methods whose names appear in the set
/// receive their full byte-exact body at Edit fidelity; all other methods
/// are rendered signature-only (the same path used for non-Edit fidelities).
/// When `focus` is `None`, every method's body is rendered — identical to
/// [`render_hierarchical_for_llm`].
///
/// This is strictly additive: callers that don't need symbol targeting can
/// keep using [`render_hierarchical_for_llm`] unchanged.
pub fn render_hierarchical_for_llm_focused(
    hir: &HierarchicalIR,
    fidelity: Fidelity,
    focus: Option<&HashSet<String>>,
) -> String {
    let mut output = String::new();

    // ── SCHEMA vNext header ──
    output.push_str("// SCHEMA vNext  @=meta C=class X=extends B?=unresolved-base-type I=implements F=field M=method $=import p:=params →=return mod:=method-modifiers cmod:=class-modifiers ctl:=control-summary pf:=pattern-facts fl:=legacy-flags cl:=class-metadata P=pattern T=type-alias\n");

    // ── Classes ──
    for class in &hir.classes {
        render_class(&mut output, class, fidelity, focus);
    }

    if !hir.interfaces.is_empty() {
        output.push_str("// Q=interface\n");
        for interface in &hir.interfaces {
            render_interface(&mut output, interface, fidelity, focus);
        }
    }

    // ── Imports ──
    for imp in &hir.imports {
        if imp.len() >= 3 {
            // The generated import identity remains canonical code-side but is
            // presentation-only noise: no visible record references it.
            let module = &imp[1];
            let named = &imp[2];
            match (module.is_empty(), named == "*" || named.is_empty()) {
                (true, true) => output.push_str("$\n"),
                (false, true) => output.push_str(&format!("$ {module}\n")),
                (true, false) => output.push_str(&format!("$ [{named}]\n")),
                (false, false) => output.push_str(&format!("$ {module} [{named}]\n")),
            }
        }
    }

    // ── Type aliases ──
    for ta in &hir.type_aliases {
        if ta.len() >= 2 {
            let alias = &ta[0];
            let original = &ta[1];
            output.push_str(&format!("T {} = {}\n", alias, original));
        }
    }

    output
}

/// Render a single class node.
fn render_class(
    output: &mut String,
    class: &ClassNode,
    fidelity: Fidelity,
    focus: Option<&HashSet<String>>,
) {
    // Typed class boundary
    output.push_str(&format!("C {}\n", class.name));

    // Class-level patterns (e.g., EMPTY_CTOR)
    for pat in &class.patterns {
        render_pattern(output, pat);
    }

    if !class.modifiers.is_empty() {
        let modifiers = class
            .modifiers
            .iter()
            .flatten()
            .map(ToString::to_string)
            .collect::<Vec<_>>();
        output.push_str(&format!("cmod: {}\n", modifiers.join(" ")));
    }

    // Class-level flags
    if !class.class_flags.is_empty() {
        let flags = class
            .class_flags
            .iter()
            .flatten()
            .cloned()
            .collect::<Vec<_>>();
        output.push_str(&format!("cl: {}\n", flags.join(" ")));
    }

    // Extends
    if let Some(parent) = &class.extends {
        output.push_str(&format!("X {}\n", parent));
    }

    // Canonical uncertainty: written C# base-list target, not a claim that
    // the target is a class or interface.
    for written_type in &class.base_type_refs {
        output.push_str(&format!("B? {}\n", written_type));
    }

    // Implements
    if !class.implements.is_empty() {
        output.push_str(&format!("I {}\n", class.implements.join(" ")));
    }

    // Fields — layout depends on fidelity
    render_fields(output, &class.fields, fidelity);

    // Methods — with overload disambiguation
    render_methods(output, &class.methods, fidelity, focus, Some(&class.name));
}

fn render_interface(
    output: &mut String,
    interface: &InterfaceNode,
    fidelity: Fidelity,
    focus: Option<&HashSet<String>>,
) {
    output.push_str(&format!("Q {}\n", interface.name));
    if !interface.modifiers.is_empty() {
        let modifiers = interface
            .modifiers
            .iter()
            .flatten()
            .map(ToString::to_string)
            .collect::<Vec<_>>();
        output.push_str(&format!("imod: {}\n", modifiers.join(" ")));
    }
    if !interface.extends.is_empty() {
        output.push_str(&format!("X {}\n", interface.extends.join(" ")));
    }
    render_fields(output, &interface.fields, fidelity);
    render_methods(output, &interface.methods, fidelity, focus, None);
}

/// Render fields for a class.
///
/// Structural fidelities group fields on one owner-local row. Edit and
/// Verbatim retain one row per field alongside their body-bearing output.
fn render_fields(output: &mut String, fields: &[FieldNode], fidelity: Fidelity) {
    if fields.is_empty() {
        return;
    }

    match fidelity {
        Fidelity::Low | Fidelity::Medium | Fidelity::High => {
            // Space-separated on one owner-local line.
            let field_strs: Vec<String> = fields
                .iter()
                .map(|f| {
                    if let Some(ft) = &f.field_type {
                        format!("{}:{}", f.name, ft)
                    } else {
                        f.name.clone()
                    }
                })
                .collect();
            output.push_str(&format!("F {}\n", field_strs.join(" ")));
        }
        Fidelity::Edit | Fidelity::Verbatim => {
            // One per line
            for field in fields {
                if let Some(ft) = &field.field_type {
                    output.push_str(&format!("F {}:{}\n", field.name, ft));
                } else {
                    output.push_str(&format!("F {}\n", field.name));
                }
            }
        }
    }
}

/// Render methods for a class, retaining parameters for overloaded names even
/// at Low fidelity so their signatures remain distinct.
///
/// At `Fidelity::Edit`, a method's full verbatim body is appended only when
/// `focus` is `None` (every method) or the method's name is in the focus set.
/// Non-focused methods fall through to the signature-only rendering path.
fn render_methods(
    output: &mut String,
    methods: &[MethodNode],
    fidelity: Fidelity,
    focus: Option<&HashSet<String>>,
    owner_name: Option<&str>,
) {
    if methods.is_empty() {
        return;
    }

    // First pass: count method name occurrences
    let mut name_counts: HashMap<&str, usize> = HashMap::new();
    for method in methods {
        *name_counts.entry(&method.name).or_insert(0) += 1;
    }

    // Second pass: emit methods
    for method in methods {
        let return_declares_observable = method
            .return_type
            .as_deref()
            .is_some_and(is_observable_return_type);

        let count = name_counts[&method.name.as_str()];

        // Method-level patterns first
        for pat in &method.patterns {
            if return_declares_observable && pat.name == "OBSERVABLE" {
                continue;
            }
            render_pattern(output, pat);
        }

        // Method declaration. Parameter signatures below distinguish overloads.
        output.push_str(&format!("M {}", method.name));

        // Method body (params, return type, flags)
        let has_params = !method.params.is_empty();
        // Constructors have no C# return type. Canonical IR retains its
        // language-neutral void sentinel, but the model-facing skeleton must
        // not render that sentinel as a semantic type.
        let visible_return = method.return_type.as_ref().filter(|return_type| {
            !(return_type.as_str() == crate::ir::opcodes::TYPE_VOID
                && owner_name.is_some_and(|owner| method.name == owner))
        });
        let has_return = visible_return.is_some();
        let has_modifiers = !method.modifiers.is_empty();
        let has_control_summaries = !method.control_summaries.is_empty();
        let visible_pattern_facts = method
            .pattern_facts
            .iter()
            .flatten()
            .filter(|fact| {
                !(return_declares_observable && fact.kind() == PatternFact::Observable.kind())
            })
            .collect::<Vec<_>>();
        let has_pattern_facts = !visible_pattern_facts.is_empty();
        let has_flags = !method.flags.is_empty();

        if has_params
            || has_return
            || has_modifiers
            || has_control_summaries
            || has_pattern_facts
            || has_flags
        {
            // Params (shown in Medium/High, hidden in Low unless overloaded)
            if has_params && (fidelity != Fidelity::Low || count > 1) {
                let param_strs: Vec<String> = method
                    .params
                    .iter()
                    .map(|p| {
                        if p.len() >= 3 {
                            format!("{}:{}", p[2], p[1])
                        } else if p.len() >= 2 {
                            format!("{}:{}", p[0], p[1])
                        } else {
                            p[0].clone()
                        }
                    })
                    .collect();
                output.push_str(&format!(" p:{}", param_strs.join(" ")));
            }

            // Return type
            if let Some(rt) = visible_return {
                output.push_str(&format!(" → {}", rt));
            }

            if has_modifiers {
                let modifiers = method
                    .modifiers
                    .iter()
                    .flatten()
                    .map(ToString::to_string)
                    .collect::<Vec<_>>();
                output.push_str(&format!(" mod:{}", modifiers.join(",")));
            }

            if has_control_summaries {
                let summaries = method
                    .control_summaries
                    .iter()
                    .flatten()
                    .map(ToString::to_string)
                    .collect::<Vec<_>>();
                output.push_str(&format!(" ctl:{}", summaries.join(",")));
            }

            if has_pattern_facts {
                let facts = visible_pattern_facts
                    .iter()
                    .map(ToString::to_string)
                    .collect::<Vec<_>>();
                output.push_str(&format!(" pf:{}", facts.join(",")));
            }

            // Unknown legacy method metadata
            if has_flags {
                let flags = method.flags.iter().flatten().cloned().collect::<Vec<_>>();
                output.push_str(&format!(" fl:{}", flags.join(",")));
            }
        }

        // Control-flow metadata at High fidelity (Gap 1 fix)
        if fidelity == Fidelity::High && !method.control_flow.is_empty() {
            let cf_strs: Vec<String> = method
                .control_flow
                .iter()
                .map(|cf| {
                    if cf.len() >= 2 {
                        format!("{}:{}", cf[0], cf[1])
                    } else {
                        cf.join(":")
                    }
                })
                .collect();
            output.push_str(&format!(" cf:{}", cf_strs.join(",")));
        }

        // Data-flow metadata at High fidelity (Gap 1 fix).
        // Rendered as `df:reads:config,writes:users` — same inline pattern
        // as control-flow so the LLM sees semantic read/write pairs.
        if fidelity == Fidelity::High && !method.data_flow.is_empty() {
            let df_strs: Vec<String> = method
                .data_flow
                .iter()
                .map(|df| {
                    if df.len() >= 2 {
                        format!("{}:{}", df[0], df[1])
                    } else {
                        df.join(":")
                    }
                })
                .collect();
            output.push_str(&format!(" df:{}", df_strs.join(",")));
        }

        // Annotation-redundancy collapse: the `async` fact (co-derived from
        // the `async` keyword) was reported up to three times — mod:ASYNC +
        // se:async + ec:async. Report it once, at the most structural level
        // available: mod:ASYNC (declaration modifier) is authoritative and
        // drops se:async/ec:async; otherwise se:async (side effect) is
        // authoritative and drops ec:async. Presentation-only — the codec
        // still stores all three. se:async/ec:async still render when no
        // more-structural async fact exists.
        let is_async_declared = method
            .modifiers
            .iter()
            .flatten()
            .any(|m| *m == DeclarationModifier::Async);
        let has_async_side_effect = method.side_effect.contains(&SideEffectKind::Async);

        // Side-effect annotation at High fidelity (Gap 1 fix).
        // e.g. `se:mutation` — quickly tells the LLM whether a method is
        // pure, performs I/O, mutates state, is async, or is transactional.
        if fidelity == Fidelity::High && !method.side_effect.is_empty() {
            let effects: Vec<String> = method
                .side_effect
                .iter()
                .filter(|&&e| !(is_async_declared && e == SideEffectKind::Async))
                .map(ToString::to_string)
                .collect();
            if !effects.is_empty() {
                output.push_str(&format!(" se:{}", effects.join(",")));
            }
        }

        // Execution-context annotation at High fidelity (Gap 1 fix).
        // e.g. `ec:async` — tells the agent the runtime context without
        // a full body read.
        if fidelity == Fidelity::High && !method.execution_context.is_empty() {
            let contexts: Vec<String> = method
                .execution_context
                .iter()
                .filter(|&&c| {
                    !((is_async_declared || has_async_side_effect)
                        && c == ExecutionContextKind::Async)
                })
                .map(ToString::to_string)
                .collect();
            if !contexts.is_empty() {
                output.push_str(&format!(" ec:{}", contexts.join(",")));
            }
        }

        // Verbatim method body at Edit fidelity (byte-exact for replace_in_file).
        // When `focus` is `Some(set)`, only methods whose names are in the
        // set get their full body; all others are signature-only.
        if fidelity == Fidelity::Edit && focus.is_none_or(|f| f.contains(&method.name)) {
            if let Some(body) = &method.body {
                output.push('\n');
                output.push_str(body);
                // Ensure trailing newline before next method
                if !body.ends_with('\n') {
                    output.push('\n');
                }
            }
        }

        output.push('\n');
    }
}

/// Render a pattern entry.
fn render_pattern(output: &mut String, pat: &PatternEntry) {
    if pat.args.is_empty() {
        output.push_str(&format!("P {}\n", pat.name));
    } else {
        let args_str = pat.args.join(" ");
        output.push_str(&format!("P {} {}\n", pat.name, args_str));
    }
}

#[cfg(test)]
#[path = "../tests/ir/render_llm.rs"]
mod tests;
