// src/ir/layers/csharp.rs
//
// Phase F: Layered Encoding — C# Language Layer (Layer 2)
// Translates C#-specific captures into additional IR instructions
// on top of the Core IR.
//
// Extracts:
//   - Class inheritance (extends) from class declarations
//   - Interface implementations
//   - Attributes/annotations
//   - Nullable type markers
//   - async/static/abstract/virtual flags
//
// R-43a: Execution semantics extraction:
//   - async Task/IAsyncEnumerable → SideEffect + ExecutionContext
//   - SignalR realtime context is projected later from resolved C# ancestry
//   - DbSet<T> fields → DataFlow
//   - SaveChangesAsync() → SideEffect("io") + ExecutionContext("async")
//   - TransactionScope → ExecutionContext("transaction_scope")
//   - IDisposable → SideEffect("io")

use super::declaration::interface_parents;
use super::{LanguageLayer, LayerContext};
use crate::compaction::modifiers::strip_csharp_attributes;
use crate::ir::opcodes::{
    CTRL_AWAIT, CTRL_TRY, CoreOp, DATAFLOW_READ, DATAFLOW_WRITE, DeclarationModifier,
    ExecutionContextKind, SideEffectKind,
};
use std::collections::HashMap;

/// Increment when identical C# input can emit different canonical IR.
#[cfg(feature = "csharp")]
pub(crate) const CANONICAL_PRODUCER_GENERATION: u32 = 5;
/// Increment when C# canonical facts change meaning for projection.
#[cfg(feature = "csharp")]
pub(crate) const SEMANTIC_INPUT_GENERATION: u32 = 8;

/// True when `head` (a declaration head, never a full body) carries `word`
/// as a standalone modifier token. Splits on non-identifier characters so
/// `static` inside `SomeStaticType`, `"static ..."`, or `// static` never
/// matches, while `public static class` and `(static ...)` still do.
fn has_head_modifier(head: &str, word: &str) -> bool {
    head.split(|c: char| !(c.is_alphanumeric() || c == '_' || c == '@'))
        .any(|tok| tok == word)
}

/// Cut `head` at the first depth-zero `=>` outside string/char literals.
/// Expression-bodied members carry their body after the arrow; the arrow
/// itself is never part of the signature head.
fn split_depth_zero_arrow(head: &str) -> &str {
    let bytes = head.as_bytes();
    let mut i = 0;
    let mut depth = 0i32;
    let mut str_ch: Option<u8> = None;
    while i < bytes.len() {
        let b = bytes[i];
        if let Some(q) = str_ch {
            if b == b'\\' {
                i += 2;
                continue;
            }
            if b == q {
                str_ch = None;
            }
            i += 1;
            continue;
        }
        match b {
            b'"' | b'\'' => {
                str_ch = Some(b);
                i += 1;
            }
            b'(' | b'[' | b'<' => {
                depth += 1;
                i += 1;
            }
            b')' | b']' | b'>' => {
                depth -= 1;
                i += 1;
            }
            b'=' if depth == 0 && i + 1 < bytes.len() && bytes[i + 1] == b'>' => {
                return &head[..i];
            }
            _ => {
                i += 1;
            }
        }
    }
    head
}

/// C# language layer (Layer 2).
/// Processes C#-specific captures and emits additional CoreOp instructions.
#[derive(Clone, Copy, Default)]
struct ClassSemantics {
    is_disposable: bool,
}

pub struct CSharpLayer {
    class_semantics: HashMap<String, ClassSemantics>,
}

impl CSharpLayer {
    pub fn new() -> Self {
        Self {
            class_semantics: HashMap::new(),
        }
    }

    /// Extract class-level flags (public/abstract/static) from a C# type
    /// declaration. Only the declaration HEAD (modifiers + keyword + name +
    /// base list, i.e. text before the first `{`) is inspected: the layer
    /// receives the full declaration node (head + body), so scanning the
    /// whole node would let a `static` token inside a method body, comment,
    /// string, or nested declaration leak onto the enclosing class.
    fn extract_class_modifiers(class_head: &str) -> Vec<DeclarationModifier> {
        let head = strip_csharp_attributes(class_head);
        let head = head.split('{').next().unwrap_or(head);
        let head = head.lines().next().unwrap_or(head);
        let mut flags = Vec::new();
        if has_head_modifier(head, "public") {
            flags.push(DeclarationModifier::Export);
        }
        if has_head_modifier(head, "abstract") {
            flags.push(DeclarationModifier::Abstract);
        }
        if has_head_modifier(head, "static") {
            flags.push(DeclarationModifier::Static);
        }
        flags
    }

    /// Extract method-level flags (async, static, virtual, override, visibility).
    /// Only the signature HEAD (text before the body `{`, expression arrow,
    /// or trailing `;`) is inspected with word-boundary token matching, so a
    /// `static` call, comment, or string inside the method body can never
    /// mark the method itself as static.
    fn extract_method_modifiers(raw_sig: &str) -> Vec<DeclarationModifier> {
        let head = strip_csharp_attributes(raw_sig);
        let head = head.split('{').next().unwrap_or(head);
        let head = head.split(';').next().unwrap_or(head);
        // Expression-bodied members (`=> expr;`) carry no block body; the
        // arrow and everything after it is body, never signature.
        let head = split_depth_zero_arrow(head);
        let mut flags = Vec::new();
        if has_head_modifier(head, "async") {
            flags.push(DeclarationModifier::Async);
        }
        if has_head_modifier(head, "private") {
            flags.push(DeclarationModifier::Private);
        }
        if has_head_modifier(head, "protected") {
            flags.push(DeclarationModifier::Protected);
        }
        if has_head_modifier(head, "static") {
            flags.push(DeclarationModifier::Static);
        }
        if has_head_modifier(head, "abstract") {
            flags.push(DeclarationModifier::Abstract);
        }
        flags
    }

    /// R-43a: Extract execution semantics from method body text.
    fn extract_method_execution_semantics(method_id: &str, raw_sig: &str) -> Vec<CoreOp> {
        let mut ops = Vec::new();

        // Detect async method via flags or return type patterns
        let is_async = raw_sig.contains("async")
            || raw_sig.contains("Task<")
            || raw_sig.contains("Task ")
            || raw_sig.contains("ValueTask<")
            || raw_sig.contains("ValueTask ")
            || raw_sig.contains("IAsyncEnumerable");

        if is_async {
            ops.push(CoreOp::SideEffect(
                method_id.to_string(),
                SideEffectKind::Async,
            ));
            ops.push(CoreOp::ExecutionContext(
                method_id.to_string(),
                ExecutionContextKind::Async,
            ));

            // Detect IAsyncEnumerable (streaming)
            if raw_sig.contains("IAsyncEnumerable") {
                ops.push(CoreOp::DataFlow(
                    method_id.to_string(),
                    DATAFLOW_READ.to_string(),
                    "async_stream".to_string(),
                ));
            }
        }

        // Detect SaveChangesAsync (EF Core I/O)
        if raw_sig.contains("SaveChangesAsync") {
            ops.push(CoreOp::SideEffect(
                method_id.to_string(),
                SideEffectKind::Io,
            ));
            if !is_async {
                ops.push(CoreOp::ExecutionContext(
                    method_id.to_string(),
                    ExecutionContextKind::Async,
                ));
            }
        }

        // Detect TransactionScope usage
        if raw_sig.contains("TransactionScope") {
            ops.push(CoreOp::ExecutionContext(
                method_id.to_string(),
                ExecutionContextKind::TransactionScope,
            ));
            ops.push(CoreOp::SideEffect(
                method_id.to_string(),
                SideEffectKind::Transaction,
            ));
        }

        // Detect Channel<T> usage (dataflow)
        if raw_sig.contains("ChannelReader") || raw_sig.contains("ChannelWriter") {
            let direction = if raw_sig.contains("ChannelWriter") {
                DATAFLOW_WRITE
            } else {
                DATAFLOW_READ
            };
            ops.push(CoreOp::DataFlow(
                method_id.to_string(),
                direction.to_string(),
                "channel".to_string(),
            ));
        }

        // Detect IQueryable (database query dataflow)
        if raw_sig.contains("IQueryable") {
            ops.push(CoreOp::DataFlow(
                method_id.to_string(),
                DATAFLOW_READ.to_string(),
                "db_query".to_string(),
            ));
        }

        // Detect try/catch
        if raw_sig.contains("try ") || raw_sig.contains("try{") {
            ops.push(CoreOp::ControlFlow(
                method_id.to_string(),
                CTRL_TRY.to_string(),
                "try".to_string(),
            ));
        }

        // Detect await
        if raw_sig.contains("await ") && is_async {
            ops.push(CoreOp::ControlFlow(
                method_id.to_string(),
                CTRL_AWAIT.to_string(),
                "await".to_string(),
            ));
        }

        ops
    }
}

impl Default for CSharpLayer {
    fn default() -> Self {
        Self::new()
    }
}

impl LanguageLayer for CSharpLayer {
    fn name(&self) -> &str {
        "csharp"
    }

    fn process_capture(
        &mut self,
        capture_name: &str,
        raw_text: &str,
        context: &mut LayerContext,
    ) -> Vec<CoreOp> {
        let mut ops = Vec::new();

        match capture_name {
            "class.root" => {
                if let Some(class_id) = &context.current_class {
                    self.class_semantics
                        .insert(class_id.clone(), ClassSemantics::default());
                    let modifiers = Self::extract_class_modifiers(raw_text);
                    if !modifiers.is_empty() {
                        ops.push(CoreOp::ClassModifiers(class_id.clone(), modifiers));
                    }
                }
            }
            "csharp.class_base_type" => {}
            "csharp.class_interface_type" => {
                if let Some(class_id) = &context.current_class
                    && matches!(raw_text.trim(), "IDisposable" | "IAsyncDisposable")
                {
                    self.class_semantics
                        .entry(class_id.clone())
                        .or_default()
                        .is_disposable = true;
                }
            }

            // Nested type roots own their own members but emit no class-level
            // flags through this layer: only `class.root` carries EXPORT/etc.
            // Routing them through the class arm would reset per-class R-43a
            // state and misattribute the enclosing class's flags.
            "interface.root" => {
                if let Some(interface_id) = &context.current_interface {
                    let declaration = strip_csharp_attributes(raw_text);
                    for parent in interface_parents(declaration, ":") {
                        ops.push(CoreOp::InterfaceExtends(interface_id.clone(), parent));
                    }
                    let modifiers = Self::extract_class_modifiers(raw_text);
                    if !modifiers.is_empty() {
                        ops.push(CoreOp::InterfaceModifiers(interface_id.clone(), modifiers));
                    }
                }
            }
            "struct.root" | "enum.root" | "trait.root" | "record.root" => {}
            "method.root" => {
                // Extract method-level flags
                let modifiers = Self::extract_method_modifiers(raw_text);
                if let Some(method_id) = &context.current_method {
                    if !modifiers.is_empty() {
                        ops.push(CoreOp::MethodModifiers(method_id.clone(), modifiers));
                    }

                    // R-43a: Extract execution semantics
                    let exec_ops = Self::extract_method_execution_semantics(method_id, raw_text);
                    ops.extend(exec_ops);

                    let class_semantics = context
                        .current_class
                        .as_ref()
                        .and_then(|class_id| self.class_semantics.get(class_id))
                        .copied()
                        .unwrap_or_default();

                    // R-43a: Per-method IDisposable side-effect
                    if class_semantics.is_disposable {
                        ops.push(CoreOp::SideEffect(method_id.clone(), SideEffectKind::Io));
                    }
                }
            }
            _ => {}
        }

        ops
    }

    fn finalize(&mut self, context: &mut LayerContext) -> Vec<CoreOp> {
        let _ = context;
        self.class_semantics.clear();
        Vec::new()
    }
}
