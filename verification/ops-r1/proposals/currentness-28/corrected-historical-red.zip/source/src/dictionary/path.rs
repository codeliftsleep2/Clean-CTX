// src/dictionary/path.rs
//
// Maps absolute file paths to short aliases (e.g., α1, α2).
//
// F-36 (FAANG audit): uses a `HashMap` for the reverse lookup (path →
// alias) so `get_or_create_alias` is O(1) instead of O(n).

use std::collections::HashMap;

pub struct PathDictionary {
    /// alias → path (e.g. "α1" → "/project/src/main.ts")
    forward: HashMap<String, String>,
    /// path → alias (the reverse index for O(1) lookup).
    ///
    /// Keys are CANONICAL paths (see `normalize_alias_key`) so that
    /// different caller-supplied spellings of the same physical file
    /// converge onto one stable alias.
    reverse: HashMap<String, String>,
    /// bundle alias → component name (e.g. "Φ1" → "user-card.component")
    bundle_aliases: HashMap<String, String>,
    /// component name → bundle alias (reverse index for O(1) lookup)
    bundle_reverse: HashMap<String, String>,
}

/// Normalize a caller-supplied path to THE canonical file identity used by
/// every in-session stateful consumer.
///
/// Non-CBM audit 2026-08-25 #3: handlers mix absolute paths and
/// workspace-relative/joined spellings of the SAME file (`resolve_file_path_checked`
/// deliberately returns the caller-shaped path), so keying on the raw
/// argument fragmented identity — one file could hold two aliases
/// (visible as duplicate `α` entries in `§PATHMAP`), silently splitting
/// every alias-keyed state (IR context, text-delta baselines, LLM cache).
///
/// IDENT-001 extension: `SessionStats` keys through this same helper so
/// stats aggregate one physical file into one row. The SQLite persistence
/// layer is the DELIBERATE exception (durable rows keep caller-shaped
/// keys; migrating would orphan historical baselines — pinned by the
/// `persistence_keys_are_caller_shaped_by_contract` test).
///
/// Resolution: `fs::canonicalize` when possible; on Windows the verbatim
/// (`\\?\`) prefix is stripped so stored keys stay human-readable.
/// Unresolvable paths (deleted files, synthetic strings used by tests)
/// fall back to the raw argument unchanged.
pub(crate) fn canonical_identity_key(path: &str) -> String {
    match std::fs::canonicalize(path) {
        Ok(canon) => {
            let s = canon.to_string_lossy();
            #[cfg(windows)]
            {
                if let Some(unc) = s.strip_prefix(r"\\?\UNC\") {
                    format!(r"\\{unc}")
                } else {
                    s.strip_prefix(r"\\?\").unwrap_or(&s).to_string()
                }
            }
            #[cfg(not(windows))]
            {
                s.into_owned()
            }
        }
        Err(_) => path.to_string(),
    }
}

impl Default for PathDictionary {
    fn default() -> Self {
        Self::new()
    }
}

impl PathDictionary {
    /// Existing session path bindings; these carry no current semantic proof.
    pub(crate) fn known_paths(&self) -> impl Iterator<Item = &str> {
        self.forward.values().map(String::as_str)
    }

    pub fn new() -> Self {
        Self {
            forward: HashMap::new(),
            reverse: HashMap::new(),
            bundle_aliases: HashMap::new(),
            bundle_reverse: HashMap::new(),
        }
    }

    pub fn get_or_create_alias(&mut self, absolute_path: String) -> String {
        // Identity invariant: ONE physical file ⇒ ONE stable alias,
        // regardless of the path form the caller supplies. Fast-path the
        // exact-string hit first so repeat calls with identical arguments
        // stay O(1) without touching the filesystem; otherwise resolve to
        // the canonical key before consulting the map.
        // Non-CBM audit 2026-08-25 #3.
        if let Some(alias) = self.reverse.get(&absolute_path).cloned() {
            return alias;
        }
        let key = canonical_identity_key(&absolute_path);
        if let Some(alias) = self.reverse.get(&key).cloned() {
            alias
        } else {
            let next = self
                .forward
                .keys()
                .filter_map(|alias| alias.strip_prefix('α')?.parse::<usize>().ok())
                .max()
                .unwrap_or(0)
                + 1;
            let alias = format!("α{next}");
            self.reverse.insert(key.clone(), alias.clone());
            self.forward.insert(alias.clone(), key);
            alias
        }
    }

    /// Resolve a session-local alias back to its durable canonical path.
    pub fn path_for_alias(&self, alias: &str) -> Option<&str> {
        self.forward.get(alias).map(String::as_str)
    }

    /// Resolve an already-registered durable path without creating session
    /// identity as a side effect.
    pub fn alias_for_path(&self, absolute_path: &str) -> Option<&str> {
        self.reverse
            .get(absolute_path)
            .or_else(|| self.reverse.get(&canonical_identity_key(absolute_path)))
            .map(String::as_str)
    }

    /// Remove one exact path/alias ownership pair without affecting any other
    /// dictionary entry.
    pub fn remove_path_alias(&mut self, alias: &str, absolute_path: &str) -> bool {
        let expected = canonical_identity_key(absolute_path);
        if self.forward.get(alias) != Some(&expected) {
            return false;
        }
        self.forward.remove(alias);
        self.reverse.retain(|_, mapped_alias| mapped_alias != alias);
        true
    }

    /// Format the full session-global PATHMAP as a footer.
    ///
    /// Serializes **every** alias in the session dictionary. Used by tests
    /// and workspace-level compression. For single-file responses prefer
    /// [`format_footer_for_aliases`] which emits only the aliases actually
    /// referenced by that response.
    pub fn format_footer(&self) -> String {
        let mut footer = String::from("\n§PATHMAP\n");
        for (alias, real_path) in &self.forward {
            footer.push_str(&format!("  {} = {}\n", alias, real_path));
        }
        footer
    }

    /// Format a request-scoped PATHMAP containing only the listed aliases.
    ///
    /// Produces the same `§PATHMAP` header and line format as [`format_footer`],
    /// but only includes aliases that exist in `required_aliases`. Aliases that
    /// have not been registered yet are silently omitted (they will not be
    /// referenced by the response anyway).
    ///
    /// This is the correct method for single-file responses like
    /// `provide_code_context`, `compress_code_context`, and `restore_context`,
    /// where the rendered output never references other files' aliases.
    ///
    /// For workspace manifests and other multi-file outputs that legitimately
    /// reference many aliases, use [`format_footer`] or pass the complete
    /// set of referenced aliases.
    pub fn format_footer_for_aliases(&self, required_aliases: &[&str]) -> String {
        let mut footer = String::from("\n§PATHMAP\n");
        for alias in required_aliases {
            if let Some(real_path) = self.forward.get(*alias) {
                footer.push_str(&format!("  {} = {}\n", alias, real_path));
            }
        }
        footer
    }

    // ------------------------------------------------------------------
    // Bundle aliases (Φ1, Φ2, …) — Tier 2 of the Angular Meta-Layer.
    // ------------------------------------------------------------------

    /// Register a new bundle alias for a component name.
    ///
    /// Returns the bundle alias (e.g. `"Φ1"`). If the component
    /// already has a bundle alias, the existing one is returned.
    pub fn get_or_create_bundle_alias(&mut self, component_name: String) -> String {
        if let Some(alias) = self.bundle_reverse.get(&component_name).cloned() {
            alias
        } else {
            let alias = format!("Φ{}", self.bundle_aliases.len() + 1);
            self.bundle_reverse
                .insert(component_name.clone(), alias.clone());
            self.bundle_aliases.insert(alias.clone(), component_name);
            alias
        }
    }

    /// Look up the bundle alias for a component name, if one exists.
    pub fn get_bundle_alias(&self, component_name: &str) -> Option<&str> {
        self.bundle_reverse.get(component_name).map(|s| s.as_str())
    }
}

#[cfg(test)]
#[path = "../tests/dictionary/path.rs"]
mod tests;
