// src/diff/differ.rs
//
// AST-level diff comparator. Takes two `CapturedStructure`s and emits a
// sequence of `DiffAction`s describing what changed.

use std::collections::{BTreeMap, BTreeSet};

use super::action::{DiffAction, DiffKind, DiffTarget};
use super::keys::{field_key, group_by_key, group_strings_by_key, method_key, summarize_class};
use super::overload_lookup::MethodLookup;
use super::snapshot::{CapturedClass, CapturedMethod, CapturedStructure};

/// Compute the AST-level diff between two snapshots.
pub fn diff_snapshots(
    baseline: &CapturedStructure,
    current: &CapturedStructure,
) -> Vec<DiffAction> {
    #[cfg(test)]
    crate::work_observations_af_perf_002::update(|c| c.diff.comparisons += 1);
    let mut actions: Vec<DiffAction> = Vec::new();

    // ---- Imports ---------------------------------------------------------
    let base_imports: BTreeMap<&str, ()> =
        baseline.imports.iter().map(|s| (s.as_str(), ())).collect();
    let cur_imports: BTreeMap<&str, ()> =
        current.imports.iter().map(|s| (s.as_str(), ())).collect();
    for imp in &current.imports {
        if !base_imports.contains_key(imp.as_str()) {
            actions.push(new_action(
                DiffKind::Added,
                DiffTarget::Import,
                "import",
                imp.clone(),
                String::new(),
            ));
        }
    }
    for imp in &baseline.imports {
        if !cur_imports.contains_key(imp.as_str()) {
            actions.push(new_action(
                DiffKind::Removed,
                DiffTarget::Import,
                "import",
                imp.clone(),
                String::new(),
            ));
        }
    }

    // ---- Classes ---------------------------------------------------------
    let cur_by_name: BTreeMap<&str, &CapturedClass> = current
        .classes
        .iter()
        .map(|c| (c.name.as_str(), c))
        .collect();

    let mut seen: BTreeSet<String> = BTreeSet::new();
    for base_cls in &baseline.classes {
        seen.insert(base_cls.name.clone());
        match cur_by_name.get(base_cls.name.as_str()) {
            None => {
                actions.push(new_action(
                    DiffKind::Removed,
                    DiffTarget::Class,
                    &format!("class {}", base_cls.name),
                    summarize_class(base_cls),
                    String::new(),
                ));
            }
            Some(cur_cls) => {
                let child_actions = diff_class(base_cls, cur_cls);
                // A class is "unchanged" only if no child element was
                // added/removed/modified AND the class-level metadata
                // (base class / interface list) is identical. F-04 diff
                // audit: previously a change to `class Foo : BaseA` →
                // `class Foo : BaseB` reported the class as unchanged.
                let class_meta_changed = base_cls.class_meta != cur_cls.class_meta;
                let has_child_changes = child_actions.iter().any(|a| a.kind != DiffKind::Unchanged);
                if class_meta_changed && !has_child_changes {
                    actions.push(new_action(
                        DiffKind::Modified,
                        DiffTarget::Class,
                        &format!("class {}", base_cls.name),
                        cur_cls.class_meta.clone(),
                        base_cls.class_meta.clone(),
                    ));
                } else if has_child_changes {
                    actions.push(new_action(
                        DiffKind::Modified,
                        DiffTarget::Class,
                        &format!("class {}", base_cls.name),
                        String::new(),
                        String::new(),
                    ));
                    actions.extend(child_actions);
                } else {
                    actions.push(new_action(
                        DiffKind::Unchanged,
                        DiffTarget::Class,
                        &format!("class {}", base_cls.name),
                        String::new(),
                        String::new(),
                    ));
                }
            }
        }
    }
    for cur_cls in &current.classes {
        if !seen.contains(&cur_cls.name) {
            actions.push(new_action(
                DiffKind::Added,
                DiffTarget::Class,
                &format!("class {}", cur_cls.name),
                summarize_class(cur_cls),
                String::new(),
            ));
        }
    }

    // ---- Orphan fields ---------------------------------------------------
    diff_orphan_fields(
        &baseline.orphan_fields,
        &current.orphan_fields,
        &mut actions,
    );

    // ---- Orphan methods (top-level functions) ----------------------------
    // G2-2 diff audit: files with only top-level functions (TS `function`,
    // C# top-level statements) previously produced zero methods and any
    // change to them was a false negative for `diff_commits`. Diff them
    // with the same method-grouping logic used inside classes.
    diff_methods(
        &baseline.orphan_methods,
        &current.orphan_methods,
        &mut actions,
    );

    actions
}

/// Construct a `DiffAction` with an empty reason hint.
fn new_action(
    kind: DiffKind,
    target: DiffTarget,
    label: &str,
    detail: String,
    previous: String,
) -> DiffAction {
    DiffAction {
        kind,
        target,
        label: label.to_string(),
        detail,
        previous_detail: previous,
        reason_hint: String::new(),
    }
}

/// Diff two collections of orphan/top-level field strings as Added/Removed.
fn diff_orphan_fields(baseline: &[String], current: &[String], actions: &mut Vec<DiffAction>) {
    let base: BTreeMap<&str, ()> = baseline.iter().map(|s| (s.as_str(), ())).collect();
    let cur: BTreeMap<&str, ()> = current.iter().map(|s| (s.as_str(), ())).collect();
    for f in current {
        if !base.contains_key(f.as_str()) {
            actions.push(new_action(
                DiffKind::Added,
                DiffTarget::Field,
                "field",
                f.clone(),
                String::new(),
            ));
        }
    }
    for f in baseline {
        if !cur.contains_key(f.as_str()) {
            actions.push(new_action(
                DiffKind::Removed,
                DiffTarget::Field,
                "field",
                f.clone(),
                String::new(),
            ));
        }
    }
}

/// Diff two method collections (class methods or top-level functions) by
/// method name, emitting Unchanged/Added/Removed/Modified per method.
/// G2-2 audit: extracted from `diff_class` so top-level functions reuse
/// the same grouping logic.
fn diff_methods(base: &[CapturedMethod], cur: &[CapturedMethod], actions: &mut Vec<DiffAction>) {
    #[cfg(test)]
    crate::work_observations_af_perf_002::update(|c| {
        c.diff.group_records[0] += base.len();
        c.diff.group_records[1] += cur.len();
    });
    let bg = group_by_key(base, |m| method_key(&m.sig));
    let cg = group_by_key(cur, |m| method_key(&m.sig));
    let mut keys: BTreeSet<String> = bg.keys().cloned().collect();
    keys.extend(cg.keys().cloned());

    for key in keys {
        match (bg.get(&key), cg.get(&key)) {
            (None, Some(g)) => {
                for m in g {
                    actions.push(method_action(DiffKind::Added, &key, m, "", ""));
                }
            }
            (Some(g), None) => {
                for m in g {
                    actions.push(method_action(DiffKind::Removed, &key, m, "", ""));
                }
            }
            (Some(g1), Some(g2)) => {
                let mut base_used = vec![false; g1.len()];
                let mut cur_used = vec![false; g2.len()];

                let mut lookup = MethodLookup::new(g2);

                // First preserve exact declarations regardless of overload
                // insertion or ordering. Name-group index is not identity.
                for (base_idx, base_method) in g1.iter().enumerate() {
                    if let Some(cur_idx) = lookup.exact(base_method, &cur_used) {
                        let current_method = g2[cur_idx];
                        #[cfg(test)]
                        crate::work_observations_af_perf_002::overload_pair(
                            &key, 0, base_idx, cur_idx,
                        );
                        base_used[base_idx] = true;
                        cur_used[cur_idx] = true;
                        actions.push(method_action(
                            DiffKind::Unchanged,
                            &key,
                            current_method,
                            "",
                            "",
                        ));
                    }
                }

                // Complete global exact phase before any signature consumption.

                // A stable visible signature independently proves continuity
                // for body, marker, and producer-evidence changes.
                for (base_idx, base_method) in g1.iter().enumerate() {
                    if base_used[base_idx] {
                        continue;
                    }
                    if let Some(cur_idx) = lookup.signature(&base_method.sig, &cur_used) {
                        let current_method = g2[cur_idx];
                        #[cfg(test)]
                        crate::work_observations_af_perf_002::overload_pair(
                            &key, 1, base_idx, cur_idx,
                        );
                        base_used[base_idx] = true;
                        cur_used[cur_idx] = true;
                        push_method_comparison(actions, &key, base_method, current_method);
                    }
                }

                drop(lookup);

                let remaining_base: Vec<usize> = base_used
                    .iter()
                    .enumerate()
                    .filter_map(|(idx, used)| (!used).then_some(idx))
                    .collect();
                let remaining_cur: Vec<usize> = cur_used
                    .iter()
                    .enumerate()
                    .filter_map(|(idx, used)| (!used).then_some(idx))
                    .collect();

                // A one-to-one remainder in a name group is the existing
                // bounded signature-change contract. Ambiguous overload
                // remainders are truthfully remove/add rather than guessed.
                if let ([base_idx], [cur_idx]) =
                    (remaining_base.as_slice(), remaining_cur.as_slice())
                {
                    #[cfg(test)]
                    crate::work_observations_af_perf_002::overload_pair(
                        &key, 2, *base_idx, *cur_idx,
                    );
                    base_used[*base_idx] = true;
                    cur_used[*cur_idx] = true;
                    push_method_comparison(actions, &key, g1[*base_idx], g2[*cur_idx]);
                }

                for (idx, method) in g1.iter().enumerate() {
                    if !base_used[idx] {
                        actions.push(method_action(DiffKind::Removed, &key, method, "", ""));
                    }
                }
                for (idx, method) in g2.iter().enumerate() {
                    if !cur_used[idx] {
                        actions.push(method_action(DiffKind::Added, &key, method, "", ""));
                    }
                }
            }
            (None, None) => {} // union of keys — unreachable, but Rust requires the arm
        }
    }
}

fn push_method_comparison(
    actions: &mut Vec<DiffAction>,
    key: &str,
    baseline: &CapturedMethod,
    current: &CapturedMethod,
) {
    if baseline == current {
        actions.push(method_action(DiffKind::Unchanged, key, current, "", ""));
        return;
    }
    let reason = if baseline.declaration != current.declaration {
        "declaration"
    } else if baseline.sig != current.sig {
        "sig"
    } else if baseline.markers != current.markers && baseline.body == current.body {
        "markers"
    } else {
        "body"
    };
    actions.push(method_action(
        DiffKind::Modified,
        key,
        current,
        &baseline.sig,
        reason,
    ));
}

fn method_action(
    kind: DiffKind,
    key: &str,
    m: &CapturedMethod,
    previous_sig: &str,
    reason: &str,
) -> DiffAction {
    DiffAction {
        kind,
        target: DiffTarget::Method,
        label: format!("method {}", key),
        detail: m.sig.clone(),
        previous_detail: previous_sig.to_string(),
        reason_hint: reason.to_string(),
    }
}

fn diff_class(baseline: &CapturedClass, current: &CapturedClass) -> Vec<DiffAction> {
    let mut actions: Vec<DiffAction> = Vec::new();

    // Methods: key by method name (part before `(`).
    diff_methods(&baseline.methods, &current.methods, &mut actions);

    // Fields: key by name (part before `:`).
    let base_fields = group_strings_by_key(&baseline.fields, field_key);
    let cur_fields = group_strings_by_key(&current.fields, field_key);

    for (key, base_group) in &base_fields {
        match cur_fields.get(key) {
            None => {
                for f in base_group {
                    actions.push(new_action(
                        DiffKind::Removed,
                        DiffTarget::Field,
                        &format!("field {}", key),
                        f.clone(),
                        String::new(),
                    ));
                }
            }
            Some(cur_group) => {
                let n = base_group.len().max(cur_group.len());
                for i in 0..n {
                    match (base_group.get(i), cur_group.get(i)) {
                        (Some(b), Some(c)) => {
                            if b == c {
                                actions.push(new_action(
                                    DiffKind::Unchanged,
                                    DiffTarget::Field,
                                    &format!("field {}", key),
                                    c.clone(),
                                    String::new(),
                                ));
                            } else {
                                actions.push(new_action(
                                    DiffKind::Modified,
                                    DiffTarget::Field,
                                    &format!("field {}", key),
                                    c.clone(),
                                    b.clone(),
                                ));
                            }
                        }
                        (Some(b), None) => actions.push(new_action(
                            DiffKind::Removed,
                            DiffTarget::Field,
                            &format!("field {}", key),
                            b.clone(),
                            String::new(),
                        )),
                        (None, Some(c)) => actions.push(new_action(
                            DiffKind::Added,
                            DiffTarget::Field,
                            &format!("field {}", key),
                            c.clone(),
                            String::new(),
                        )),
                        _ => {}
                    }
                }
            }
        }
    }
    for (key, cur_group) in &cur_fields {
        if !base_fields.contains_key(key) {
            for f in cur_group {
                actions.push(new_action(
                    DiffKind::Added,
                    DiffTarget::Field,
                    &format!("field {}", key),
                    f.clone(),
                    String::new(),
                ));
            }
        }
    }

    actions
}

#[cfg(test)]
#[path = "../tests/diff/differ.rs"]
mod tests;

#[cfg(test)]
#[path = "../tests/diff/overload_equivalence_af_perf_002.rs"]
pub(crate) mod overload_equivalence;

#[cfg(test)]
#[path = "../tests/diff/overload_cost_static_af_perf_002.rs"]
mod overload_acceptance;

#[cfg(test)]
#[path = "../tests/diff/overload_alternatives_af_perf_002.rs"]
pub(crate) mod overload_alternatives;
