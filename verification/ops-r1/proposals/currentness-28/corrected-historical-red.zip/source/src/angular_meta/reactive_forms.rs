//! Angular Reactive Forms source-shape detector.
//!
//! The layer is deliberately string-based and independent from template
//! extraction. It activates only when an `@angular/forms` import and a
//! statically recognizable reactive-form construction coexist.

use crate::angular_meta::phi::PhiMarker;
use crate::angular_meta::util::{
    consume_call_expression, extract_decl_name, find_matching_brace, split_top_level,
};
use crate::compression::Fidelity;

#[path = "reactive_forms_validators.rs"]
mod validators;
use validators::{validators_from_control_body, validators_from_value};

#[path = "reactive_forms_imports.rs"]
mod imports;
use imports::{
    ImportedForms, extract_builder_aliases, extract_forms_imports, has_construction_hint,
};

#[path = "reactive_forms_normalize.rs"]
mod normalize;
use normalize::{merge_fields, normalize_artifacts};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ReactiveFormKind {
    Form,
    Control,
    Array,
    Validator,
}

impl PhiMarker for ReactiveFormKind {
    fn marker_prefix(self) -> &'static str {
        match self {
            Self::Form => "Φform:",
            Self::Control => "Φcontrol:",
            Self::Array => "Φarray:",
            Self::Validator => "Φvalidator:",
        }
    }

    fn expansion(self) -> &'static str {
        match self {
            Self::Form => "FormGroup",
            Self::Control => "FormControl",
            Self::Array => "FormArray",
            Self::Validator => "Validator",
        }
    }

    fn all_in_expand_order() -> &'static [Self] {
        &[Self::Validator, Self::Control, Self::Array, Self::Form]
    }

    fn from_token(token: &str) -> Option<Self> {
        match token {
            "Φform" => Some(Self::Form),
            "Φcontrol" => Some(Self::Control),
            "Φarray" => Some(Self::Array),
            "Φvalidator" => Some(Self::Validator),
            _ => None,
        }
    }

    fn token(self) -> &'static str {
        match self {
            Self::Form => "Φform",
            Self::Control => "Φcontrol",
            Self::Array => "Φarray",
            Self::Validator => "Φvalidator",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FieldKind {
    Control,
    Group(Vec<FieldDecl>),
    Array(Vec<FieldDecl>),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct FieldDecl {
    name: String,
    kind: FieldKind,
    validators: Vec<String>,
}

#[derive(Debug, Clone)]
struct FormDecl {
    name: String,
    fields: Vec<FieldDecl>,
}

#[derive(Debug, Clone)]
enum FormArtifact {
    Form(FormDecl),
    Field(FieldDecl),
}

#[derive(Debug, Clone, Default)]
pub struct ReactiveFormShape {
    artifacts: Vec<FormArtifact>,
}

impl ReactiveFormShape {
    pub fn is_empty(&self) -> bool {
        self.artifacts.is_empty()
    }

    pub fn render(&self, fidelity: Fidelity) -> String {
        let mut lines = Vec::new();
        for artifact in &self.artifacts {
            match artifact {
                FormArtifact::Form(form) => render_form(form, fidelity, &mut lines),
                FormArtifact::Field(field) if fidelity != Fidelity::Low => {
                    render_field(field, fidelity, 1, &mut lines);
                }
                FormArtifact::Field(_) => {}
            }
        }
        if lines.is_empty() {
            return String::new();
        }
        format!("// --- Φ Forms Meta ---\n{}\n", lines.join("\n"))
    }
}

fn render_form(form: &FormDecl, fidelity: Fidelity, lines: &mut Vec<String>) {
    if fidelity == Fidelity::Low {
        lines.push(format!("  Φform:{}", form.name));
        return;
    }
    let controls = form
        .fields
        .iter()
        .map(|field| field.name.as_str())
        .collect::<Vec<_>>()
        .join(",");
    if controls.is_empty() {
        lines.push(format!("  Φform:{}", form.name));
    } else {
        lines.push(format!("  Φform:{} ctrls=[{}]", form.name, controls));
    }
    for field in &form.fields {
        render_field(field, fidelity, 1, lines);
    }
}

fn render_field(field: &FieldDecl, fidelity: Fidelity, depth: usize, lines: &mut Vec<String>) {
    let indent = "  ".repeat(depth);
    match &field.kind {
        FieldKind::Control => lines.push(format!("{indent}Φcontrol:{}", field.name)),
        FieldKind::Group(fields) if is_high_detail(fidelity) => {
            let controls = fields
                .iter()
                .map(|field| field.name.as_str())
                .collect::<Vec<_>>()
                .join(",");
            if controls.is_empty() {
                lines.push(format!("{indent}Φform:{}", field.name));
            } else {
                lines.push(format!("{indent}Φform:{} ctrls=[{controls}]", field.name));
            }
            for child in fields {
                render_field(child, fidelity, depth + 1, lines);
            }
        }
        FieldKind::Group(_) => {}
        FieldKind::Array(fields) if is_high_detail(fidelity) && !fields.is_empty() => {
            lines.push(format!(
                "{indent}Φarray:{} ctrls=[{}]",
                field.name,
                fields
                    .iter()
                    .map(|field| field.name.as_str())
                    .collect::<Vec<_>>()
                    .join(",")
            ));
        }
        FieldKind::Array(_) => lines.push(format!("{indent}Φarray:{}", field.name)),
    }
    if is_high_detail(fidelity) && !field.validators.is_empty() {
        lines.push(format!(
            "{indent}Φvalidator:{} → [{}]",
            field.name,
            field.validators.join(",")
        ));
    }
}

fn is_high_detail(fidelity: Fidelity) -> bool {
    matches!(
        fidelity,
        Fidelity::High | Fidelity::Edit | Fidelity::Verbatim
    )
}

pub fn has_reactive_forms(source: &str) -> bool {
    extract_reactive_form_shape(source, Fidelity::Low).is_some()
}

pub fn extract_reactive_form_shape(source: &str, _fidelity: Fidelity) -> Option<ReactiveFormShape> {
    let lexical_regions = crate::meta_util::LexicalRegions::new(source);
    extract_reactive_form_shape_with_regions(source, _fidelity, &lexical_regions)
}

pub(crate) fn extract_reactive_form_shape_with_regions(
    source: &str,
    _fidelity: Fidelity,
    lexical_regions: &crate::meta_util::LexicalRegions,
) -> Option<ReactiveFormShape> {
    let imports = extract_forms_imports(source, lexical_regions);
    if imports.is_empty() || !has_construction_hint(source, &imports) {
        return None;
    }
    let builder_aliases = extract_builder_aliases(source, &imports.builders, lexical_regions);
    let candidates = find_candidates(source, &imports, &builder_aliases, lexical_regions);
    let mut artifacts = Vec::new();
    let mut consumed_until = 0usize;

    for candidate in candidates {
        if candidate.start < consumed_until {
            continue;
        }
        let Some((consumed, body)) = consume_call_expression(source, candidate.open_paren) else {
            continue;
        };
        let end = candidate.open_paren + consumed;
        let Some(name) = extract_decl_name(&source[..candidate.start]) else {
            continue;
        };
        match candidate.kind {
            ConstructionKind::Group => {
                artifacts.push(FormArtifact::Form(FormDecl {
                    name,
                    fields: extract_group_fields(&body, &imports, &builder_aliases),
                }));
            }
            ConstructionKind::Control => artifacts.push(FormArtifact::Field(FieldDecl {
                name,
                kind: FieldKind::Control,
                validators: validators_from_control_body(&body),
            })),
            ConstructionKind::Array => artifacts.push(FormArtifact::Field(FieldDecl {
                name,
                kind: FieldKind::Array(nested_array_fields(&body, &imports, &builder_aliases)),
                validators: Vec::new(),
            })),
        }
        consumed_until = end;
    }

    normalize_artifacts(&mut artifacts);
    (!artifacts.is_empty()).then_some(ReactiveFormShape { artifacts })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ConstructionKind {
    Group,
    Control,
    Array,
}

#[derive(Debug, Clone, Copy)]
struct Candidate {
    start: usize,
    open_paren: usize,
    kind: ConstructionKind,
}

fn find_candidates(
    source: &str,
    imports: &ImportedForms,
    builder_aliases: &[String],
    lexical_regions: &crate::meta_util::LexicalRegions,
) -> Vec<Candidate> {
    let mut candidates = Vec::new();
    collect_explicit_candidates(
        source,
        &imports.groups,
        ConstructionKind::Group,
        &mut candidates,
        lexical_regions,
    );
    collect_explicit_candidates(
        source,
        &imports.controls,
        ConstructionKind::Control,
        &mut candidates,
        lexical_regions,
    );
    collect_explicit_candidates(
        source,
        &imports.arrays,
        ConstructionKind::Array,
        &mut candidates,
        lexical_regions,
    );
    collect_builder_candidates(
        source,
        builder_aliases,
        "group",
        ConstructionKind::Group,
        &mut candidates,
        lexical_regions,
    );
    collect_builder_candidates(
        source,
        builder_aliases,
        "control",
        ConstructionKind::Control,
        &mut candidates,
        lexical_regions,
    );
    collect_builder_candidates(
        source,
        builder_aliases,
        "array",
        ConstructionKind::Array,
        &mut candidates,
        lexical_regions,
    );
    candidates.sort_by_key(|candidate| (candidate.start, candidate.open_paren));
    candidates
}

fn collect_explicit_candidates(
    source: &str,
    names: &[String],
    kind: ConstructionKind,
    candidates: &mut Vec<Candidate>,
    lexical_regions: &crate::meta_util::LexicalRegions,
) {
    for name in names {
        let pattern = format!("new {name}");
        for (start, _) in source.match_indices(&pattern) {
            if lexical_regions.contains(start) || !has_word_boundary(source, start) {
                continue;
            }
            let after_name = start + pattern.len();
            let whitespace = source[after_name..].len() - source[after_name..].trim_start().len();
            let open = after_name + whitespace;
            if source.as_bytes().get(open) == Some(&b'(') {
                candidates.push(Candidate {
                    start,
                    open_paren: open,
                    kind,
                });
            }
        }
    }
}

fn collect_builder_candidates(
    source: &str,
    aliases: &[String],
    method: &str,
    kind: ConstructionKind,
    candidates: &mut Vec<Candidate>,
    lexical_regions: &crate::meta_util::LexicalRegions,
) {
    let pattern = format!(".{method}");
    for (dot, _) in source.match_indices(&pattern) {
        if lexical_regions.contains(dot) {
            continue;
        }
        let after_method = dot + pattern.len();
        let whitespace = source[after_method..].len() - source[after_method..].trim_start().len();
        let open = after_method + whitespace;
        if source.as_bytes().get(open) != Some(&b'(') {
            continue;
        }
        let Some((receiver_start, receiver)) = receiver_before(source, dot) else {
            continue;
        };
        if !aliases.iter().any(|alias| alias == receiver) {
            continue;
        }
        candidates.push(Candidate {
            start: expression_start(source, receiver_start),
            open_paren: open,
            kind,
        });
    }
}

fn receiver_before(source: &str, dot: usize) -> Option<(usize, &str)> {
    let bytes = source.as_bytes();
    let mut end = dot;
    while end > 0 && bytes[end - 1].is_ascii_whitespace() {
        end -= 1;
    }
    let mut start = end;
    while start > 0 && is_identifier_byte(bytes[start - 1]) {
        start -= 1;
    }
    (start < end).then_some((start, &source[start..end]))
}

fn expression_start(source: &str, receiver_start: usize) -> usize {
    let bytes = source.as_bytes();
    let mut start = receiver_start;
    while start > 0 && bytes[start - 1] == b'.' {
        let mut preceding = start - 1;
        while preceding > 0 && is_identifier_byte(bytes[preceding - 1]) {
            preceding -= 1;
        }
        if preceding == start - 1 {
            break;
        }
        start = preceding;
    }
    start
}

fn has_word_boundary(source: &str, start: usize) -> bool {
    start == 0 || !is_identifier_byte(source.as_bytes()[start - 1])
}

fn is_identifier_byte(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'$')
}

fn is_identifier(value: &str) -> bool {
    let mut chars = value.chars();
    chars
        .next()
        .is_some_and(|first| first.is_alphabetic() || matches!(first, '_' | '$'))
        && chars.all(|ch| ch.is_alphanumeric() || matches!(ch, '_' | '$'))
}

fn extract_group_fields(
    body: &str,
    imports: &ImportedForms,
    builder_aliases: &[String],
) -> Vec<FieldDecl> {
    let Some(object) = first_object_argument(body) else {
        return Vec::new();
    };
    let mut fields = Vec::new();
    for entry in split_top_level(&object, ',') {
        let parts = split_top_level(&entry, ':');
        if parts.len() < 2 {
            continue;
        }
        let Some(name) = static_property_name(&parts[0]) else {
            continue;
        };
        let value = parts[1..].join(":");
        let value_regions = crate::meta_util::LexicalRegions::new(&value);
        let construction = find_candidates(&value, imports, builder_aliases, &value_regions)
            .first()
            .map(|candidate| candidate.kind);
        let kind = match construction {
            Some(ConstructionKind::Group) => {
                FieldKind::Group(nested_group_fields(&value, imports, builder_aliases))
            }
            Some(ConstructionKind::Array) => {
                FieldKind::Array(nested_array_fields(&value, imports, builder_aliases))
            }
            _ => FieldKind::Control,
        };
        let validators = matches!(&kind, FieldKind::Control)
            .then(|| validators_from_value(&value, imports, builder_aliases))
            .unwrap_or_default();
        fields.push(FieldDecl {
            name,
            kind,
            validators,
        });
    }
    fields
}

fn first_object_argument(body: &str) -> Option<String> {
    let first = split_top_level(body, ',').into_iter().next()?;
    let trimmed = first.trim();
    if !trimmed.starts_with('{') {
        return None;
    }
    let close = find_matching_brace(trimmed, '{')?;
    (close == trimmed.len() - 1).then(|| trimmed[1..close].to_string())
}

fn static_property_name(raw: &str) -> Option<String> {
    let key = raw.trim();
    if key.len() >= 2
        && ((key.starts_with('\'') && key.ends_with('\''))
            || (key.starts_with('"') && key.ends_with('"')))
    {
        let unquoted = &key[1..key.len() - 1];
        return is_identifier(unquoted).then(|| unquoted.to_string());
    }
    is_identifier(key).then(|| key.to_string())
}

fn nested_group_fields(
    body: &str,
    imports: &ImportedForms,
    builder_aliases: &[String],
) -> Vec<FieldDecl> {
    let lexical_regions = crate::meta_util::LexicalRegions::new(body);
    let candidates = find_candidates(body, imports, builder_aliases, &lexical_regions);
    let Some(group) = candidates
        .iter()
        .find(|candidate| candidate.kind == ConstructionKind::Group)
    else {
        return Vec::new();
    };
    let Some((_, group_body)) = consume_call_expression(body, group.open_paren) else {
        return Vec::new();
    };
    extract_group_fields(&group_body, imports, builder_aliases)
}

fn nested_array_fields(
    body: &str,
    imports: &ImportedForms,
    builder_aliases: &[String],
) -> Vec<FieldDecl> {
    let lexical_regions = crate::meta_util::LexicalRegions::new(body);
    let candidates = find_candidates(body, imports, builder_aliases, &lexical_regions);
    let mut fields = Vec::new();
    let mut consumed_until = 0;
    for group in candidates
        .iter()
        .filter(|candidate| candidate.kind == ConstructionKind::Group)
    {
        if group.start < consumed_until {
            continue;
        }
        let Some((consumed, group_body)) = consume_call_expression(body, group.open_paren) else {
            continue;
        };
        merge_fields(
            &mut fields,
            extract_group_fields(&group_body, imports, builder_aliases),
        );
        consumed_until = group.open_paren + consumed;
    }
    fields
}

pub fn expand_phi_in_line(line: &str) -> String {
    crate::angular_meta::phi::expand_phi_in_line::<ReactiveFormKind>(line)
}

pub fn expand_phi(token: &str) -> Option<&'static str> {
    crate::angular_meta::phi::expand_phi::<ReactiveFormKind>(token)
}

#[cfg(test)]
#[path = "../tests/angular_meta/reactive_forms.rs"]
mod tests;

#[cfg(test)]
#[path = "../tests/angular_meta/reactive_forms_structure.rs"]
mod structure_tests;
