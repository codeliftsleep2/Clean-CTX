// src/angular_meta/mod.rs
//
// Angular Meta-Layer — Tier 1 (Decorators) + Tier 2 (File-Triplet Bundling).
//
// The Meta-Layer is **purely additive**: it never modifies the existing
// TS compaction output. It only appends a `Φ` block below the existing
// compacted class. Existing users see no change; Angular users get
// enriched output with `@Component` / `@Injectable` / `@Input` /
// `@Output` context.
//
// # Module structure
//
// - `detect`     : Angular detection heuristic
// - `decorators` : `@Component` / `@Injectable` / `@NgModule` /
//                  `@Directive` / `@Pipe` / `@Input` / `@Output` extractor
// - `decorator_scan`      : textual `@Decorator(...)` / field-decorator walkers
// - `decorator_args`      : decorator-argument parsing (`{...}`, `('alias')`)
// - `constructor_injects` : Angular constructor DI parameter extraction
// - `markers`    : `Φ` marker construction & expansion
// - `bundler`    : file-triplet resolver (*.component.ts → .html + .scss)
// - `template`   : tree-sitter-html Angular-syntax template extractor
// - `style`      : CSS/SCSS class + var extractor
// - `footer`     : `§ΦMAP` workspace footer formatter
// - (this file)  : Public surface, `MetaBlock` struct, `run_meta_layer`

#[cfg(feature = "typescript")]
pub(crate) mod application_config_providers;
#[cfg(feature = "typescript")]
pub(crate) mod class_role_authority;
#[cfg(feature = "angular")]
pub(crate) mod constructor_authority;
pub(crate) mod constructor_injects;
pub(crate) mod decorator_args;
pub(crate) mod decorator_scan;
pub(crate) mod decorators;
pub(crate) mod detect;
#[cfg(test)]
pub(crate) mod detect_metrics;
pub mod formly;
#[cfg(feature = "typescript")]
pub(crate) mod functional_authority;
#[cfg(feature = "typescript")]
pub(crate) mod inject_authority;
pub(crate) mod inject_evidence;
pub(crate) mod markers;
#[cfg(feature = "typescript")]
pub(crate) mod member_authority;
#[cfg(feature = "typescript")]
pub(crate) mod member_semantics;
pub(crate) mod module_metadata;
pub mod ngrx;
pub mod phi;
#[cfg(feature = "typescript")]
pub(crate) mod provider_composition;
#[cfg(feature = "typescript")]
pub(crate) mod provider_imported;
#[cfg(feature = "typescript")]
pub(crate) mod provider_pair_authority;
#[cfg(feature = "typescript")]
pub(crate) mod provider_position;
#[cfg(feature = "typescript")]
pub(crate) mod provider_semantics;
pub mod reactive_forms;
#[cfg(feature = "angular")]
pub(crate) mod route_components;
#[cfg(feature = "angular")]
pub(crate) mod route_guards;
#[cfg(feature = "angular")]
pub(crate) mod route_lazy_components;
#[cfg(feature = "angular")]
pub(crate) mod route_load_children;
#[cfg(feature = "typescript")]
mod route_objects;
#[cfg(feature = "typescript")]
pub(crate) mod route_providers;
#[cfg(feature = "angular")]
pub(crate) mod route_resolvers;
pub mod routing;
pub mod rx;
pub mod semantic;
pub mod signals;
#[cfg(feature = "typescript")]
pub(crate) mod string_token_authority;
pub mod style;
pub mod template;
pub mod template_compress;
pub(crate) mod template_occurrences;
pub(crate) mod template_ordered;
pub mod template_ownership;
pub mod testing;
#[cfg(feature = "typescript")]
pub(crate) mod typed_provider_root;
pub mod util;

#[cfg(all(test, feature = "angular"))]
pub(crate) use detect_metrics::{
    ast_parse_count, detection_count, reset_ast_parse_count, reset_detection_count,
};

use crate::compression::Fidelity;

/// A single named section of a meta-layer block.
///
/// Each section has its own header (e.g. `// --- Φ Angular Meta ---`
/// or `// --- Φ RxJS Meta ---`) and a set of `Φ` marker lines.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct MetaSection {
    /// The header line (e.g. `"// --- Φ Angular Meta ---"`).
    pub header: String,
    /// The `Φ` marker lines for this section.
    pub lines: Vec<String>,
}

/// The Meta-Layer output for a single `.ts` file.
///
/// `None` means "not an Angular file" — the caller should not emit any
/// Φ block at all (zero overhead, byte-identical to non-Angular
/// output).
///
/// `Some(block)` means "Angular file" — the caller should append the
/// Φ block lines below the existing compacted class entry.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct MetaBlock {
    /// One `Φ` line per Angular-bearing class, in document order.
    /// Each line is the fully-formatted marker line (e.g. `Φcmp:Foo sel=...`).
    /// Already newline-separated; caller is responsible for the
    /// surrounding `// --- Φ Angular Meta ---` header.
    ///
    /// **Backward-compat:** this is the Angular decorator section.
    /// New layers (RxJS, NgRx, Signals, Routing, Reactive Forms, Formly,
    /// Testing) use `sections`.
    pub lines: Vec<String>,
    /// Named sections for additional meta-layers (RxJS, NgRx, Formly, etc.).
    /// Each section carries its own header.
    pub sections: Vec<MetaSection>,
}

impl MetaBlock {
    /// Returns `true` if there are no Φ lines to emit (i.e. the
    /// caller should skip the entire `// --- Φ Angular Meta ---` block).
    pub fn is_empty(&self) -> bool {
        self.lines.is_empty() && self.sections.iter().all(|s| s.lines.is_empty())
    }

    /// Render the full Φ block, including the header. Returns an
    /// empty string when the block is empty (so callers can `+=`
    /// blindly).
    pub fn render(&self) -> String {
        if self.is_empty() {
            return String::new();
        }
        let mut s = String::new();

        // Angular decorator section (backward-compat `lines` field).
        if !self.lines.is_empty() {
            s.push_str("// --- Φ Angular Meta ---\n");
            for line in &self.lines {
                s.push_str(line);
                s.push('\n');
            }
        }

        // Additional named sections (RxJS, NgRx, Signals, Routing).
        for section in &self.sections {
            if section.lines.is_empty() {
                continue;
            }
            s.push_str(&section.header);
            s.push('\n');
            for line in &section.lines {
                s.push_str(line);
                s.push('\n');
            }
        }

        s
    }
}

/// Run the Tier-1 Meta-Layer pass on a single `.ts` file's raw source
/// text. Returns `None` when the file is not an Angular file (no
/// `@Component` / `@Injectable` / etc. decorators present), and
/// `Some(MetaBlock)` when at least one class carries a recognised
/// Angular decorator.
///
/// The function is deliberately **string-based** for Phase 1 — it
/// does not re-parse the AST. The TS capture pipeline has already
/// given us `class.root` captures; we walk the raw text of each
/// class capture looking for decorators that immediately precede
/// it. This is the same strategy used by `compaction/import.rs` and
/// is sufficient for the Tier 1 deliverable (no new dependencies,
/// no new file types, no AST changes).
///
/// # Arguments
///
/// - `source_code`    : the full source text of the file being compressed
/// - `class_captures` : the slice texts of each `class.root` capture
///   (in document order, already sorted by
///   `run_capture_pipeline`)
/// - `fidelity`       : fidelity level (F-ANG-23 — used to drive
///   per-fidelity marker verbosity):
///   - `Fidelity::Low`    → emit only `@Component` / `@Injectable`
///     / `@Directive` / `@Pipe` / `@NgModule` summary markers
///     (no field-level `@Input` / `@Output`).
///   - `Fidelity::Medium` → add field-level `@Input` / `@Output`
///     markers; skip constructor `Φinjects:` (covered by class summary).
///   - `Fidelity::High`   → emit everything including
///     `Φinjects:` and the modern `input()`/`output()`/`model()`
///     signal lines.
pub fn run_meta_layer(
    source_code: &str,
    class_captures: &[String],
    fidelity: Fidelity,
) -> Option<MetaBlock> {
    run_meta_layer_with_config(source_code, class_captures, fidelity, None)
}

/// Run the meta-layer with an optional [`MetaLayerConfig`] so the
/// per-layer sub-configs (RxJS `min_pipe_operators`, NgRx
/// `include_dispatch_sites`/`include_select_sites`/`entity_selectors`,
/// and the `enabled` master switches) are honored.
///
/// When `config` is `None`, all layers run with their defaults (the
/// same behaviour as [`run_meta_layer`]).
pub fn run_meta_layer_with_config(
    source_code: &str,
    class_captures: &[String],
    fidelity: Fidelity,
    config: Option<&crate::config::MetaLayerConfig>,
) -> Option<MetaBlock> {
    run_meta_layer_with_config_and_path(
        source_code,
        class_captures,
        fidelity,
        config,
        std::path::Path::new(""),
    )
}

/// Path-aware variant used by production dispatch. Existing callers keep the
/// source-only contract above; only detectors with explicit filename evidence
/// consume `path`.
pub fn run_meta_layer_with_config_and_path(
    source_code: &str,
    class_captures: &[String],
    fidelity: Fidelity,
    config: Option<&crate::config::MetaLayerConfig>,
    path: &std::path::Path,
) -> Option<MetaBlock> {
    let lexical_regions = crate::meta_util::LexicalRegions::new(source_code);
    run_meta_layer_with_config_path_and_regions(
        source_code,
        class_captures,
        fidelity,
        config,
        path,
        &lexical_regions,
    )
}

pub(crate) fn run_meta_layer_with_config_path_and_regions(
    source_code: &str,
    class_captures: &[String],
    fidelity: Fidelity,
    config: Option<&crate::config::MetaLayerConfig>,
    path: &std::path::Path,
    lexical_regions: &crate::meta_util::LexicalRegions,
) -> Option<MetaBlock> {
    run_meta_layer_with_config_path_regions_and_evidence(
        source_code,
        class_captures,
        fidelity,
        config,
        path,
        lexical_regions,
        PrecomputedAngularEvidence::default(),
    )
}

#[derive(Default)]
pub(crate) struct PrecomputedAngularEvidence<'a> {
    pub rx: Option<Option<rx::RxShape>>,
    pub ngrx: Option<Option<ngrx::NgRxShape>>,
    pub routing: Option<Option<routing::RouteShape>>,
    pub is_angular: Option<bool>,
    pub initializers: Option<&'a [inject_evidence::ClassInitializerEvidence]>,
}

pub(crate) fn run_meta_layer_with_config_path_regions_and_evidence(
    source_code: &str,
    class_captures: &[String],
    fidelity: Fidelity,
    config: Option<&crate::config::MetaLayerConfig>,
    path: &std::path::Path,
    lexical_regions: &crate::meta_util::LexicalRegions,
    precomputed: PrecomputedAngularEvidence<'_>,
) -> Option<MetaBlock> {
    // Tier 0 (detection): is this an Angular file at all?
    let is_angular = precomputed
        .is_angular
        .unwrap_or_else(|| detect::is_angular_file(source_code));

    // Resolve per-layer enabled flags from config (defaults: all enabled).
    let rxjs_enabled = config.map(|c| c.rxjs.enabled).unwrap_or(true);
    let ngrx_enabled = config.map(|c| c.ngrx.enabled).unwrap_or(true);
    let signals_enabled = config.map(|c| c.signals.enabled).unwrap_or(true);
    let reactive_forms_enabled = config.map(|c| c.reactive_forms.enabled).unwrap_or(true);
    let formly_enabled = config.map(|c| c.formly.enabled).unwrap_or(true);
    let routing_enabled = config.map(|c| c.routing.enabled).unwrap_or(true);
    let testing_enabled = config.map(|c| c.testing.enabled).unwrap_or(true);

    // Detect RxJS independently — a file may be RxJS without being
    // Angular (e.g. a standalone RxJS service or utility).
    let rx_shape = if rxjs_enabled {
        precomputed.rx.unwrap_or_else(|| {
            rx::extract_rx_shape_with_regions(source_code, fidelity, lexical_regions)
        })
    } else {
        None
    };

    // Detect NgRx independently — NgRx files are typically Angular
    // but may not have decorators (e.g. actions/selectors files).
    let ngrx_shape = if ngrx_enabled {
        precomputed.ngrx.unwrap_or_else(|| {
            ngrx::extract_ngrx_shape_with_regions(source_code, fidelity, lexical_regions)
        })
    } else {
        None
    };

    // Detect Signals independently — modern Angular components use
    // signal()/computed()/effect() without decorators.
    let signal_shape = if signals_enabled {
        signals::extract_signal_shape_with_regions(source_code, fidelity, lexical_regions)
    } else {
        None
    };

    // Detect Routing independently — route config files may not have
    // decorators (e.g. `app.routes.ts`).
    let route_shape = if routing_enabled {
        precomputed.routing.unwrap_or_else(|| {
            routing::extract_route_shape_with_regions(source_code, fidelity, lexical_regions)
        })
    } else {
        None
    };

    // Detect Reactive Forms independently. Source construction plus the
    // `@angular/forms` import is sufficient; decorators are not required.
    let reactive_form_shape = if reactive_forms_enabled {
        reactive_forms::extract_reactive_form_shape_with_regions(
            source_code,
            fidelity,
            lexical_regions,
        )
    } else {
        None
    };

    // Detect ngx-formly independently. Formly configuration frequently
    // appears in undecorated files and remains separate from Reactive Forms.
    let formly_shape = if formly_enabled {
        formly::extract_formly_shape_with_regions(source_code, fidelity, lexical_regions)
    } else {
        None
    };

    // Detect testing independently — Vitest specs and TestBed setup do not
    // require Angular decorators. Path evidence is used only for `.spec.ts`.
    let testing_shape = if testing_enabled && testing::is_testing_source(source_code, path) {
        testing::extract_testing_shape_with_regions(source_code, fidelity, lexical_regions)
    } else {
        None
    };

    if !is_angular
        && rx_shape.is_none()
        && ngrx_shape.is_none()
        && signal_shape.is_none()
        && reactive_form_shape.is_none()
        && formly_shape.is_none()
        && route_shape.is_none()
        && testing_shape.is_none()
    {
        // Neither Angular decorators, RxJS, NgRx, Signals, nor Routing —
        // zero overhead.
        return None;
    }

    // Tier 1 (extraction): walk each class capture and emit Φ lines.
    // F-ANG-23: fidelity now controls the verbosity of the output.
    let mut block = MetaBlock::default();

    if is_angular {
        let classes: Vec<_> = match precomputed.initializers {
            Some(classes) => classes
                .iter()
                .map(|class| (class.raw_class.as_str(), class.admitted_tokens()))
                .collect(),
            None => class_captures
                .iter()
                .map(|raw| (raw.as_str(), Vec::new()))
                .collect(),
        };
        for (raw_class, tokens) in classes {
            if let Some(result) =
                decorators::extract_decorators_with_inject_tokens(raw_class, fidelity, &tokens)
            {
                block.lines.extend(result.lines);
                // Tier 2.5: run tree-sitter-html on inline templates.
                // Only for components with `template:` (not `templateUrl:`)
                // since external .html files are handled by the workspace
                // bundle pass.
                // This is only available when the `angular` feature is enabled.
                #[cfg(feature = "angular")]
                if let Some(tpl) = &result.inline_template {
                    if !tpl.trim().is_empty() {
                        // Fidelity-gated template rendering (ANGULAR_HTML_COMPRESSION_PLAN).
                        // Low → single-line shape summary; Medium/High → multi-line
                        // structural Angular semantics.
                        for line in template_compress::compress_template(tpl, fidelity) {
                            if line != "Φtpl:empty" {
                                block.lines.push(line);
                            }
                        }
                    }
                }
            }
        }
    }

    let unresolved_spreads =
        module_metadata::unresolved_spreads(class_captures, source_code, Some(path));
    if !unresolved_spreads.is_empty() {
        block.sections.push(MetaSection {
            header: "// --- Angular Metadata Evidence ---".to_string(),
            lines: unresolved_spreads
                .into_iter()
                .map(|name| format!("Φmodspread:{name}"))
                .collect(),
        });
    }

    // Tier 2 (RxJS): append the RxJS meta block if present.
    if let Some(shape) = rx_shape {
        let lines = shape
            .marker_lines_with_config(fidelity, config.map(|c| c.rxjs.min_pipe_operators))
            .into_iter()
            .map(|marker| marker.trim_end_matches('\n').to_string())
            .collect::<Vec<_>>();
        if !lines.is_empty() {
            block.sections.push(MetaSection {
                header: "// --- Φ RxJS Meta ---".to_string(),
                lines,
            });
        }
    }

    // Tier 3 (NgRx): append the NgRx meta block if present.
    if let Some(shape) = ngrx_shape {
        let ngrx_block = shape.render_with_config(fidelity, config.map(|c| &c.ngrx));
        if !ngrx_block.is_empty() {
            let mut ngrx_lines: Vec<String> = ngrx_block.lines().map(|l| l.to_string()).collect();
            let header = if ngrx_lines
                .first()
                .map(|l| l.starts_with("// ---"))
                .unwrap_or(false)
            {
                ngrx_lines.remove(0)
            } else {
                "// --- Φ NgRx Meta ---".to_string()
            };
            block.sections.push(MetaSection {
                header,
                lines: ngrx_lines,
            });
        }
    }

    // Tier 4 (Signals): append the Signals meta block if present.
    if let Some(shape) = signal_shape {
        let signal_block = shape.render(fidelity);
        if !signal_block.is_empty() {
            let mut signal_lines: Vec<String> =
                signal_block.lines().map(|l| l.to_string()).collect();
            let header = if signal_lines
                .first()
                .map(|l| l.starts_with("// ---"))
                .unwrap_or(false)
            {
                signal_lines.remove(0)
            } else {
                "// --- Φ Signals Meta ---".to_string()
            };
            block.sections.push(MetaSection {
                header,
                lines: signal_lines,
            });
        }
    }

    // Tier 5 (Routing) owns its existing presentation section.
    if let Some(shape) = route_shape {
        shape.append_meta_section(&mut block, fidelity);
    }

    // Reactive Forms remains a distinct source-meta section and never emits
    // template binding markers owned by `template.rs`.
    if let Some(shape) = reactive_form_shape {
        let forms_block = shape.render(fidelity);
        if !forms_block.is_empty() {
            let mut form_lines: Vec<String> =
                forms_block.lines().map(|line| line.to_string()).collect();
            let header = if form_lines
                .first()
                .is_some_and(|line| line.starts_with("// ---"))
            {
                form_lines.remove(0)
            } else {
                "// --- Φ Forms Meta ---".to_string()
            };
            block.sections.push(MetaSection {
                header,
                lines: form_lines,
            });
        }
    }

    // ngx-formly owns field configuration shape, grouping, and expression
    // wiring; it deliberately remains independent from Reactive Forms.
    if let Some(shape) = formly_shape {
        let formly_block = shape.render(fidelity);
        if !formly_block.is_empty() {
            let mut formly_lines: Vec<String> =
                formly_block.lines().map(|line| line.to_string()).collect();
            let header = if formly_lines
                .first()
                .is_some_and(|line| line.starts_with("// ---"))
            {
                formly_lines.remove(0)
            } else {
                "// --- Φ Formly Meta ---".to_string()
            };
            block.sections.push(MetaSection {
                header,
                lines: formly_lines,
            });
        }
    }

    // Tier 6 (Testing): independent Vitest + Angular TestBed section.
    if let Some(shape) = testing_shape {
        let testing_block = shape.render(fidelity);
        if !testing_block.is_empty() {
            let mut testing_lines: Vec<String> =
                testing_block.lines().map(|line| line.to_string()).collect();
            let header = if testing_lines
                .first()
                .is_some_and(|line| line.starts_with("// ---"))
            {
                testing_lines.remove(0)
            } else {
                "// --- Φ Testing Meta ---".to_string()
            };
            block.sections.push(MetaSection {
                header,
                lines: testing_lines,
            });
        }
    }

    if block.is_empty() {
        // Neither Angular decorators, RxJS, NgRx, Signals, nor Routing
        // artifacts. Be conservative — do not emit a Φ block header.
        return None;
    }

    Some(block)
}

#[cfg(all(test, feature = "angular"))]
#[path = "../tests/angular_meta/mod.rs"]
mod tests;

#[cfg(all(test, feature = "angular"))]
#[path = "../tests/angular_meta/semantic.rs"]
mod semantic_tests;

#[cfg(all(test, feature = "angular"))]
#[path = "../tests/angular_meta/constructor_di_edges.rs"]
mod constructor_di_edge_tests;

#[cfg(feature = "typescript")]
pub(crate) mod bootstrap_references;

#[cfg(feature = "typescript")]
mod bootstrap_inline_providers;

#[cfg(feature = "typescript")]
pub(crate) mod config_composition;

#[cfg(feature = "typescript")]
pub(crate) mod legacy_bootstrap;

#[cfg(all(test, feature = "angular"))]
pub(crate) mod admission_work_metrics;

#[cfg(all(test, feature = "typescript"))]
pub(crate) mod delegated_work_metrics;

#[cfg(all(test, feature = "typescript"))]
#[path = "../tests/architecture/delegated_provider_work_af_perf_001.rs"]
mod delegated_provider_work_tests;
