//! Closed operation identity for the public `workspace_query` surface.

use super::prepare::{PreparationContext, PreparedQuery};
use crate::mcp::McpState;
use serde_json::Value;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum WorkspaceQueryOperation {
    FindEntities,
    ForwardEdges,
    ReverseEdges,
    EntitiesInFile,
    DeclarationsInFile,
    TransitiveDependencies,
    HasCycle,
    CallsInFile,
    ResolverRegistrations,
}

impl WorkspaceQueryOperation {
    pub(super) fn parse(value: &str) -> Option<Self> {
        match value {
            "find_entities" => Some(Self::FindEntities),
            "forward_edges" => Some(Self::ForwardEdges),
            "reverse_edges" => Some(Self::ReverseEdges),
            "entities_in_file" => Some(Self::EntitiesInFile),
            "declarations_in_file" => Some(Self::DeclarationsInFile),
            "transitive_dependencies" => Some(Self::TransitiveDependencies),
            "has_cycle" => Some(Self::HasCycle),
            "calls_in_file" => Some(Self::CallsInFile),
            "resolver_registrations" => Some(Self::ResolverRegistrations),
            _ => None,
        }
    }

    pub(super) fn prepare(
        self,
        args: &Value,
        state: &McpState,
        context: &mut PreparationContext,
    ) -> PreparedQuery {
        #[cfg(feature = "angular")]
        let module_owners = super::angular_modules::owners(args, state, context);
        #[cfg(feature = "angular")]
        match super::angular_modules::revalidate(
            state,
            &module_owners,
            args["workspaceRoot"].as_str(),
        ) {
            Ok(true) => context.invalidate_module_preparation(),
            Ok(false) => {}
            Err(error) => {
                return PreparedQuery::failure(super::outcome::QueryFailure::internal(error));
            }
        }
        #[cfg(not(feature = "csharp"))]
        let initial = self.prepare_base(args, state, context);
        #[cfg(feature = "csharp")]
        let initial = (!super::dependencies::can_defer_ef_preparation(args, state, context))
            .then(|| self.prepare_base(args, state, context));
        #[cfg(feature = "csharp")]
        let initial = super::dependencies::prepare(self, args, state, context, initial);
        #[cfg(feature = "angular")]
        let initial = initial.with_module_contributors(super::angular_modules::dependencies(
            state,
            &super::angular_modules::owners(args, state, context),
        ));
        initial
    }

    pub(super) fn prepare_base(
        self,
        args: &Value,
        state: &McpState,
        context: &mut PreparationContext,
    ) -> PreparedQuery {
        match self {
            Self::FindEntities => super::entities::prepare_find_entities(args, state, context),
            Self::ForwardEdges => super::edges::prepare_forward_edges(args, state, context),
            Self::ReverseEdges => super::edges::prepare_reverse_edges(args, state, context),
            Self::EntitiesInFile => super::entities::prepare_entities_in_file(args, state, context),
            Self::DeclarationsInFile => {
                super::entities::prepare_declarations_in_file(args, state, context)
            }
            Self::TransitiveDependencies => {
                super::graph::prepare_transitive_dependencies(args, state, context)
            }
            Self::HasCycle => super::graph::prepare_has_cycle(args, state, context),
            Self::CallsInFile => super::calls::prepare_calls_in_file(args, state, context),
            Self::ResolverRegistrations => {
                super::resolver_registrations::prepare(args, state, context)
            }
        }
    }
}
