//! Session and durable ownership for complete semantic-edge snapshots.

use crate::ir::delta::SequenceDelta;
use crate::layers::meta::semantic::{CallEvidence, EntityRef, SemanticEdge, SemanticRelation};
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::sync::{
    Arc, Mutex, OnceLock,
    atomic::{AtomicBool, Ordering},
};

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub(crate) struct PendingTransitionKey {
    alias: String,
    from: u64,
    to: u64,
}

#[derive(Debug, Clone)]
pub(crate) struct PendingSemanticTransition {
    pub durable_file: String,
    pub from: u64,
    pub to: u64,
    pub target_source_hash: String,
    pub delta_identity: String,
    pub semantic: crate::mcp::compatibility::validator::CompatibleSemanticProjection,
    pub compatibility: crate::mcp::compatibility::identity::CompatibilityIdentities,
    retired: Arc<AtomicBool>,
}

impl PendingSemanticTransition {
    pub(crate) fn is_retired(&self) -> bool {
        self.retired.load(Ordering::Acquire)
    }
}

#[derive(Debug, Clone)]
pub(crate) struct SemanticSnapshot {
    pub authority: crate::mcp::semantic_compilation::retained::RetainedAuthority,
    pub source_hash: String,
    pub edges: Vec<SemanticEdge>,
    pub dependencies: Vec<crate::layers::meta::semantic::SemanticDependency>,
}

impl SemanticSnapshot {
    fn is_current(&self, registrations_enabled: bool) -> bool {
        self.authority.is_current(&self.source_hash)
            && self
                .authority
                .admits_semantic_projection(&self.edges, registrations_enabled)
            && self
                .dependencies
                .iter()
                .all(|dependency| dependency.is_current())
    }
}
#[derive(Debug, Clone, serde::Deserialize, serde::Serialize)]
pub(crate) struct DurableSemanticSnapshot {
    #[serde(default, flatten)]
    pub authority: crate::mcp::semantic_compilation::retained::RetainedAuthority,
    pub file_path: String,
    pub source_hash: String,
    pub version: u64,
    pub edges: Vec<DurableSemanticEdge>,
    #[serde(default)]
    pub dependencies: Vec<crate::layers::meta::semantic::SemanticDependency>,
}

#[derive(Debug, Clone, serde::Deserialize, serde::Serialize)]
pub(crate) struct DurableSemanticEdge {
    relation: SemanticRelation,
    subject: DurableEntityRef,
    object: DurableEntityRef,
    layer: String,
    call_evidence: Option<CallEvidence>,
}

#[derive(Debug, Clone, serde::Deserialize, serde::Serialize)]
struct DurableEntityRef {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    canonical: Option<crate::layers::meta::canonical_endpoint::CanonicalEndpoint>,
    domain: String,
    entity_type: String,
    name: String,
    file: Option<String>,
}

impl DurableSemanticSnapshot {
    #[cfg(test)]
    pub(crate) fn new(
        file_path: String,
        source_hash: String,
        version: u64,
        edges: &[SemanticEdge],
    ) -> Self {
        Self::new_with_dependencies(file_path, source_hash, version, edges, &[])
    }

    pub(crate) fn new_with_dependencies(
        file_path: String,
        source_hash: String,
        version: u64,
        edges: &[SemanticEdge],
        dependencies: &[crate::layers::meta::semantic::SemanticDependency],
    ) -> Self {
        Self {
            file_path,
            source_hash,
            version,
            authority: Default::default(),
            edges: edges.iter().map(DurableSemanticEdge::from).collect(),
            dependencies: dependencies.to_vec(),
        }
    }

    pub(crate) fn restore_edges(&self) -> Result<Vec<SemanticEdge>, String> {
        self.edges.iter().map(SemanticEdge::try_from).collect()
    }
}

impl From<&SemanticEdge> for DurableSemanticEdge {
    fn from(edge: &SemanticEdge) -> Self {
        Self {
            relation: edge.relation,
            subject: DurableEntityRef::from(&edge.subject),
            object: DurableEntityRef::from(&edge.object),
            layer: edge.layer.to_string(),
            call_evidence: edge.call_evidence,
        }
    }
}

impl From<&EntityRef> for DurableEntityRef {
    fn from(entity: &EntityRef) -> Self {
        Self {
            domain: entity.domain.to_string(),
            entity_type: entity.entity_type.to_string(),
            name: entity.name.clone(),
            file: entity.file.clone(),
            canonical: entity.canonical.clone(),
        }
    }
}

impl TryFrom<&DurableSemanticEdge> for SemanticEdge {
    type Error = String;

    fn try_from(edge: &DurableSemanticEdge) -> Result<Self, Self::Error> {
        validate_relation_evidence(edge.relation, edge.call_evidence)?;
        Ok(Self {
            relation: edge.relation,
            subject: edge.subject.restore()?,
            object: edge.object.restore()?,
            layer: intern_label(&edge.layer)?,
            call_evidence: edge.call_evidence,
        })
    }
}

fn validate_relation_evidence(
    relation: SemanticRelation,
    call_evidence: Option<CallEvidence>,
) -> Result<(), String> {
    match (relation, call_evidence) {
        (SemanticRelation::Calls, None) => {
            Err("durable Calls edge is missing call evidence".to_string())
        }
        (SemanticRelation::Calls, Some(_)) | (_, None) => Ok(()),
        (_, Some(_)) => Err("durable non-Calls edge carries call evidence".to_string()),
    }
}

impl DurableEntityRef {
    fn restore(&self) -> Result<EntityRef, String> {
        Ok(EntityRef {
            domain: intern_label(&self.domain)?,
            entity_type: intern_label(&self.entity_type)?,
            name: self.name.clone(),
            file: self.file.clone(),
            canonical: self.canonical.clone(),
        })
    }
}

fn intern_label(value: &str) -> Result<&'static str, String> {
    static LABELS: OnceLock<Mutex<HashSet<&'static str>>> = OnceLock::new();
    let mut labels = LABELS
        .get_or_init(|| Mutex::new(HashSet::new()))
        .lock()
        .map_err(|_| "durable semantic label registry is unavailable".to_string())?;
    if let Some(existing) = labels.get(value) {
        return Ok(*existing);
    }
    let value: &'static str = Box::leak(value.to_string().into_boxed_str());
    labels.insert(value);
    Ok(value)
}

pub(crate) fn sequence_delta_identity(delta: &SequenceDelta) -> Result<String, String> {
    let bytes = serde_json::to_vec(delta)
        .map_err(|error| format!("delta identity encoding failed: {error}"))?;
    Ok(format!("{:x}", Sha256::digest(bytes)))
}

impl super::McpState {
    /// Resolve crash-recovery ownership before a registered path may compile,
    /// checkpoint, or publish authoritative semantics for one file.
    pub(crate) fn preflight_semantic_publication(&self, file_path: &str) -> Result<(), String> {
        let owner = self.durable_owner_path(file_path);
        match self.recover_pending_edit(&owner)? {
            crate::mcp::sqlite_store::EditRecovery::None => Ok(()),
            _ => self.hydrate_recovered_durable_state(&owner),
        }
    }

    pub(crate) fn recover_pending_edit(
        &self,
        file_path: &str,
    ) -> Result<crate::mcp::sqlite_store::EditRecovery, String> {
        let guard = self.persistence_store_lock();
        let Some(store) = guard.as_ref() else {
            return Ok(crate::mcp::sqlite_store::EditRecovery::None);
        };
        let mut sqlite = store
            .sqlite()
            .ok_or_else(|| "Persistence DB is unavailable".to_string())?;
        sqlite
            .recover_edit_intent(file_path)
            .map_err(|error| format!("Edit recovery failed: {error}"))
    }

    pub(crate) fn hydrate_recovered_durable_state(&self, file_path: &str) -> Result<(), String> {
        let restored = {
            let guard = self.persistence_store_lock();
            let store = guard
                .as_ref()
                .ok_or_else(|| "Persistence is not enabled".to_string())?;
            let sqlite = store
                .sqlite()
                .ok_or_else(|| "Persistence DB is unavailable".to_string())?;
            sqlite
                .load_durable_context(file_path, None)
                .map_err(|error| format!("Recovered durable load failed: {error}"))?
                .ok_or_else(|| "Recovered durable context is missing".to_string())?
        };
        let source = match self.read_source(file_path) {
            Ok(source) => source,
            Err(_) => return Ok(()),
        };
        let required_fidelity = restored.fidelity;
        let compatible = match crate::mcp::compatibility::validator::validate_current_context(
            restored,
            &source,
            std::path::Path::new(file_path),
            &self.config,
            required_fidelity,
        ) {
            Ok(compatible) => compatible,
            Err(_) => return Ok(()),
        };
        let canonical = compatible.canonical;
        let semantic = compatible.semantic;
        crate::ir::hierarchical::try_ir_to_hierarchical(&canonical.ir)
            .map_err(|error| format!("Recovered durable projection failed: {error}"))?;
        self.with_semantic_authority_update(file_path, || {
            let alias = self.get_or_create_alias(file_path.to_string());
            let mut ir = canonical.ir;
            ir.file_id.clone_from(&alias);
            self.ir_context_lock()
                .load_ir(ir, Some(canonical.source_hash));
            self.remember_persisted_path(&alias, file_path);
            self.remember_context_fidelity(&alias, canonical.fidelity);
            self.publish_compatible_semantic_projection(&alias, file_path, semantic)?;
            self.llm_text_cache_lock().remove(&alias);
            Ok::<_, String>(())
        })?;
        #[cfg(feature = "csharp")]
        self.mark_csharp_call_authority_dirty_for_file(file_path)?;
        Ok(())
    }

    pub fn remember_persisted_path(&self, alias: &str, file_path: &str) {
        let owner = self.durable_owner_path(file_path);
        lock_or_recover!(self.persisted_paths.lock(), "persisted_paths")
            .insert(alias.to_string(), owner);
    }

    pub fn persisted_path(&self, alias: &str) -> Option<String> {
        lock_or_recover!(self.persisted_paths.lock(), "persisted_paths")
            .get(alias)
            .cloned()
    }

    pub fn forget_persisted_path(&self, alias: &str) {
        lock_or_recover!(self.persisted_paths.lock(), "persisted_paths").remove(alias);
        lock_or_recover!(self.context_fidelities.lock(), "context_fidelities").remove(alias);
        self.forget_semantic_state(alias);
    }

    pub(crate) fn forget_path_alias(&self, alias: &str, path: &str) -> bool {
        self.dict_lock().remove_path_alias(alias, path)
    }

    pub(crate) fn forget_context_caches(&self, file_path: &str) {
        self.invalidate_source_cache(file_path);
        self.cache_write().forget_file(file_path);
        let canonical = self.semantic_owner_path(file_path);
        self.cbm_filter_lock()
            .skip_sets
            .retain(|path, _| crate::dictionary::path::canonical_identity_key(path) != canonical);
    }

    #[cfg(test)]
    #[cfg(feature = "angular")]
    pub(crate) fn remember_semantic_edges(&self, alias: &str, edges: Vec<SemanticEdge>) {
        self.remember_semantic_projection(alias, edges, Vec::new());
    }

    #[cfg(any(feature = "csharp", feature = "angular"))]
    pub(crate) fn remember_semantic_projection(
        &self,
        alias: &str,
        edges: Vec<SemanticEdge>,
        dependencies: Vec<crate::layers::meta::semantic::SemanticDependency>,
    ) {
        #[cfg(test)]
        crate::work_observations_af_perf_002::publication_sink(
            "generation-snapshot",
            edges.len(),
            dependencies.len(),
        );
        lock_or_recover!(
            self.semantic_edge_snapshots.lock(),
            "semantic_edge_snapshots"
        )
        .insert(
            alias.to_string(),
            SemanticSnapshot {
                authority: Default::default(),
                source_hash: String::new(),
                edges,
                dependencies,
            },
        );
    }
    pub(crate) fn remember_retained_semantic_projection(
        &self,
        alias: &str,
        snapshot: SemanticSnapshot,
    ) {
        #[cfg(test)]
        crate::work_observations_af_perf_002::publication_sink(
            "retained-snapshot",
            snapshot.edges.len(),
            snapshot.dependencies.len(),
        );
        lock_or_recover!(
            self.semantic_edge_snapshots.lock(),
            "semantic_edge_snapshots"
        )
        .insert(alias.to_string(), snapshot);
    }

    pub(crate) fn publish_compatible_semantic_projection(
        &self,
        alias: &str,
        file_path: &str,
        projection: crate::mcp::compatibility::validator::CompatibleSemanticProjection,
    ) -> Result<(), String> {
        if !projection.authority.is_current(&projection.source_hash)
            || !projection.authority.admits_semantic_projection(
                &projection.semantic_edges,
                crate::layers::meta::resolver_registrations::enabled(&self.config),
            )
        {
            return Err("Typed authority changed before compatible publication".into());
        }
        let snapshot = SemanticSnapshot {
            authority: projection.authority.clone(),
            source_hash: projection.source_hash.clone(),
            edges: projection.semantic_edges.clone(),
            dependencies: projection.semantic_dependencies.clone(),
        };
        let canonical_path = self.semantic_owner_path(file_path);
        {
            let mut index = self.workspace_index_lock();
            match crate::workspace::index::SemanticFidelity::from_compilation(projection.fidelity) {
                Some(fidelity) => index
                    .replace_semantic_projection_with_complete_authority(
                        &canonical_path,
                        crate::workspace::index::SemanticProjectionInput {
                            #[cfg(feature = "typescript")]
                            typescript_authority: projection.authority.typescript_authority,
                            resolver_registrations: projection.authority.resolver_registrations,
                            resolver_registration_scope: projection
                                .authority
                                .resolver_registration_scope,
                            fidelity,
                            source_hash: projection.source_hash,
                            edges: projection.semantic_edges,
                            dependencies: projection.semantic_dependencies,
                        },
                        crate::layers::meta::resolver_registrations::enabled(&self.config),
                    )
                    .map_err(str::to_string)?,
                None => {
                    index.remove_file(&canonical_path);
                    index.add_edges(&canonical_path, projection.semantic_edges);
                }
            }
        }
        self.remember_retained_semantic_projection(alias, snapshot);
        Ok(())
    }

    pub(crate) fn semantic_snapshot(&self, alias: &str) -> Option<SemanticSnapshot> {
        lock_or_recover!(
            self.semantic_edge_snapshots.lock(),
            "semantic_edge_snapshots"
        )
        .get(alias)
        .filter(|snapshot| {
            #[cfg(test)]
            let _observation = crate::work_observations_af_perf_002::snapshot_scope();
            snapshot.is_current(crate::layers::meta::resolver_registrations::enabled(
                &self.config,
            ))
        })
        .cloned()
    }

    pub(crate) fn semantic_edges(&self, alias: &str) -> Option<Vec<SemanticEdge>> {
        self.semantic_snapshot(alias).map(|snapshot| snapshot.edges)
    }
    pub(crate) fn remember_pending_transition(
        &self,
        alias: &str,
        durable_file: &str,
        delta: &SequenceDelta,
        target_source_hash: String,
        semantic: crate::mcp::compatibility::validator::CompatibleSemanticProjection,
        compatibility: crate::mcp::compatibility::identity::CompatibilityIdentities,
    ) -> Result<(), String> {
        if delta.target_hash.as_deref() != Some(target_source_hash.as_str()) {
            return Err("generated delta target hash does not match semantic state".to_string());
        }
        if semantic.source_hash != target_source_hash {
            return Err("generated semantic projection has wrong target hash".to_string());
        }
        if !semantic.authority.is_current(&target_source_hash)
            || !semantic.authority.admits_semantic_projection(
                &semantic.semantic_edges,
                crate::layers::meta::resolver_registrations::enabled(&self.config),
            )
        {
            return Err("generated TypeScript authority is stale".to_string());
        }
        let key = PendingTransitionKey {
            alias: alias.to_string(),
            from: delta.from,
            to: delta.to,
        };
        let transition = PendingSemanticTransition {
            durable_file: durable_file.to_string(),
            from: delta.from,
            to: delta.to,
            target_source_hash,
            delta_identity: sequence_delta_identity(delta)?,
            semantic,
            compatibility,
            retired: Arc::new(AtomicBool::new(false)),
        };
        lock_or_recover!(
            self.pending_semantic_transitions.lock(),
            "pending_semantic_transitions"
        )
        .insert(key, transition);
        Ok(())
    }

    pub(crate) fn pending_transition(
        &self,
        alias: &str,
        durable_file: &str,
        delta: &SequenceDelta,
    ) -> Result<PendingSemanticTransition, String> {
        let key = PendingTransitionKey {
            alias: alias.to_string(),
            from: delta.from,
            to: delta.to,
        };
        let transition = lock_or_recover!(
            self.pending_semantic_transitions.lock(),
            "pending_semantic_transitions"
        )
        .get(&key)
        .cloned()
        .ok_or_else(|| "missing authoritative semantic-edge snapshot for delta".to_string())?;
        if transition.durable_file != durable_file {
            return Err("pending semantic-edge snapshot has wrong file identity".to_string());
        }
        if delta.target_hash.as_deref() != Some(transition.target_source_hash.as_str()) {
            return Err("pending semantic-edge snapshot has wrong target hash".to_string());
        }
        if transition.delta_identity != sequence_delta_identity(delta)? {
            return Err(
                "pending semantic-edge snapshot does not match delta transition".to_string(),
            );
        }
        if !transition
            .semantic
            .authority
            .is_current(&transition.target_source_hash)
        {
            return Err("pending TypeScript authority is stale".to_string());
        }
        Ok(transition)
    }

    pub(crate) fn consume_pending_transition(&self, alias: &str, from: u64, to: u64) {
        lock_or_recover!(
            self.pending_semantic_transitions.lock(),
            "pending_semantic_transitions"
        )
        .remove(&PendingTransitionKey {
            alias: alias.to_string(),
            from,
            to,
        });
    }

    pub(crate) fn forget_pending_transitions_in_root(&self, root: &str) -> usize {
        let retiring: Vec<_> = {
            let transitions = lock_or_recover!(
                self.pending_semantic_transitions.lock(),
                "pending_semantic_transitions"
            );
            transitions
                .iter()
                .filter(|(_, transition)| {
                    crate::workspace::path_identity::is_within_root(&transition.durable_file, root)
                })
                .map(|(key, transition)| (key.clone(), transition.clone()))
                .collect()
        };
        for (key, transition) in &retiring {
            self.with_semantic_authority_update(&transition.durable_file, || {
                transition.retired.store(true, Ordering::Release);
                lock_or_recover!(
                    self.pending_semantic_transitions.lock(),
                    "pending_semantic_transitions"
                )
                .remove(key);
            });
        }
        retiring.len()
    }

    pub(crate) fn forget_pending_transitions(&self, alias: &str) {
        lock_or_recover!(
            self.pending_semantic_transitions.lock(),
            "pending_semantic_transitions"
        )
        .retain(|key, _| key.alias != alias);
    }

    #[cfg(test)]
    pub(crate) fn pending_transition_count(&self, alias: &str) -> usize {
        lock_or_recover!(
            self.pending_semantic_transitions.lock(),
            "pending_semantic_transitions"
        )
        .keys()
        .filter(|key| key.alias == alias)
        .count()
    }

    pub(crate) fn forget_semantic_state(&self, alias: &str) {
        lock_or_recover!(
            self.semantic_edge_snapshots.lock(),
            "semantic_edge_snapshots"
        )
        .remove(alias);
        lock_or_recover!(
            self.pending_semantic_transitions.lock(),
            "pending_semantic_transitions"
        )
        .retain(|key, _| key.alias != alias);
    }
}
