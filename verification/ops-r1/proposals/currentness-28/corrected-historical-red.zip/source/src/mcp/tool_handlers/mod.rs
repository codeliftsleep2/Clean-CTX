// src/mcp/tool_handlers/mod.rs
//
// Tool handler module - registry-based dispatch with modular handler
// implementations split across submodules for Single Responsibility.
//
// Submodules:
//   core/        — Compression, IR, delta, provide, restore handlers
//   context/     — Context history queries
//   gitdiff.rs   — diff_commits (multi-file git-ref diff) handler
//   persistence/ — SQLite/BufferedStore CRUD tools
//   stats/       — Dashboard rendering
//   traits.rs    — ToolHandlerDef trait (v0.3.0 placeholder)
//   registry.rs  — HandlerRegistry + wiring

pub mod context;
pub mod core;
pub mod edit;
pub mod gitdiff;
pub(crate) mod hydration;
pub(crate) mod pcg;
pub(crate) mod pcg_documents;
pub mod persistence;
pub mod query;
pub mod refresh;
pub mod registry;
pub mod stats;
pub mod traits;

// Re-exports for API consumers (v0.3.0+)
#[allow(unused_imports)]
pub use registry::HandlerRegistry;
#[allow(unused_imports)]
pub use traits::BoxedHandlerFn;

#[cfg(test)]
#[path = "../../tests/mcp/control_full_test_support.rs"]
pub(crate) mod control_full_test_support;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/tool_handlers.rs"]
pub(crate) mod tool_handlers_tests;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/phase_a_retirement.rs"]
pub(crate) mod phase_a_retirement_tests;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/phase_b_retirement.rs"]
pub(crate) mod phase_b_retirement_tests;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/phase3_contract.rs"]
pub(crate) mod phase3_contract_tests;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/envelope_contract.rs"]
pub(crate) mod envelope_contract_tests;

#[cfg(all(test, feature = "typescript"))]
#[path = "../../tests/mcp/semantic_publication_recovery.rs"]
pub(crate) mod semantic_publication_recovery_tests;

// End-to-end `provide_code_context` regressions for method-declaration
// identity: the rendered skeleton must carry the structural method name, and
// the request must have taken the COMPRESSED path (never `raw_passthrough`,
// which would return the source verbatim and prove nothing about the IR).
#[cfg(all(test, feature = "csharp"))]
#[path = "../../tests/mcp/provider_code_context_signature.rs"]
pub(crate) mod provider_code_context_signature_tests;

#[cfg(all(test, any(feature = "csharp", feature = "typescript")))]
#[path = "../../tests/mcp/focus_generic_methods.rs"]
pub(crate) mod focus_generic_methods_tests;

#[cfg(all(test, feature = "typescript"))]
#[path = "../../tests/mcp/provide_code_context_batch.rs"]
pub(crate) mod provide_code_context_batch_tests;

#[cfg(all(test, feature = "typescript"))]
#[path = "../../tests/mcp/provide_code_context_response_mode_economics.rs"]
pub(crate) mod provide_code_context_response_mode_economics_tests;

#[cfg(all(test, feature = "angular", feature = "typescript"))]
#[path = "../../tests/mcp/provide_angular_template_ownership.rs"]
pub(crate) mod provide_angular_template_ownership_tests;

#[cfg(all(test, feature = "angular", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_angular_templates.rs"]
pub(crate) mod workspace_query_angular_template_tests;

#[cfg(all(test, feature = "angular", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_angular_selector_occurrences.rs"]
pub(crate) mod workspace_query_angular_selector_occurrence_tests;

#[cfg(all(test, feature = "angular", feature = "typescript"))]
#[path = "../../tests/mcp/angular_template_phase6_diagnostics.rs"]
pub(crate) mod angular_template_phase6_diagnostic_tests;

#[cfg(all(test, feature = "rust", feature = "csharp"))]
#[path = "../../tests/mcp/refresh_workspace.rs"]
pub(crate) mod refresh_workspace_tests;
