//! Reusable schema fragments for public tools with polymorphic requests.

use serde_json::{Value, json};
pub(super) mod resolver_registrations;

pub(super) fn apply_edit_operations() -> Value {
    json!({
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "type": { "const": "replace_body" },
                    "target": { "type": "string", "description": "Signature-qualified structural unit, for example Owner.method(type,...). A legacy qualified or bare name is accepted only when unique." },
                    "expectedOldText": { "type": "string", "description": "Byte-exact unit text previously delivered to this session." },
                    "newText": { "type": "string", "description": "Complete replacement body text." }
                },
                "required": ["type", "target", "expectedOldText", "newText"]
            },
            {
                "type": "object",
                "properties": {
                    "type": { "const": "delete" },
                    "target": { "type": "string", "description": "Signature-qualified structural unit. A legacy qualified or bare name is accepted only when unique." },
                    "expectedOldText": { "type": "string", "description": "Byte-exact full declaration text, or the legacy tracked body text for compatibility." }
                },
                "required": ["type", "target", "expectedOldText"]
            },
            {
                "type": "object",
                "properties": {
                    "type": { "const": "insert_after" },
                    "anchor": { "type": "string", "description": "Signature-qualified anchor. A legacy qualified or bare name is accepted only when unique." },
                    "unitText": { "type": "string", "description": "Complete structural unit text to insert." }
                },
                "required": ["type", "anchor", "unitText"]
            },
            {
                "type": "object",
                "properties": {
                    "type": { "const": "insert_before" },
                    "anchor": { "type": "string", "description": "Signature-qualified anchor. A legacy qualified or bare name is accepted only when unique." },
                    "unitText": { "type": "string", "description": "Complete structural unit text to insert." }
                },
                "required": ["type", "anchor", "unitText"]
            }
        ]
    })
}

fn provide_code_context_item_properties() -> Value {
    json!({
        "filePath": { "type": "string" },
        "intent": { "type": "string", "enum": ["edit", "refactor", "overview", "debug", "implement"], "description": "edit: byte-exact method bodies for safe apply_edit operations. refactor: full structural detail. overview: max compression. debug: balanced. implement: moderate detail." },
        "fidelity": { "type": "string", "enum": ["low", "medium", "high", "edit", "verbatim"], "description": "Compression fidelity: low, medium, high, edit, or verbatim." },
        "focusMethods": { "type": "array", "items": { "type": "string" }, "description": "Select qualified Owner.method names, or an unambiguous bare method name. Focused requests use Edit fidelity unless an explicit compatible mode is supplied." }
    })
}

pub(super) fn provide_code_context_properties() -> Value {
    let mut properties = provide_code_context_item_properties();
    let object = properties
        .as_object_mut()
        .expect("provide context properties are an object");
    object.insert("workspaceRoot".into(), json!({ "type": "string", "description": "Strongly recommended. Shared explicit workspace root for reliable path resolution; defaults to CWD for backward compatibility." }));
    object.insert("tokenizer".into(), json!({ "type": "string" }));
    object.insert("responseMode".into(), json!({
        "type": "string",
        "enum": ["mirrored", "structured", "indexed"],
        "description": "Batch-only response projection. mirrored (default) exposes exact code in both MCP channels; structured exposes code only in structured items; indexed exposes code only in top-level content blocks."
    }));

    let mut item_properties = provide_code_context_item_properties();
    item_properties
        .as_object_mut()
        .expect("provide context item properties are an object")
        .insert("id".into(), json!({ "type": "string", "minLength": 1 }));
    object.insert(
        "files".into(),
        json!({
            "type": "array",
            "minItems": 1,
            "maxItems": 8,
            "items": {
                "type": "object",
                "properties": item_properties,
                "required": ["id", "filePath"]
            }
        }),
    );
    Value::Object(object.clone())
}

pub(super) fn provide_code_context_request_variants() -> Value {
    json!([
        {
            "required": ["filePath"],
            "not": {
                "anyOf": [
                    { "required": ["files"] },
                    { "required": ["responseMode"] }
                ]
            }
        },
        {
            "properties": {
                "files": provide_code_context_properties()["files"].clone()
            },
            "required": ["files"],
            "not": {
                "anyOf": [
                    { "required": ["filePath"] },
                    { "required": ["fidelity"] }
                ]
            }
        }
    ])
}

pub(super) fn provide_code_context_batch_results() -> Value {
    json!({
        "type": "array",
        "description": "Ordered outcomes, exactly one per accepted batch item.",
        "items": {
            "type": "object",
            "properties": {
                "id": { "type": "string" },
                "status": { "type": "string", "enum": ["ok", "error"] },
                "content_index": { "type": "integer", "minimum": 0, "description": "Index of the exact successful text block in result.content." },
                "content": {
                    "type": "array",
                    "description": "Exact MCP content mirrored for structured-only clients; byte-identical to the block selected by content_index.",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": { "const": "text" },
                            "text": { "type": "string" }
                        },
                        "required": ["type", "text"]
                    }
                },
                "meta": { "type": "object", "description": "The corresponding single-file semantic metadata." },
                "error": {
                    "type": "object",
                    "properties": {
                        "code": { "type": "integer" },
                        "message": { "type": "string" },
                        "data": {}
                    },
                    "required": ["code", "message"]
                }
            },
            "required": ["id", "status"],
            "oneOf": [
                {
                    "properties": { "status": { "const": "ok" } },
                    "required": ["meta"],
                    "not": { "required": ["error"] },
                    "oneOf": [
                        {
                            "required": ["content_index", "content"]
                        },
                        {
                            "required": ["content"],
                            "not": { "required": ["content_index"] }
                        },
                        {
                            "required": ["content_index"],
                            "not": { "required": ["content"] }
                        }
                    ]
                },
                {
                    "properties": { "status": { "const": "error" } },
                    "required": ["error"],
                    "not": {
                        "anyOf": [
                            { "required": ["content_index"] },
                            { "required": ["content"] },
                            { "required": ["meta"] }
                        ]
                    }
                }
            ]
        }
    })
}

pub(super) fn workspace_query_properties() -> Value {
    let mut properties = workspace_query_operation_properties();
    let properties = properties
        .as_object_mut()
        .expect("workspace query properties are an object");
    properties.insert("workspaceRoot".into(), json!({ "type": "string", "description": "Shared primary trusted workspace root. Required for calls_in_file and resolver_registrations; optional for other cross-file operations." }));
    properties.insert("withinPath".into(), json!({ "type": "string", "description": "Shared optional answer projection inside workspaceRoot plus configured additional roots. Narrows returned occurrences by their asserting file; discovery, hydration, and compilation still cover all authorized roots. Rejected when outside that authorized set or when workspaceRoot is absent." }));
    properties.insert("queries".into(), workspace_query_batch_queries());
    Value::Object(properties.clone())
}

fn workspace_query_operation_properties() -> Value {
    json!({
        "type": { "type": "string", "enum": ["find_entities", "forward_edges", "reverse_edges", "entities_in_file", "declarations_in_file", "transitive_dependencies", "has_cycle", "calls_in_file", "resolver_registrations"], "description": "Type of workspace query." },
        "domain": { "type": "string", "description": "Optional exact domain for forward_edges, reverse_edges, transitive_dependencies, or declaration-only find_entities. With entity_type, edge queries use the exact-identity fast path; alone, filters name resolution." },
        "entity_type": { "type": "string", "description": "Optional exact entity type for forward_edges, reverse_edges, transitive_dependencies, or declaration-only find_entities. With domain, edge queries use the exact-identity fast path; alone, filters name resolution." },
        "name": { "type": "string", "minLength": 1, "description": "Exactly one entity name. Required for find_entities, forward_edges, reverse_edges, and transitive_dependencies. For multiple names, use top-level queries with one independently identified item per name; do not pass an array or a names field." },
        "declarations_only": { "type": "boolean", "description": "find_entities only. When true, return source-proven declaration occurrences and apply optional domain/entity_type filters. Fact authority alone proves declarations, not source completeness. With an explicit workspaceRoot, complete provider-neutral acquisition and publication can earn exact coverage for supported declaration producers; inspect coverage for the actual outcome. Ordinary occurrence searches are lower bounds. Default false preserves occurrence-oriented behavior." },
        "file_path": { "type": "string", "description": "File path for entities_in_file or declarations_in_file query." },
        "fidelity": { "type": "string", "enum": ["low", "medium", "high", "edit", "verbatim"], "description": "Optional semantic compilation fidelity for entities_in_file or declarations_in_file. Edit and verbatim normalize to High because these queries publish no source bodies. Defaults to the configured fidelity." },
        "kind": { "type": "string", "enum": ["dependency"], "description": "Optional cycle policy for has_cycle. Defaults to dependency." },
        "filePath": { "type": "string", "description": "Trusted source file for calls_in_file." },
        "owner": { "type": "object", "description": "Typed caller owner for calls_in_file.", "properties": { "kind": { "type": "string", "enum": ["class", "interface"] }, "name": { "type": "string" } }, "required": ["kind", "name"] },
        "method": { "type": "object", "description": "Caller method for calls_in_file. Omit signature fields for the complete overload family.", "properties": { "name": { "type": "string" }, "parameters": { "type": "array", "items": { "type": "string" }, "description": "Optional exact visible parameter-signature selector." }, "return_type": { "type": "string" } }, "required": ["name"] },
        "direction": {"type":"string","enum":["forward","reverse"],"description":"resolver_registrations only."},
        "route_path": {"type":"string","description":"Forward written-registration route occurrence bucket; empty allowed."},
        "resolver_name": {"type":"string","minLength":1,"description":"Reverse written-registration declaration name bucket."},
        "depth": { "type": "integer", "description": "Traversal depth for transitive_dependencies: 0 = unlimited, 1 = direct, 2 = transitive. Default: 1." },
    })
}

pub(super) fn workspace_query_request_variants() -> Value {
    let mut variants = workspace_query_variants(true)
        .as_array()
        .expect("workspace query variants are an array")
        .clone();
    for variant in &mut variants {
        variant["not"] = json!({ "required": ["queries"] });
    }
    variants.push(json!({
        "properties": { "queries": workspace_query_batch_queries() },
        "required": ["queries"],
        "not": { "required": ["type"] },
    }));
    Value::Array(variants)
}

fn workspace_query_variants(require_calls_root: bool) -> Value {
    let calls_required: &[&str] = if require_calls_root {
        &["filePath", "workspaceRoot", "owner", "method"]
    } else {
        &["filePath", "owner", "method"]
    };
    json!([
        query_variant("find_entities", &["name"]),
        query_variant("forward_edges", &["name"]),
        query_variant("reverse_edges", &["name"]),
        query_variant("entities_in_file", &["file_path"]),
        query_variant("declarations_in_file", &["file_path"]),
        query_variant("transitive_dependencies", &["name"]),
        query_variant("has_cycle", &[]),
        query_variant("calls_in_file", calls_required),
        resolver_registrations::input_variant(require_calls_root)
    ])
}

fn workspace_query_batch_queries() -> Value {
    let mut properties = workspace_query_operation_properties();
    let properties = properties
        .as_object_mut()
        .expect("workspace query properties are an object");
    properties.insert("id".into(), json!({ "type": "string", "minLength": 1 }));
    json!({
        "type": "array",
        "minItems": 1,
        "maxItems": 32,
        "items": {
            "type": "object",
            "properties": properties,
            "oneOf": workspace_query_variants(false),
            "required": ["id"],
            "not": {
                "anyOf": [
                    { "required": ["workspaceRoot"] },
                    { "required": ["withinPath"] }
                ]
            }
        }
    })
}

pub(super) fn workspace_query_batch_results() -> Value {
    let mut schema = json!({
        "type": "array",
        "description": "Ordered outcomes, exactly one per accepted batch item.",
        "items": {
            "type": "object",
            "properties": {
                "id": { "type": "string" },
                "type": { "type": "string" },
                "status": { "type": "string", "enum": ["ok", "error"] },
                "result": { "type": "object", "description": "The corresponding legacy structured result for a successful item." },
                "error": {
                    "type": "object",
                    "properties": {
                        "code": { "type": "integer" },
                        "message": { "type": "string" },
                        "data": {}
                    },
                    "required": ["code", "message"]
                }
            },
            "required": ["id", "type", "status"],
            "oneOf": [
                {
                    "properties": { "status": { "const": "ok" } },
                    "required": ["result"],
                    "not": { "required": ["error"] }
                },
                {
                    "properties": { "status": { "const": "error" } },
                    "required": ["error"],
                    "not": { "required": ["result"] }
                }
            ]
        }
    });
    schema["items"]["allOf"] = json!([{
        "if":{"properties":{"type":{"const":"resolver_registrations"},"status":{"const":"ok"}},"required":["type","status"]},
        "then":{"properties":{"result":resolver_registrations::result()}}
    }]);
    schema
}

fn query_variant(kind: &str, operation_fields: &[&str]) -> Value {
    let mut required = vec!["type"];
    required.extend_from_slice(operation_fields);
    json!({
        "properties": { "type": { "const": kind } },
        "required": required
    })
}
