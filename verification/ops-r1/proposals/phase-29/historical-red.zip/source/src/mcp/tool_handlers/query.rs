// src/mcp/tool_handlers/query.rs
#[cfg(all(test, feature = "angular"))]
#[path = "../../tests/mcp/ops_r1_query_phase_currentness.rs"]
mod ops_r1_query_phase_currentness;
//
// workspace_query handler — read-only MCP query API.
//
// Cross-file operations expose the existing WorkspaceIndex query methods over
// the already-wired write lifecycle established in Phases A/B. The narrow
// `calls_in_file` operation instead inspects a fresh, unpublished canonical IR
// candidate so typed owner and overload identity survive the query boundary.
//
// Semantic hydration: for eligible query types, after the initial WorkspaceIndex
// query, one exhaustive candidate-file discovery pass runs across the primary
// root plus configured additional roots. Healthy CBM is preferred; roots CBM
// cannot cover fall back to literal filesystem discovery. Both providers
// supply ONLY candidate file paths. Those paths flow through resolve_file_path_checked →
// compile_file_ir_focused → Clean-CTX semantic extraction → WorkspaceIndex.
// CBM graph semantics (edge counts, relationship types, etc.) never enter the
// WorkspaceIndex. The original query reruns exactly once after hydration.
//
// Scope of one query — the ONE rule, computed once per call and shared by the
// initial answer and the post-hydration rerun:
//
//   effective scope = workspaceRoot + configured additional_roots   (WSC-004)
//                     ∩ optional `withinPath` narrowing
//
// `withinPath` (optional string) narrows an ALREADY authorized workspace to a
// file or directory subtree: a relative path resolves against `workspaceRoot`, an
// absolute path is used as declared, and the resolved path is canonicalized once
// per query. It is validated against the authorized root set BEFORE the index is
// consulted, so a path outside that set — or a `withinPath` supplied without
// `workspaceRoot` — is refused with `-32602` and can never become an implicit
// authorization root. Occurrence PROVENANCE is the boundary on every surface
// (`EntityRef.file` for entity occurrences, `StoredEdge::asserting_file` for edge
// occurrences), reachability/cycle queries apply it DURING traversal, and Model C
// identity is untouched. Omitting `withinPath` leaves every query exactly as it
// was. The rule itself lives in one place — `workspace::scope::WorkspaceScope` —
// and no handler parses a path of its own.
//
// Module layout (handler groups are separate files, mirroring how the index
// splits its query families):
//   query.rs             — dispatch, the hydration cycle, the shared scope rule.
//   query/calls.rs       — owner-aware calls from one canonical file candidate.
//   query/diagnostics.rs — the sparse LLM-facing discovery-diagnostic projection.
//   query/entities.rs    — find_entities, entities_in_file.
//   query/edges.rs       — forward_edges, reverse_edges.
//   query/graph.rs       — transitive_dependencies, has_cycle.
//
// Hydration diagnostics reach the caller through ONE shared projection
// (`diagnostics::discovery_field`): expected state is omitted and only
// decision-relevant deviation is serialized, as an optional `discovery` object.
// The internal `HydrationReport` stays complete; nothing about discovery,
// provider selection, or the semantic answer changes here.

use crate::mcp::McpState;
use crate::protocol::send_response;
use serde_json::Value;

mod angular_templates;
mod batch;
mod calls;
mod classification;
mod content;
mod coverage;
mod csharp_resolution;
#[cfg(feature = "csharp")]
mod dependencies;
mod diagnostics;
mod dotnet_testing;
#[cfg(feature = "csharp")]
mod edge_merge;
mod edges;
mod entities;
mod graph;
mod identity;
mod outcome;
mod prepare;
mod request;
mod resolver_registrations;
#[cfg(test)]
pub(crate) mod work_metrics;

pub(super) use diagnostics::discovery_field;

/// Handle `workspace_query` — read-only cross-file and file-local queries.
pub(crate) fn handle_workspace_query(id: &Value, params: &Value, state: &McpState) {
    let args = &params["arguments"];
    if args.get("queries").is_some() {
        batch::handle(id, args, state);
        return;
    }
    let query_type = match args["type"].as_str() {
        Some(t) => t,
        None => {
            send_response(&serde_json::json!({
                "jsonrpc": "2.0", "id": id,
                "error": {
                    "code": -32602,
                    "message": "Missing required argument: 'type'. Supported values: \
                     find_entities, forward_edges, reverse_edges, entities_in_file, declarations_in_file, \
                     transitive_dependencies, has_cycle, calls_in_file, resolver_registrations.".to_string()
                }
            }));
            return;
        }
    };

    let operation = match request::WorkspaceQueryOperation::parse(query_type) {
        Some(operation) => operation,
        None => {
            send_response(&serde_json::json!({
                "jsonrpc": "2.0", "id": id,
                "error": {
                    "code": -32602,
                    "message": format!(
                        "Unknown query type: '{}'. Supported values: find_entities, \
                         forward_edges, reverse_edges, entities_in_file, declarations_in_file, \
                         transitive_dependencies, has_cycle, calls_in_file, resolver_registrations.",
                        query_type
                    )
                }
            }));
            return;
        }
    };
    let mut context = prepare::PreparationContext::new();
    let result = operation
        .prepare(args, state, &mut context)
        .evaluate_single(state);
    outcome::send_single(id, args, state, result);
}

/// Run a WorkspaceIndex query with optional one-cycle semantic hydration.
///
/// 1. Run the initial query against current WorkspaceIndex (authoritative for
///    what Clean-CTX currently knows).
/// 2. If the query is hydration-eligible, perform ONE exhaustive discovery hydration pass.
/// 3. Rerun the original query exactly once.
/// 4. Return final results + the complete internal hydration report. The
///    LLM-facing projection of that report is `diagnostics::discovery_field`,
///    applied by the handler that serializes the response.
#[cfg(all(test, feature = "rust"))]
fn run_query_with_hydration<F>(
    state: &McpState,
    query_type: &str,
    query_name: &str,
    workspace_root: Option<&str>,
    query_fn: F,
) -> Result<(Value, usize, super::hydration::HydrationReport), String>
where
    F: Fn(&crate::workspace::index::WorkspaceIndex) -> (Value, usize),
{
    // Step 1: Initial authoritative query.
    let (initial_results, initial_count) = {
        let idx = state.workspace_index_read();
        query_fn(&idx)
    };

    // Step 2: Evaluate hydration eligibility (independent of result count).
    let eligible = super::hydration::is_hydration_eligible(
        query_type,
        &serde_json::json!({ "name": query_name }),
    );
    if !eligible {
        return Ok((
            initial_results,
            initial_count,
            super::hydration::HydrationReport::default(),
        ));
    }

    // Step 3: One exhaustive discovery hydration pass.
    let hydration =
        super::hydration::hydrate_workspace_index(state, query_type, query_name, workspace_root)?;
    // Legacy test helper callers provide only a query name, not the exact
    // identity needed by the production capability gate. Preserve their
    // historical edge-query behavior without affecting production routing.
    #[cfg(feature = "csharp")]
    if matches!(query_type, "forward_edges" | "reverse_edges") {
        state.prepare_exact_csharp_calls()?;
    }

    // Step 4: Rerun original query exactly once.
    let (final_results, final_count) = {
        let idx = state.workspace_index_read();
        query_fn(&idx)
    };

    Ok((final_results, final_count, hydration))
}

/// Extract a required string argument from the arguments object.
fn required_str<'a>(args: &'a Value, name: &str) -> Option<&'a str> {
    args[name].as_str().filter(|s| !s.is_empty())
}

/// Extract the singular entity name used by name-bearing operations.
///
/// The MCP schema rejects non-strings for conforming clients, but the server
/// boundary remains authoritative when a client bypasses or coerces schema
/// validation. Keep absence distinct from a present value of the wrong type,
/// and direct multi-name callers to the supported batch request form.
fn required_name<'a>(args: &'a Value, query_type: &str) -> Result<&'a str, outcome::QueryFailure> {
    match args.get("name") {
        None | Some(Value::Null) => Err(outcome::QueryFailure::invalid(format!(
            "Missing required argument: 'name' for {query_type} query."
        ))),
        Some(Value::String(name)) if !name.is_empty() => Ok(name),
        Some(_) => Err(outcome::QueryFailure::invalid(
            "Invalid argument: 'name' must be a non-empty string. For multiple names, use \
             top-level 'queries' with one item per name.",
        )),
    }
}

/// Extract an optional integer argument; returns `default` if missing.
fn optional_i32(args: &Value, name: &str, default: i32) -> i32 {
    args[name].as_i64().map(|v| v as i32).unwrap_or(default)
}

/// The effective scope of one `workspace_query` call: the caller's
/// `workspaceRoot` plus the configured `additional_roots` (WSC-004), intersected
/// with the optional `withinPath` narrowing. No handler parses a root or a path
/// itself — this is the only place that reads either argument, and
/// `WorkspaceScope` is the only place that decides admission.
///
/// `Ok(None)` — the caller declared no workspace root and no `withinPath`: the
/// query stays unscoped (the global/session view), exactly as before, and no
/// fallback root is ever substituted.
///
/// `Err(message)` — an invalid `withinPath` argument: it was supplied without an
/// explicit `workspaceRoot`, or it resolves outside the authorized root set. The
/// query is refused before the index is consulted, so no unrelated fact is ever
/// exposed and the narrowing can never widen the authorized workspace.
fn query_scope(
    state: &McpState,
    args: &Value,
) -> Result<Option<crate::workspace::scope::WorkspaceScope>, String> {
    let within_path = args["withinPath"]
        .as_str()
        .map(str::trim)
        .filter(|path| !path.is_empty());
    match within_path {
        Some(within_path) => crate::workspace::scope::WorkspaceScope::narrowed(
            args["workspaceRoot"].as_str(),
            &state.config.additional_roots,
            within_path,
        )
        .map(Some),
        None => Ok(crate::workspace::scope::WorkspaceScope::new(
            args["workspaceRoot"].as_str(),
            &state.config.additional_roots,
        )),
    }
}

/// Refuse one query whose `withinPath` argument is not authorized.
///
/// `-32602` (invalid params) with the reason `WorkspaceScope` produced: the
/// argument is a parameter of the request that cannot be satisfied, not an empty
/// answer about the workspace.
fn scope_failure(message: String) -> outcome::QueryFailure {
    outcome::QueryFailure::invalid(format!("Invalid 'withinPath' argument: {message}"))
}

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query.rs"]
mod tests;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_2.rs"]
mod tests_hydration;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_3.rs"]
mod tests_multi_root_hydration;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_issue_150_schema.rs"]
mod tests_issue_150_schema;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_issue_151_contract.rs"]
mod tests_issue_151_contract;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_4.rs"]
mod tests_reverse_hydration;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_5.rs"]
mod tests_hydration_completeness;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_6.rs"]
mod tests_filesystem_hydration;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_7.rs"]
mod tests_filesystem_safety;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_8.rs"]
mod tests_hydration_discovery_cache;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_9.rs"]
mod tests_filesystem_discovery_cache;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_provider_readiness.rs"]
mod tests_provider_readiness;

#[cfg(all(test, feature = "rust", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_reverse_edge_completeness.rs"]
mod tests_reverse_edge_completeness;

#[cfg(all(
    test,
    feature = "rust",
    feature = "csharp",
    feature = "typescript",
    feature = "angular"
))]
#[path = "../../tests/mcp/workspace_query_provider_equivalence.rs"]
mod tests_provider_equivalence;

#[cfg(all(test, feature = "rust", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_warm_state_authority.rs"]
mod tests_warm_state_authority;

#[cfg(all(test, feature = "rust", feature = "csharp", feature = "dotnet"))]
#[path = "../../tests/mcp/workspace_query_dbcontext_role.rs"]
mod tests_dbcontext_role;

#[cfg(all(test, feature = "rust", feature = "csharp", feature = "dotnet"))]
#[path = "../../tests/mcp/workspace_query_automapper_r7.rs"]
mod tests_automapper_r7;

#[cfg(all(test, feature = "rust", feature = "csharp", feature = "dotnet"))]
#[path = "../../tests/mcp/workspace_query_signalr_r8.rs"]
mod tests_signalr_r8;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_aspnet_r9.rs"]
mod tests_aspnet_r9;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_mstest_r10.rs"]
mod tests_mstest_r10;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_aspnet_r11.rs"]
mod tests_aspnet_r11;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_csharp_convergence_r12.rs"]
mod tests_csharp_convergence_r12;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_issue_155.rs"]
mod tests_issue_155;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_issue_155_dependencies.rs"]
mod tests_issue_155_dependencies;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
mod publication_test_support;
#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_issue_155_blockers.rs"]
mod tests_issue_155_blockers;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_issue_156.rs"]
mod tests_issue_156;

#[cfg(all(test, feature = "dotnet", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_issue_156_dependencies.rs"]
mod tests_issue_156_dependencies;

#[cfg(all(test, feature = "rust", feature = "java", feature = "spring_boot"))]
#[path = "../../tests/mcp/workspace_query_legacy_edit_adequacy.rs"]
mod tests_legacy_edit_adequacy;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_publication_retry.rs"]
mod tests_publication_retry;

#[cfg(all(test, feature = "rust", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_entities_auto_compile.rs"]
mod tests_entities_auto_compile;

#[cfg(all(test, feature = "rust", feature = "angular"))]
#[path = "../../tests/mcp/workspace_query_hydration_fidelity.rs"]
mod tests_hydration_fidelity;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_cycle_witness.rs"]
mod tests_cycle_witness;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_identity_resolution.rs"]
mod tests_identity_resolution;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_batch.rs"]
mod tests_batch;

#[cfg(all(test, feature = "rust", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_batch_preparation.rs"]
mod tests_batch_preparation;

#[cfg(all(
    test,
    feature = "rust",
    feature = "csharp",
    feature = "typescript",
    feature = "angular"
))]
#[path = "../../tests/mcp/workspace_query_performance_work_counts.rs"]
mod tests_performance_work_counts;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_name_validation.rs"]
mod tests_name_validation;

#[cfg(all(test, feature = "rust", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_file_diagnostics.rs"]
mod tests_file_diagnostics;

// Native call facts (`SemanticRelation::Calls`) end-to-end: cross-file,
// cross-project, and the repeated-query discovery cache.
#[cfg(all(test, feature = "rust", feature = "csharp"))]
#[path = "../../tests/mcp/workspace_query_calls.rs"]
mod tests_native_calls;

#[cfg(all(test, feature = "rust", feature = "csharp"))]
#[path = "../../tests/mcp/csharp_call_authority_lifecycle.rs"]
mod csharp_call_authority_lifecycle_tests;

#[cfg(all(test, feature = "rust", feature = "csharp"))]
#[path = "../../tests/mcp/issue_144_performance_work_counts.rs"]
mod tests_issue_144_performance_work_counts;

#[cfg(all(test, feature = "rust"))]
#[path = "../../tests/mcp/workspace_query_exact_identity_coverage.rs"]
mod tests_exact_identity_coverage;

// Native call facts for the additional language producers (TypeScript, Java,
// Rust)
// end-to-end: cross-file `reverse_edges` returns Clean-CTX-authored callers for
// either language, without any CBM-supplied call relationship.
#[cfg(all(test, feature = "rust", feature = "typescript", feature = "java"))]
#[path = "../../tests/mcp/workspace_query_calls_languages.rs"]
mod tests_native_calls_languages;

// Spring Boot semantic edges through the real provide/query MCP lifecycle.
#[cfg(all(test, feature = "rust", feature = "spring_boot"))]
#[path = "../../tests/mcp/workspace_query_spring.rs"]
mod tests_spring_lifecycle;

// BOUND-ARROW callers (TypeScript) end-to-end: the arrow's binding name is the
// caller, the CALLER's file asserts the fact, and WSC-004 scope holds.
#[cfg(all(test, feature = "rust", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_calls_arrows.rs"]
mod tests_native_calls_arrows;

// Owner-aware file-local call inspection: canonical IR remains the authority,
// while global WorkspaceIndex identity and cross-file query behavior stay
// unchanged.
#[cfg(all(test, feature = "rust", feature = "csharp", feature = "typescript"))]
#[path = "../../tests/mcp/workspace_query_calls_in_file.rs"]
mod tests_calls_in_file;

#[cfg(all(test, feature = "angular"))]
#[path = "../../tests/mcp/workspace_query_issue_157.rs"]
mod tests_issue_157;

#[cfg(all(test, feature = "angular"))]
#[path = "../../tests/mcp/workspace_query_issue_157_dependencies.rs"]
mod tests_issue_157_dependencies;

#[cfg(feature = "angular")]
mod angular_modules;

#[cfg(all(test, feature = "angular"))]
#[path = "../../tests/mcp/workspace_query_issue_162.rs"]
mod tests_issue_162;
