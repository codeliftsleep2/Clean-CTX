class Peer0 {}
class Probe0 { peer?: Peer0; }
