import type {Peer0} from '../cell15/owner15';
export class Probe2 { peer?: Peer0; }
