import type {Peer0} from '../cell15/owner15';
export class Probe11 { peer?: Peer0; }
