import type {Peer0} from '../cell15/owner15';
export class Probe4 { peer?: Peer0; }
