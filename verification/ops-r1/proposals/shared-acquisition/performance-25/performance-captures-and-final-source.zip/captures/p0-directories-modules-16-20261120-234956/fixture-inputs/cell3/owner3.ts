import type {Peer0} from '../cell15/owner15';
export class Probe3 { peer?: Peer0; }
