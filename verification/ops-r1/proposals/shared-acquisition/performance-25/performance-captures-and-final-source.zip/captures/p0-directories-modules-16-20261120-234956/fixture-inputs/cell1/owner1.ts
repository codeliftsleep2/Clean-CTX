import type {Peer0} from '../cell15/owner15';
export class Probe1 { peer?: Peer0; }
