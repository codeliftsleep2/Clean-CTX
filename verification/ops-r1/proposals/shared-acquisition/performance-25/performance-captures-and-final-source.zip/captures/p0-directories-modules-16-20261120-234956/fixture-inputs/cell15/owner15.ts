export class Peer0 {}
export class Probe15 { peer?: Peer0; }
