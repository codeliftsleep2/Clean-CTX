import type {Peer0} from './owner15';
export class Probe2 { peer?: Peer0; }
