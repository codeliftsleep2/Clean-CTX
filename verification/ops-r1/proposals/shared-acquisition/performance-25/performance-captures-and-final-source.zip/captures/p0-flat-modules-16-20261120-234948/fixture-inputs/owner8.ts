import type {Peer0} from './owner15';
export class Probe8 { peer?: Peer0; }
