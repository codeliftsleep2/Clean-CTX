import type {Peer0} from './owner15';
export class Probe11 { peer?: Peer0; }
