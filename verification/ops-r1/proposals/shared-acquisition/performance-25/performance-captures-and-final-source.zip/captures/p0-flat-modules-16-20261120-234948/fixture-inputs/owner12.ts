import type {Peer0} from './owner15';
export class Probe12 { peer?: Peer0; }
