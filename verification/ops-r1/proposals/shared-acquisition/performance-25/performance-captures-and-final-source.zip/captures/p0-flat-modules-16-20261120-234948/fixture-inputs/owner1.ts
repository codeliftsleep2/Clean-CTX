import type {Peer0} from './owner15';
export class Probe1 { peer?: Peer0; }
