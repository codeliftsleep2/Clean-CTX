import type {Peer0} from './owner15';
export class Probe7 { peer?: Peer0; }
