import type {Peer0} from './owner15';
export class Probe3 { peer?: Peer0; }
