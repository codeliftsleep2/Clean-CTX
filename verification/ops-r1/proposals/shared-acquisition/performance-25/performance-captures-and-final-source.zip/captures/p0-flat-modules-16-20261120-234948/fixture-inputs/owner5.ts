import type {Peer0} from './owner15';
export class Probe5 { peer?: Peer0; }
