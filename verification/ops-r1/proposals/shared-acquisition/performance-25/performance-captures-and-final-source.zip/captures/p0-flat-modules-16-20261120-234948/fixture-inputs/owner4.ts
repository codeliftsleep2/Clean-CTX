import type {Peer0} from './owner15';
export class Probe4 { peer?: Peer0; }
