import type {Peer0} from './owner15';
export class Probe9 { peer?: Peer0; }
