import type {Peer0} from './owner15';
export class Probe14 { peer?: Peer0; }
