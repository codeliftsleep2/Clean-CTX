import type {Peer0} from './owner15';
export class Probe10 { peer?: Peer0; }
