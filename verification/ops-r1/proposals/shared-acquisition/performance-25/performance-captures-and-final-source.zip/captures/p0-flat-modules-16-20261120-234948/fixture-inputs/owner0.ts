import type {Peer0} from './owner15';
export class Probe0 { peer?: Peer0; }
