import type {Peer0} from './owner15';
export class Probe6 { peer?: Peer0; }
