import type {Peer0} from './owner15';
export class Probe13 { peer?: Peer0; }
