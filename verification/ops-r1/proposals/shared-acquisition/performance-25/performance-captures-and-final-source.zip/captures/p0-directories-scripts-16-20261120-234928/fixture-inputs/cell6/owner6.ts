class Probe6 { peer?: Peer0; }
