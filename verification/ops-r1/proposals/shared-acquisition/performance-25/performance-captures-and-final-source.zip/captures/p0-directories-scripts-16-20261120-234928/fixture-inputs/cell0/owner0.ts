class Probe0 { peer?: Peer0; }
