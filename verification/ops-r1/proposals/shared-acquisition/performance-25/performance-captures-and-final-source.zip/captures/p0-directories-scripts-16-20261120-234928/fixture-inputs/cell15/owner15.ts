class Peer0 {}
class Probe15 { peer?: Peer0; }
