class Probe1 { peer?: Peer0; }
