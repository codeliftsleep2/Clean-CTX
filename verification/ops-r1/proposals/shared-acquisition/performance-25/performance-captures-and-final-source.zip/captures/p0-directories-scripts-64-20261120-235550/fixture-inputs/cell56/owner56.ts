class Probe56 { peer?: Peer0; }
