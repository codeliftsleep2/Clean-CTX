class Probe54 { peer?: Peer0; }
