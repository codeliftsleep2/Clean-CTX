class Probe59 { peer?: Peer0; }
