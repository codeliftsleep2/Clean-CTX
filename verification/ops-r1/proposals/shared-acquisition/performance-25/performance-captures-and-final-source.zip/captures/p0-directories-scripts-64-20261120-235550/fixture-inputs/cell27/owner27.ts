class Probe27 { peer?: Peer0; }
