class Probe24 { peer?: Peer0; }
