class Probe61 { peer?: Peer0; }
