class Probe50 { peer?: Peer0; }
