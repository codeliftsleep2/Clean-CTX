class Probe51 { peer?: Peer0; }
