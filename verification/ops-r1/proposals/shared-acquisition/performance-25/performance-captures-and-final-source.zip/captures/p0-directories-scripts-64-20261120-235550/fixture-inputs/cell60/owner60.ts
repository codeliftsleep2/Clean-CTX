class Probe60 { peer?: Peer0; }
