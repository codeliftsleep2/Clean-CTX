class Probe22 { peer?: Peer0; }
