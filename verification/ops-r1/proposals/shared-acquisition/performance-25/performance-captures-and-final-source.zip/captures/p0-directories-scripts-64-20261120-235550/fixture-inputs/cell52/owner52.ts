class Probe52 { peer?: Peer0; }
