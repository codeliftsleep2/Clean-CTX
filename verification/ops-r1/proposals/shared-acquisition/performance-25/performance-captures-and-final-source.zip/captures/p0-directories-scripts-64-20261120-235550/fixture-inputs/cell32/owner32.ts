class Probe32 { peer?: Peer0; }
