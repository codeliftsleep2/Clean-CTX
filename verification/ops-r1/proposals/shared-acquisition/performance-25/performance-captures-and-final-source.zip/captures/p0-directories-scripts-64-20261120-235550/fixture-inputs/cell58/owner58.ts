class Probe58 { peer?: Peer0; }
