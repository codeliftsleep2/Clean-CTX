class Probe26 { peer?: Peer0; }
