class Probe40 { peer?: Peer0; }
