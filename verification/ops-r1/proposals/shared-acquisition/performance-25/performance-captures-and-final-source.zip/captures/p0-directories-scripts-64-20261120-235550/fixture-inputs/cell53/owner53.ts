class Probe53 { peer?: Peer0; }
