class Probe48 { peer?: Peer0; }
