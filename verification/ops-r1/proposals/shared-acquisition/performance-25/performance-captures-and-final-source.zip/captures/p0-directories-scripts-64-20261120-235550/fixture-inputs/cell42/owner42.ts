class Probe42 { peer?: Peer0; }
