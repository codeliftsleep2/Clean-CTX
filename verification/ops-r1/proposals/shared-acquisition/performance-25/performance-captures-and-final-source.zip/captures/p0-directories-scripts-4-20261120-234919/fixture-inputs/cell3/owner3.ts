class Peer0 {}
class Probe3 { peer?: Peer0; }
