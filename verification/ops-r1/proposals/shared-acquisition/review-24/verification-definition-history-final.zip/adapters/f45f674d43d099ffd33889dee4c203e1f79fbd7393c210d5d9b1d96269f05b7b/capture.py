"""Reviewed stage adapter for the existing OPS-R1 bounded monitor; never builds."""
import contextlib,hashlib,importlib.util,io,json,os,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[5]
SOURCE_PINS={'red': 'ca0aba6c734d91da73be356a8c74779816ca8af254e43a63d6fe7e529bd51e14', 'green': '389a714aa2d037e73e92a623564c4198896bf2e5a6ccc2c00408381899f24ac5', 'green-amendment-18': '21734cd76b0d8a2a008b07964d31238b39354dce75af1456059ff71862d567a0', 'green-m3-23': 'c5348d3dd24e4903610cd7a137037e4fbe6e59b1eaab2206016908e28d26ef1f'}
CASES={
    "fitness": [
        4,
        0
    ],
    "precached_host_unit_project_and_owner_only_proof": [
        1,
        1
    ],
    "seed_is_not_sibling_disk_authority": [
        1,
        2
    ],
    "divergent_overlay_and_private_cache_are_not_overwritten": [
        1,
        3
    ],
    "failed_partial_and_poisoned_leader_do_not_grant_or_poison": [
        1,
        4
    ],
    "standalone_capture_and_missing_module_qualification": [
        1,
        5
    ],
    "precached_attached_unit_replays_only_its_source": [
        1,
        6
    ],
    "failed_partial_after_one_unit_keeps_local_failure": [
        1,
        7
    ],
    "precached_unaccounted_values_never_seal_from_nonempty_witnesses": [
        1,
        8
    ],
    "config_roots_and_route_changes_stay_independent": [
        1,
        9
    ],
    "source_and_package_changes_invalidate_proof": [
        1,
        10
    ],
    "request_directory_and_inherited_project_remain_authoritative": [
        1,
        11
    ],
    "multiple_projects_and_operations_do_not_share_authority": [
        1,
        12
    ],
    "same_config_different_automatic_type_lookup_stays_distinct": [
        1,
        13
    ],
    "concurrent_owners_and_nested_acquisition_are_isolated": [
        1,
        14
    ],
    "bootstrap": [
        1,
        15
    ],
    "hydration_and_explicit": [
        1,
        16
    ],
    "worker_order_non_ts": [
        1,
        17
    ],
    "worker_failure_non_ts": [
        1,
        18
    ],
    "batch_prepublication": [
        1,
        19
    ],
    "typescript_prepublication": [
        1,
        20
    ],
    "typescript_persistence": [
        1,
        21
    ],
    "resolver_positive": [
        1,
        22
    ],
    "retirement": [
        1,
        23
    ],
    "csharp": [
        1,
        24
    ],
    "ambient_dependency": [
        1,
        25
    ]
}
def digest(data):return hashlib.sha256(data).hexdigest()
def main():
    stage=os.environ.get('OPS_R1_STAGE')
    if stage not in SOURCE_PINS:raise ValueError('Explicit OPS_R1_STAGE=red or green required')
    source_key=stage
    source_name='reviewed-red-sources.json'
    if stage=='green':
        amendment=os.environ.get('OPS_R1_GREEN_SOURCE','amendment-18')
        if amendment not in ('amendment-15','amendment-18','m3-23'):
            raise ValueError('Unknown pinned GREEN source amendment')
        source_name='reviewed-green-'+amendment+'-sources.json'
        if amendment=='amendment-18':source_key='green-amendment-18'
        if amendment=='m3-23':source_key='green-m3-23'
    proposal=pathlib.Path(__file__).with_name(source_name)
    if digest(proposal.read_bytes())!=SOURCE_PINS[source_key]:raise ValueError('Reviewed stage source pin changed')
    import subprocess
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    if head!='0dd8d7503af3116241ad7c1e23c293b1d5849cc1':raise ValueError('Reviewed baseline HEAD changed')
    original=ROOT/'verification/ops-r1/p0/run_bounded.py'
    if digest(original.read_bytes())!='5acc4590c602ee2528c27419b446443fc1325664457adda0e1aab1639dec4484':
        raise ValueError('Reviewed monitor changed; no child authorized')
    spec=importlib.util.spec_from_file_location('ops_reviewed_monitor',original)
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    core.__file__=__file__
    core.PROPOSAL=proposal
    core.CASES={'fitness':(4,0)} if stage=='red' else {k:tuple(v) for k,v in CASES.items()}
    capture=io.StringIO()
    with contextlib.redirect_stdout(capture):code=core.main()
    output=capture.getvalue().strip()
    if '--verify-sources-only' in sys.argv or '--verify-baseline-only' in sys.argv:
        print(output);return code
    folder=pathlib.Path(output)
    if not folder.resolve().is_relative_to((ROOT/'target/ops-r1').resolve()):raise ValueError('Unexpected evidence destination')
    receipt_path=folder/'receipt.json';original_receipt=receipt_path.read_bytes();receipt=json.loads(original_receipt)
    (folder/'monitor-receipt.json').write_bytes(original_receipt)
    receipt['monitor_receipt_sha256']=digest(original_receipt)
    receipt['monitor_case_parameters']={key:receipt.pop(key) for key in ['units','component']}
    receipt['fixture_scope']='Four-owner public fitness' if receipt['case']=='fitness' else 'Pinned tracked control; fixture sizes are defined by that test, not the monitor compatibility parameters'
    receipt.update(proposal_stage=stage,source_pin_sha256=SOURCE_PINS[source_key],adapter_sha256=digest(pathlib.Path(__file__).read_bytes()),monitor_sha256=digest(original.read_bytes()))
    for name in ['work-counts.json']:
        if (folder/name).exists():receipt[name+'_sha256']=digest((folder/name).read_bytes())
    receipt['selection_standing']='One exact Rust tracked test; no CI admission or leak certification'
    receipt_path.write_text(json.dumps(receipt,indent=2)+chr(10),encoding='utf-8')
    print(folder);return code
if __name__=='__main__':sys.exit(main())
